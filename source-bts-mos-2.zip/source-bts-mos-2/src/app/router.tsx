import { createBrowserRouter } from 'react-router-dom'

import Accueil from '../pages/Accueil'
import NotFound from '../pages/NotFound'

import ConnexionEtudiant from '../pages/etudiant/ConnexionEtudiant'
import InscriptionEtudiant from '../pages/etudiant/InscriptionEtudiant'
import AccueilEtudiant from '../pages/etudiant/AccueilEtudiant'
import ThemeSeances from '../pages/etudiant/ThemeSeances'
import Seance from '../pages/etudiant/Seance'
import SeanceEvaluation from '../pages/etudiant/SeanceEvaluation'
import MessagerieEtudiant from '../pages/etudiant/MessagerieEtudiant'
import MesCompetences from '../pages/etudiant/MesCompetences'

import ConnexionEnseignant from '../pages/enseignant/ConnexionEnseignant'
import GestionComptes from '../pages/enseignant/GestionComptes'
import ClassesGroupes from '../pages/enseignant/ClassesGroupes'
import MotDePasseOublie from '../pages/etudiant/MotDePasseOublie'
import AccueilEnseignant from '../pages/enseignant/AccueilEnseignant'
import ListeEtudiants from '../pages/enseignant/ListeEtudiants'
import SuiviEtudiant from '../pages/enseignant/SuiviEtudiant'
import Devoirs from '../pages/enseignant/Devoirs'
import CorrectionDevoir from '../pages/enseignant/CorrectionDevoir'
import Deverrouillage from '../pages/enseignant/Deverrouillage'
import MessagerieEnseignant from '../pages/enseignant/MessagerieEnseignant'
import Exports from '../pages/enseignant/Exports'
import DemandesInscription from '../pages/enseignant/DemandesInscription'
import CorrigeSeance from '../pages/enseignant/CorrigeSeance'

export const router = createBrowserRouter([
  { path: '/', element: <Accueil /> },

  // Espace étudiant
  { path: '/etudiant/connexion', element: <ConnexionEtudiant /> },
  { path: '/etudiant/inscription', element: <InscriptionEtudiant /> },
  { path: '/etudiant', element: <AccueilEtudiant /> },
  { path: '/etudiant/theme/:themeId', element: <ThemeSeances /> },
  { path: '/etudiant/seance/:seanceId', element: <Seance /> },
  { path: '/etudiant/seance/:seanceId/:onglet', element: <Seance /> },
  { path: '/etudiant/evaluation/:seanceId', element: <SeanceEvaluation /> },
  { path: '/etudiant/messagerie', element: <MessagerieEtudiant /> },
  { path: '/etudiant/competences', element: <MesCompetences /> },
  { path: '/etudiant/mot-de-passe-oublie', element: <MotDePasseOublie /> },

  // Espace enseignant
  { path: '/enseignant/connexion', element: <ConnexionEnseignant /> },
  { path: '/enseignant', element: <AccueilEnseignant /> },
  { path: '/enseignant/etudiants', element: <ListeEtudiants /> },
  { path: '/enseignant/etudiants/:etudiantId', element: <SuiviEtudiant /> },
  { path: '/enseignant/devoirs', element: <Devoirs /> },
  { path: '/enseignant/devoirs/:devoirId', element: <CorrectionDevoir /> },
  { path: '/enseignant/deverrouillage', element: <Deverrouillage /> },
  { path: '/enseignant/messagerie', element: <MessagerieEnseignant /> },
  { path: '/enseignant/exports', element: <Exports /> },
  { path: '/enseignant/inscriptions', element: <DemandesInscription /> },
  { path: '/enseignant/gestion-comptes', element: <GestionComptes /> },
  { path: '/enseignant/classes-groupes', element: <ClassesGroupes /> },
  { path: '/enseignant/corriges/:seanceId', element: <CorrigeSeance /> },

  { path: '*', element: <NotFound /> },
])

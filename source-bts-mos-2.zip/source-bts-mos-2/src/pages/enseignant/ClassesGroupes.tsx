import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'

interface Classe {
  id: string
  nom: string
}
interface Groupe {
  id: string
  nom: string
  classe_id: string
}
interface Etudiant {
  user_id: string
  nom: string
  prenom: string
  classe_id: string | null
}
interface EtudiantGroupe {
  user_id: string
  groupe_id: string
}

export default function ClassesGroupes() {
  const navigate = useNavigate()
  const [classes, setClasses] = useState<Classe[]>([])
  const [groupes, setGroupes] = useState<Groupe[]>([])
  const [etudiants, setEtudiants] = useState<Etudiant[]>([])
  const [etudiantGroupes, setEtudiantGroupes] = useState<EtudiantGroupe[]>([])
  const [chargement, setChargement] = useState(true)
  const [classeActive, setClasseActive] = useState<string | null>(null)

  // Etats edition
  const [nouvelleClasse, setNouvelleClasse] = useState('')
  const [nouveauGroupe, setNouveauGroupe] = useState('')
  const [renomClasse, setRenomClasse] = useState<{ id: string; nom: string } | null>(null)
  const [renomGroupe, setRenomGroupe] = useState<{ id: string; nom: string } | null>(null)
  const [enCours, setEnCours] = useState(false)

  const charger = async () => {
    const [{ data: cl }, { data: gr }, { data: et }, { data: eg }] = await Promise.all([
      supabase.from('classes').select('*').order('nom'),
      supabase.from('groupes').select('*').order('nom'),
      supabase.from('demandes_inscription').select('user_id, nom, prenom, classe_id').eq('statut', 'accepte').order('nom'),
      supabase.from('etudiant_groupes').select('*'),
    ])
    setClasses(cl ?? [])
    setGroupes(gr ?? [])
    setEtudiants(et ?? [])
    setEtudiantGroupes(eg ?? [])
    if (!classeActive && cl && cl.length > 0) setClasseActive(cl[0].id)
    setChargement(false)
  }

  useEffect(() => { charger() }, [])

  // --- Classes ---
  const creerClasse = async () => {
    if (!nouvelleClasse.trim()) return
    setEnCours(true)
    const { data } = await supabase.from('classes').insert({ nom: nouvelleClasse.trim() }).select().single()
    if (data) { setClasses(p => [...p, data].sort((a, b) => a.nom.localeCompare(b.nom))); setClasseActive(data.id) }
    setNouvelleClasse('')
    setEnCours(false)
  }

  const renommerClasse = async () => {
    if (!renomClasse || !renomClasse.nom.trim()) return
    await supabase.from('classes').update({ nom: renomClasse.nom.trim() }).eq('id', renomClasse.id)
    setClasses(p => p.map(c => c.id === renomClasse.id ? { ...c, nom: renomClasse.nom.trim() } : c).sort((a, b) => a.nom.localeCompare(b.nom)))
    setRenomClasse(null)
  }

  const supprimerClasse = async (id: string) => {
    const nb = etudiants.filter(e => e.classe_id === id).length
    if (!confirm(`Supprimer cette classe ? ${nb > 0 ? `${nb} etudiant(s) seront sans classe.` : ''}`)) return
    await supabase.from('classes').delete().eq('id', id)
    setClasses(p => p.filter(c => c.id !== id))
    setGroupes(p => p.filter(g => g.classe_id !== id))
    if (classeActive === id) setClasseActive(classes.find(c => c.id !== id)?.id ?? null)
  }

  // --- Groupes ---
  const creerGroupe = async () => {
    if (!nouveauGroupe.trim() || !classeActive) return
    setEnCours(true)
    const { data } = await supabase.from('groupes').insert({ nom: nouveauGroupe.trim(), classe_id: classeActive }).select().single()
    if (data) setGroupes(p => [...p, data].sort((a, b) => a.nom.localeCompare(b.nom)))
    setNouveauGroupe('')
    setEnCours(false)
  }

  const renommerGroupe = async () => {
    if (!renomGroupe || !renomGroupe.nom.trim()) return
    await supabase.from('groupes').update({ nom: renomGroupe.nom.trim() }).eq('id', renomGroupe.id)
    setGroupes(p => p.map(g => g.id === renomGroupe.id ? { ...g, nom: renomGroupe.nom.trim() } : g))
    setRenomGroupe(null)
  }

  const supprimerGroupe = async (id: string) => {
    if (!confirm('Supprimer ce groupe ?')) return
    await supabase.from('groupes').delete().eq('id', id)
    setGroupes(p => p.filter(g => g.id !== id))
    setEtudiantGroupes(p => p.filter(eg => eg.groupe_id !== id))
  }

  // --- Affectation classe ---
  const affecterClasse = async (userId: string, classeId: string | null) => {
    await supabase.from('demandes_inscription').update({ classe_id: classeId }).eq('user_id', userId)
    setEtudiants(p => p.map(e => e.user_id === userId ? { ...e, classe_id: classeId } : e))
  }

  // --- Affectation groupe ---
  const toggleGroupe = async (userId: string, groupeId: string) => {
    const existe = etudiantGroupes.some(eg => eg.user_id === userId && eg.groupe_id === groupeId)
    if (existe) {
      await supabase.from('etudiant_groupes').delete().eq('user_id', userId).eq('groupe_id', groupeId)
      setEtudiantGroupes(p => p.filter(eg => !(eg.user_id === userId && eg.groupe_id === groupeId)))
    } else {
      await supabase.from('etudiant_groupes').insert({ user_id: userId, groupe_id: groupeId })
      setEtudiantGroupes(p => [...p, { user_id: userId, groupe_id: groupeId }])
    }
  }

  const classeSelectionnee = classes.find(c => c.id === classeActive)
  const groupesClasse = groupes.filter(g => g.classe_id === classeActive)
  const etudiantsClasse = etudiants.filter(e => e.classe_id === classeActive)
  const etudiantsSansClasse = etudiants.filter(e => !e.classe_id)

  const Btn = ({ onClick, children, rouge }: { onClick: () => void; children: React.ReactNode; rouge?: boolean }) => (
    <button onClick={onClick}
      style={{ fontSize: '0.72rem', padding: '3px 8px', borderRadius: '5px', border: `1px solid ${rouge ? '#FECACA' : '#D1D5DB'}`, background: rouge ? '#FEF2F2' : '#FFFFFF', color: rouge ? '#DC2626' : '#374151', cursor: 'pointer', fontFamily: 'Arial' }}>
      {children}
    </button>
  )

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Tableau de bord
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Classes et groupes</span>
        <div style={{ width: '100px' }} />
      </header>

      {chargement ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
      ) : (
        <main style={{ padding: '1.25rem 1rem', maxWidth: '900px', margin: '0 auto', display: 'grid', gridTemplateColumns: '220px 1fr', gap: '1.25rem', alignItems: 'start' }}>

          {/* Colonne gauche : liste des classes */}
          <div>
            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', overflow: 'hidden', marginBottom: '0.75rem' }}>
              <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #F3F4F6', fontSize: '0.72rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Classes
              </div>
              {classes.length === 0 && (
                <div style={{ padding: '0.75rem 1rem', fontSize: '0.8rem', color: '#9CA3AF' }}>Aucune classe</div>
              )}
              {classes.map(cl => (
                <div key={cl.id} onClick={() => setClasseActive(cl.id)}
                  style={{ padding: '0.75rem 1rem', cursor: 'pointer', backgroundColor: classeActive === cl.id ? '#F0FDF4' : '#FFFFFF', borderLeft: `3px solid ${classeActive === cl.id ? '#1B6B3A' : 'transparent'}`, borderBottom: '1px solid #F3F4F6' }}>
                  {renomClasse?.id === cl.id ? (
                    <div style={{ display: 'flex', gap: '4px' }} onClick={e => e.stopPropagation()}>
                      <input value={renomClasse.nom} onChange={e => setRenomClasse({ ...renomClasse, nom: e.target.value })}
                        onKeyDown={e => e.key === 'Enter' && renommerClasse()}
                        autoFocus style={{ flex: 1, padding: '3px 6px', border: '1px solid #D1D5DB', borderRadius: '4px', fontSize: '0.8rem', fontFamily: 'Arial' }} />
                      <Btn onClick={renommerClasse}>OK</Btn>
                      <Btn onClick={() => setRenomClasse(null)}>x</Btn>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: classeActive === cl.id ? '700' : '500', color: '#111827' }}>{cl.nom}</span>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <Btn onClick={() => setRenomClasse({ id: cl.id, nom: cl.nom })}>
                          <svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>
                        </Btn>
                        <Btn rouge onClick={() => supprimerClasse(cl.id)}>
                          <svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
                        </Btn>
                      </div>
                    </div>
                  )}
                  <div style={{ fontSize: '0.7rem', color: '#9CA3AF', marginTop: '2px' }}>
                    {etudiants.filter(e => e.classe_id === cl.id).length} etudiant(s)
                  </div>
                </div>
              ))}
            </div>
            {/* Creer classe */}
            <div style={{ display: 'flex', gap: '0.4rem' }}>
              <input value={nouvelleClasse} onChange={e => setNouvelleClasse(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && creerClasse()}
                placeholder="Nouvelle classe..."
                style={{ flex: 1, padding: '0.5rem', border: '1px solid #D1D5DB', borderRadius: '7px', fontSize: '0.8rem', fontFamily: 'Arial' }} />
              <button onClick={creerClasse} disabled={enCours || !nouvelleClasse.trim()}
                style={{ padding: '0.5rem 0.75rem', backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '7px', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Arial', fontWeight: '700' }}>
                +
              </button>
            </div>
          </div>

          {/* Colonne droite : detail classe */}
          {classeSelectionnee ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

              {/* Groupes de la classe */}
              <div style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', overflow: 'hidden' }}>
                <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #F3F4F6', fontSize: '0.72rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Groupes de {classeSelectionnee.nom}
                </div>
                {groupesClasse.length === 0 ? (
                  <div style={{ padding: '0.75rem 1rem', fontSize: '0.8rem', color: '#9CA3AF' }}>Aucun groupe</div>
                ) : (
                  <div style={{ padding: '0.5rem 1rem', display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                    {groupesClasse.map(g => (
                      <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: '4px', backgroundColor: '#F0FDF4', border: '1px solid #6EE7B7', borderRadius: '20px', padding: '4px 10px' }}>
                        {renomGroupe?.id === g.id ? (
                          <div style={{ display: 'flex', gap: '4px' }}>
                            <input value={renomGroupe.nom} onChange={e => setRenomGroupe({ ...renomGroupe, nom: e.target.value })}
                              onKeyDown={e => e.key === 'Enter' && renommerGroupe()}
                              autoFocus style={{ width: '80px', padding: '2px 4px', border: '1px solid #D1D5DB', borderRadius: '4px', fontSize: '0.8rem', fontFamily: 'Arial' }} />
                            <Btn onClick={renommerGroupe}>OK</Btn>
                            <Btn onClick={() => setRenomGroupe(null)}>x</Btn>
                          </div>
                        ) : (
                          <>
                            <span style={{ fontSize: '0.8rem', color: '#065F46', fontWeight: '600' }}>{g.nom}</span>
                            <span style={{ fontSize: '0.7rem', color: '#9CA3AF' }}>({etudiantGroupes.filter(eg => eg.groupe_id === g.id).length})</span>
                            <button onClick={() => setRenomGroupe({ id: g.id, nom: g.nom })} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF', padding: '0 2px', fontSize: '0.7rem' }}>✎</button>
                            <button onClick={() => supprimerGroupe(g.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#DC2626', padding: '0 2px', fontSize: '0.7rem' }}>x</button>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                <div style={{ padding: '0.5rem 1rem', borderTop: '1px solid #F3F4F6', display: 'flex', gap: '0.4rem' }}>
                  <input value={nouveauGroupe} onChange={e => setNouveauGroupe(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && creerGroupe()}
                    placeholder={`Nouveau groupe dans ${classeSelectionnee.nom}...`}
                    style={{ flex: 1, padding: '0.4rem 0.6rem', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '0.8rem', fontFamily: 'Arial' }} />
                  <button onClick={creerGroupe} disabled={!nouveauGroupe.trim()}
                    style={{ padding: '0.4rem 0.75rem', backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '6px', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Arial', fontWeight: '700' }}>
                    +
                  </button>
                </div>
              </div>

              {/* Etudiants de la classe */}
              <div style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', overflow: 'hidden' }}>
                <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #F3F4F6', fontSize: '0.72rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Etudiants ({etudiantsClasse.length})
                </div>
                {etudiantsClasse.length === 0 ? (
                  <div style={{ padding: '0.75rem 1rem', fontSize: '0.8rem', color: '#9CA3AF' }}>Aucun etudiant dans cette classe</div>
                ) : (
                  etudiantsClasse.map(e => {
                    const gEtudiant = etudiantGroupes.filter(eg => eg.user_id === e.user_id).map(eg => eg.groupe_id)
                    return (
                      <div key={e.user_id} style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #F3F4F6' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
                          <span style={{ fontSize: '0.85rem', fontWeight: '600', color: '#111827' }}>{e.prenom} {e.nom}</span>
                          <select value={e.classe_id ?? ''} onChange={ev => affecterClasse(e.user_id, ev.target.value || null)}
                            style={{ fontSize: '0.75rem', padding: '2px 6px', border: '1px solid #D1D5DB', borderRadius: '5px', fontFamily: 'Arial' }}>
                            <option value="">-- Sans classe --</option>
                            {classes.map(c => <option key={c.id} value={c.id}>{c.nom}</option>)}
                          </select>
                        </div>
                        {groupesClasse.length > 0 && (
                          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
                            {groupesClasse.map(g => {
                              const dans = gEtudiant.includes(g.id)
                              return (
                                <button key={g.id} onClick={() => toggleGroupe(e.user_id, g.id)}
                                  style={{ fontSize: '0.7rem', padding: '2px 8px', borderRadius: '20px', border: `1px solid ${dans ? '#1B6B3A' : '#D1D5DB'}`, background: dans ? '#D1FAE5' : '#FFFFFF', color: dans ? '#065F46' : '#6B7280', cursor: 'pointer', fontFamily: 'Arial', fontWeight: dans ? '700' : '400' }}>
                                  {g.nom}
                                </button>
                              )
                            })}
                          </div>
                        )}
                      </div>
                    )
                  })
                )}
              </div>

              {/* Etudiants sans classe */}
              {etudiantsSansClasse.length > 0 && (
                <div style={{ backgroundColor: '#FFFBEB', border: '1px solid #FCD34D', borderRadius: '10px', overflow: 'hidden' }}>
                  <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #FDE68A', fontSize: '0.72rem', fontWeight: '700', color: '#92400E', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    Sans classe ({etudiantsSansClasse.length})
                  </div>
                  {etudiantsSansClasse.map(e => (
                    <div key={e.user_id} style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #FDE68A', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.85rem', color: '#111827' }}>{e.prenom} {e.nom}</span>
                      <select value="" onChange={ev => affecterClasse(e.user_id, ev.target.value || null)}
                        style={{ fontSize: '0.75rem', padding: '2px 6px', border: '1px solid #FCD34D', borderRadius: '5px', fontFamily: 'Arial' }}>
                        <option value="">Affecter a une classe...</option>
                        {classes.map(c => <option key={c.id} value={c.id}>{c.nom}</option>)}
                      </select>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>
              Creez ou selectionnez une classe
            </div>
          )}
        </main>
      )}
    </div>
  )
}

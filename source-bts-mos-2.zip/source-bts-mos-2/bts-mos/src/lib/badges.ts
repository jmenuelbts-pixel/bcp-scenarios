import { supabase } from './supabase'

interface Progression { seance_id: string; onglet: string }

export const BADGES_DEF = [
  { id: 'premier_pas', label: 'Premier pas', desc: 'Vous avez visité votre premier onglet', icon: '🎯', couleur: '#1A56A0' },
  { id: 'explorateur', label: 'Explorateur', desc: '3 séances commencées', icon: '🔍', couleur: '#B8860B' },
  { id: 'assidu', label: 'Assidu', desc: '5 séances complétées à 100%', icon: '⭐', couleur: '#C2185B' },
  { id: 'devoir_rendu', label: 'Devoir rendu', desc: 'Premier devoir envoyé au professeur', icon: '📝', couleur: '#059669' },
  { id: 'journal', label: 'Chroniqueur', desc: 'Premier journal de bord écrit', icon: '📖', couleur: '#7C3AED' },
]

export async function verifierEtAttribuerBadges(userId: string, progressions: Progression[]) {
  const { data: badgesExistants } = await supabase
    .from('badges').select('badge_id').eq('user_id', userId)
  const dejObtenu = new Set((badgesExistants ?? []).map((b: { badge_id: string }) => b.badge_id))

  const seancesCommencees = new Set(progressions.map(p => p.seance_id)).size
  const onglets = ['capsule', 'fiche', 'presentiel', 'activites', 'travaux', 'journal']
  const seancesCompletes = Object.values(
    progressions.reduce((acc, p) => {
      if (!acc[p.seance_id]) acc[p.seance_id] = new Set()
      acc[p.seance_id].add(p.onglet)
      return acc
    }, {} as Record<string, Set<string>>)
  ).filter(s => onglets.every(o => s.has(o))).length

  const { count: nbDevoirs } = await supabase.from('devoirs')
    .select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('statut', 'remis')
  const { count: nbJournal } = await supabase.from('journal_bord')
    .select('id', { count: 'exact', head: true }).eq('user_id', userId)

  const conditions: Record<string, boolean> = {
    premier_pas: progressions.length > 0,
    explorateur: seancesCommencees >= 3,
    assidu: seancesCompletes >= 5,
    devoir_rendu: (nbDevoirs ?? 0) > 0,
    journal: (nbJournal ?? 0) > 0,
  }

  const nouveaux: string[] = []
  for (const [id, ok] of Object.entries(conditions)) {
    if (ok && !dejObtenu.has(id)) {
      await supabase.from('badges').insert({ user_id: userId, badge_id: id, obtenu_a: new Date().toISOString() })
      nouveaux.push(id)
    }
  }
  return nouveaux
}

export async function getBadgesEtudiant(userId: string) {
  const { data } = await supabase.from('badges').select('badge_id, obtenu_a').eq('user_id', userId)
  return (data ?? []) as { badge_id: string; obtenu_a: string }[]
}

import { createContext, useContext, useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { supabase } from './supabase'
import type { User, Session } from '@supabase/supabase-js'
import type { Role } from '../data/schema'

interface AuthContextType {
  user: User | null
  session: Session | null
  role: Role | null
  loading: boolean
  signInEtudiant: (email: string, mdp: string) => Promise<{ error: string | null }>
  signInEnseignant: (email: string, mdp: string) => Promise<{ error: string | null }>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  role: null,
  loading: true,
  signInEtudiant: async () => ({ error: null }),
  signInEnseignant: async () => ({ error: null }),
  signOut: async () => {},
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [role, setRole] = useState<Role | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      setRole((session?.user?.user_metadata?.role as Role) ?? null)
      setLoading(false)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      setRole((session?.user?.user_metadata?.role as Role) ?? null)
    })

    return () => subscription.unsubscribe()
  }, [])

  const signInEtudiant = async (email: string, mdp: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password: mdp })
    if (error) return { error: 'Email ou mot de passe incorrect.' }
    return { error: null }
  }

  const signInEnseignant = async (email: string, mdp: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password: mdp })
    if (error) return { error: 'Email ou mot de passe incorrect.' }
    return { error: null }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setSession(null)
    setRole(null)
  }

  return (
    <AuthContext.Provider value={{ user, session, role, loading, signInEtudiant, signInEnseignant, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}

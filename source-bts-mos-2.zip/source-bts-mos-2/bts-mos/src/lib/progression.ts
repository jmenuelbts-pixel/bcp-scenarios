import { supabase } from './supabase'
import type { OngletId } from '../data/schema'

// Enregistre qu'un étudiant a visité un onglet
export async function marquerOngletVisite(userId: string, seanceId: string, onglet: OngletId) {
  await supabase.from('progressions').upsert({
    user_id: userId,
    seance_id: seanceId,
    onglet,
    statut: 'complete',
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,seance_id,onglet' })
}

// Récupère la progression d'un étudiant
export async function getProgression(userId: string) {
  const { data } = await supabase
    .from('progressions')
    .select('seance_id, onglet, statut')
    .eq('user_id', userId)
  return data ?? []
}

// Calcule le % de progression pour une séance (nb onglets visités / 6)
export function calcProgressionSeance(progressions: { seance_id: string; onglet: string }[], seanceId: string) {
  const onglets = ['capsule', 'fiche', 'presentiel', 'activites', 'travaux', 'journal']
  const visites = progressions.filter(p => p.seance_id === seanceId).map(p => p.onglet)
  const nb = onglets.filter(o => visites.includes(o)).length
  return Math.round((nb / onglets.length) * 100)
}

// Calcule le % global (sur toutes les séances ouvertes)
export function calcProgressionGlobale(progressions: { seance_id: string; onglet: string }[], seancesOuvertes: string[]) {
  if (seancesOuvertes.length === 0) return 0
  const total = seancesOuvertes.length * 6
  const visites = progressions.filter(p => seancesOuvertes.includes(p.seance_id)).length
  return Math.round((visites / total) * 100)
}

// ─────────────────────────────────────────────────────────────────────────────
// SUIVI DES COMPÉTENCES BLOC 3
// ─────────────────────────────────────────────────────────────────────────────

import { COMPETENCES } from '../data/competences'
import type { ResultatCompetence, NiveauCompetence } from '../data/competences'

/**
 * Calcule le niveau de maîtrise pour chaque compétence du Bloc 3.
 *
 * Logique :
 *  - non_travaillee : aucune séance couvrant cette compétence n'a été visitée
 *  - en_cours       : au moins une séance visitée, mais pas toutes OU pas de devoir remis
 *  - atteinte       : toutes les séances couvrant la compétence visitées ET au moins un devoir remis
 *
 * @param progressions  lignes de la table progressions (seance_id, onglet)
 * @param devoirs       lignes de la table devoirs (seance_id, statut)
 */
export function calcCompetences(
  progressions: { seance_id: string; onglet: string }[],
  devoirs: { seance_id: string; statut: string }[],
): ResultatCompetence[] {
  // Séances où l'onglet "activites" a été visité (preuve de travail sur le contenu)
  const seancesAvecActivites = new Set(
    progressions.filter(p => p.onglet === 'activites').map(p => p.seance_id)
  )
  // Séances avec au moins un devoir remis (statut = 'remis')
  const seancesAvecDevoir = new Set(
    devoirs.filter(d => d.statut === 'remis').map(d => d.seance_id)
  )

  return COMPETENCES.map(competence => {
    const seancesRealisees = competence.seances.filter(s => seancesAvecActivites.has(s))
    const devoirRemis = competence.seances.some(s => seancesAvecDevoir.has(s))
    const toutesSeancesFaites = competence.seances.every(s => seancesAvecActivites.has(s))

    let niveau: NiveauCompetence
    if (seancesRealisees.length === 0) {
      niveau = 'non_travaillee'
    } else if (toutesSeancesFaites && devoirRemis) {
      niveau = 'atteinte'
    } else {
      niveau = 'en_cours'
    }

    return {
      competence,
      niveau,
      seancesRealisees,
      seancesTotales: competence.seances,
      scoreQuiz: null,   // réservé pour quand les scores seront persistés
      devoirRemis,
    }
  })
}

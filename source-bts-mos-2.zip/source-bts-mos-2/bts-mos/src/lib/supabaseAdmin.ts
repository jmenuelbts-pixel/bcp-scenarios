// Client Supabase Admin — utilise la clé service_role via variable d'environnement
// IMPORTANT : cette clé ne doit jamais être exposée publiquement
// Elle est injectée au moment du build par Vite via VITE_SUPABASE_SERVICE_ROLE_KEY
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string
const serviceRoleKey = import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY as string

export const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  }
})

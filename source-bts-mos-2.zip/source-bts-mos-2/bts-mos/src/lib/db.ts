import Dexie from 'dexie'
import type { Table } from 'dexie'
import type { Progression, Reponse, Devoir, EntreeJournalBord, Annotation, FlashcardSM2 } from '../data/schema'

export class MosProDB extends Dexie {
  progressions!: Table<Progression>
  reponses!: Table<Reponse>
  devoirs!: Table<Devoir>
  journal!: Table<EntreeJournalBord>
  annotations!: Table<Annotation>
  flashcards!: Table<FlashcardSM2>

  constructor() {
    super('MosProP3')
    this.version(1).stores({
      progressions: '[user_id+seance_id+onglet], user_id, seance_id',
      reponses: '[user_id+exercice_id], user_id',
      devoirs: 'id, user_id, seance_id, statut',
      journal: 'id, user_id, seance_id',
      annotations: '[user_id+seance_id+notion_id], user_id',
      flashcards: '[user_id+id], user_id, next_review',
    })
  }
}

export const db = new MosProDB()

// Gestion de session : déconnexion après 20 min d'inactivité
// + persistance de session lors des retours navigateur

import { supabase } from './supabase'

const INACTIVITE_MS = 20 * 60 * 1000 // 20 minutes

let timerInactivite: ReturnType<typeof setTimeout> | null = null

function reinitTimer(onExpiration: () => void) {
  if (timerInactivite) clearTimeout(timerInactivite)
  timerInactivite = setTimeout(onExpiration, INACTIVITE_MS)
}

export function demarrerSurveillanceInactivite(onExpiration: () => void) {
  const evenements = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll']
  const handler = () => reinitTimer(onExpiration)
  evenements.forEach(e => window.addEventListener(e, handler, { passive: true }))
  reinitTimer(onExpiration)
  return () => {
    if (timerInactivite) clearTimeout(timerInactivite)
    evenements.forEach(e => window.removeEventListener(e, handler))
  }
}

// Vérifie si la session est encore valide (pour les retours navigateur)
export async function verifierSession(): Promise<{ valide: boolean; role: string | null }> {
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) return { valide: false, role: null }

  // Vérifier le rôle
  const { data: profil } = await supabase
    .from('demandes_inscription')
    .select('statut')
    .eq('user_id', session.user.id)
    .single()

  if (profil) return { valide: true, role: 'etudiant' }

  // Peut-être enseignant
  const { data: ens } = await supabase
    .from('enseignants')
    .select('id')
    .eq('user_id', session.user.id)
    .single()

  if (ens) return { valide: true, role: 'enseignant' }

  return { valide: true, role: 'etudiant' } // fallback
}

export async function deconnecter() {
  if (timerInactivite) clearTimeout(timerInactivite)
  await supabase.auth.signOut()
}

// MOS Pro P3 — Définition des routes
// Phase 0 — Toutes les routes identifiées avant d'écrire les pages

/*
  Structure des routes :

  /                              → Page d'accueil (double portail)
  /etudiant/connexion            → Connexion espace étudiant
  /enseignant/connexion          → Connexion espace enseignant

  ── ESPACE ÉTUDIANT ─────────────────────────────────────────────────
  /etudiant                      → Accueil étudiant (4 pavés + progression)
  /etudiant/theme/:themeId       → Liste des séances d'un thème
  /etudiant/seance/:seanceId     → Page séance (6 onglets)
  /etudiant/seance/:seanceId/capsule     → Onglet 1 — Capsule distancielle
  /etudiant/seance/:seanceId/fiche       → Onglet 2 — Fiche ressource
  /etudiant/seance/:seanceId/presentiel  → Onglet 3 — Cours en présentiel
  /etudiant/seance/:seanceId/activites   → Onglet 4 — Activités
  /etudiant/seance/:seanceId/travaux     → Onglet 5 — Travaux à rendre
  /etudiant/seance/:seanceId/journal     → Onglet 6 — Journal de bord
  /etudiant/messagerie           → Messagerie étudiant

  ── ESPACE ENSEIGNANT ───────────────────────────────────────────────
  /enseignant                    → Tableau de bord enseignant
  /enseignant/etudiants          → Liste des étudiants
  /enseignant/etudiant/:userId   → Suivi individuel d'un étudiant
  /enseignant/devoirs            → Travaux à rendre (tous étudiants)
  /enseignant/devoirs/:devoirId  → Correction d'un devoir
  /enseignant/deverrouillage     → Gestion des déverrouillages
  /enseignant/messagerie         → Messagerie enseignant
  /enseignant/exports            → Exports PDF

  ── ERREURS ─────────────────────────────────────────────────────────
  *                              → Page 404
*/

export const ROUTES = {
  // Accueil
  accueil: '/',
  connexionEtudiant:    '/etudiant/connexion',
  connexionEnseignant:  '/enseignant/connexion',

  // Espace étudiant
  etudiantAccueil:      '/etudiant',
  etudiantTheme:        (themeId: string) => `/etudiant/theme/${themeId}`,
  etudiantSeance:       (seanceId: string) => `/etudiant/seance/${seanceId}`,
  etudiantOnglet:       (seanceId: string, onglet: string) => `/etudiant/seance/${seanceId}/${onglet}`,
  etudiantMessagerie:   '/etudiant/messagerie',

  // Espace enseignant
  enseignantAccueil:    '/enseignant',
  enseignantEtudiants:  '/enseignant/etudiants',
  enseignantEtudiant:   (userId: string) => `/enseignant/etudiant/${userId}`,
  enseignantDevoirs:    '/enseignant/devoirs',
  enseignantDevoir:     (devoirId: string) => `/enseignant/devoirs/${devoirId}`,
  enseignantDeverrouillage: '/enseignant/deverrouillage',
  enseignantMessagerie: '/enseignant/messagerie',
  enseignantExports:    '/enseignant/exports',
} as const

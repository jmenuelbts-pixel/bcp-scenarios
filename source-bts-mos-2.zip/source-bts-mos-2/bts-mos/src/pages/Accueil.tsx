import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useState } from 'react'

export default function Accueil() {
  const navigate = useNavigate()
  const [showApropos, setShowApropos] = useState(false)

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#FFFBEB', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>

      {/* Bouton À propos */}
      <button onClick={() => setShowApropos(true)}
        style={{ position: 'fixed', top: '1rem', left: '1rem', background: 'none', border: '1.5px solid #FCD34D', borderRadius: '8px', padding: '0.4rem 0.75rem', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', color: '#92400E', fontFamily: 'Arial', backgroundColor: '#FEF3C7' }}>
        <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>
        </svg>
        À propos
      </button>

      {/* Modal À propos */}
      <AnimatePresence>
        {showApropos && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.4)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem' }}
            onClick={() => setShowApropos(false)}>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
              onClick={e => e.stopPropagation()}
              style={{ backgroundColor: '#FFFFFF', borderRadius: '14px', padding: '2rem', maxWidth: '480px', width: '100%' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.25rem' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: '700', color: '#92400E', margin: 0 }}>MOS Pro P3</h2>
                <button onClick={() => setShowApropos(false)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF', fontSize: '1.25rem', lineHeight: 1, padding: '0.25rem' }}>
                  &times;
                </button>
              </div>
              <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.7', margin: '0 0 0.875rem 0' }}>
                MOS Pro P3 est une application pédagogique développée pour les étudiants en BTS Management Opérationnel de la Sécurité, Pôle 3 — Unité U52, en formation par alternance.
              </p>
              <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.7', margin: '0 0 0.875rem 0' }}>
                Elle permet à chaque étudiant de suivre son parcours séance par séance : capsules distancielles, fiches ressource, activités, travaux à rendre et journal de bord. L'enseignant dispose d'un espace dédié pour suivre la progression de chaque étudiant, corriger les devoirs, échanger par messagerie et déverrouiller les contenus.
              </p>
              <div style={{ borderTop: '1px solid #E5E7EB', paddingTop: '1rem' }}>
                <div style={{ fontSize: '0.875rem', fontWeight: '700', color: '#111827' }}>Jacky MENUEL</div>
                <div style={{ fontSize: '0.8rem', color: '#6B7280', marginTop: '0.15rem' }}>Professeur d'Économie-Gestion</div>
                <div style={{ fontSize: '0.8rem', color: '#6B7280' }}>Lycée Maria Deraismes — Paris 17e</div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Logo + titre */}
      <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        style={{ textAlign: 'center', marginBottom: '2rem' }}>
        {/* Icône bouclier */}
        <div style={{ width: '72px', height: '72px', borderRadius: '18px', backgroundColor: '#F59E0B', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
          <svg width="44" height="48" viewBox="0 0 44 48" fill="none">
            <path d="M22 2L4 10V24C4 34 12 43 22 46C32 43 40 34 40 24V10L22 2Z" fill="rgba(255,255,255,0.2)" stroke="white" strokeWidth="1.5"/>
            <text x="22" y="24" textAnchor="middle" fill="white" fontSize="15" fontWeight="500" fontFamily="Arial">M</text>
            <text x="22" y="37" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="11" fontWeight="500" fontFamily="Arial">P3</text>
          </svg>
        </div>
        <h1 style={{ fontSize: '1.625rem', fontWeight: '700', color: '#92400E', margin: '0 0 0.3rem 0', letterSpacing: '-0.01em' }}>
          MOS Pro P3
        </h1>
        <p style={{ fontSize: '0.875rem', color: '#B45309', margin: 0 }}>
          Gestion de la relation client
        </p>
      </motion.div>

      {/* Portails */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem', width: '100%', maxWidth: '380px' }}>
        <motion.button
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/etudiant/connexion')}
          style={{ backgroundColor: '#F59E0B', color: '#FFFFFF', border: 'none', borderRadius: '14px', padding: '1.25rem 1.5rem', cursor: 'pointer', textAlign: 'left', width: '100%', fontFamily: 'Arial' }}>
          <div style={{ fontSize: '0.7rem', fontWeight: '700', letterSpacing: '0.08em', opacity: 0.85, marginBottom: '0.2rem', textTransform: 'uppercase' }}>Espace</div>
          <div style={{ fontSize: '1.25rem', fontWeight: '700' }}>Étudiant</div>
        </motion.button>

        <motion.button
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/enseignant/connexion')}
          style={{ backgroundColor: '#FFFFFF', color: '#92400E', border: '1.5px solid #FCD34D', borderRadius: '14px', padding: '1.25rem 1.5rem', cursor: 'pointer', textAlign: 'left', width: '100%', fontFamily: 'Arial' }}>
          <div style={{ fontSize: '0.7rem', fontWeight: '700', letterSpacing: '0.08em', opacity: 0.7, marginBottom: '0.2rem', textTransform: 'uppercase' }}>Espace</div>
          <div style={{ fontSize: '1.25rem', fontWeight: '700' }}>Enseignant</div>
        </motion.button>
      </div>

      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
        style={{ marginTop: '1.75rem', fontSize: '0.7rem', color: '#D97706' }}>
        Lycée Maria Deraismes · Paris 17e · U52 coef. 5
      </motion.p>
    </div>
  )
}

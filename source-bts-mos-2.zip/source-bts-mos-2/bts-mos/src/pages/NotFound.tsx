import { useNavigate } from 'react-router-dom'

export default function NotFound() {
  const navigate = useNavigate()
  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: 'Arial', padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '3rem', fontWeight: '700', color: '#D1D5DB', margin: '0 0 0.5rem 0' }}>404</h1>
      <p style={{ color: '#6B7280', marginBottom: '1.5rem' }}>Page introuvable.</p>
      <button onClick={() => navigate('/')} style={{ backgroundColor: '#111827', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.75rem 1.5rem', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px' }}>
        Retour a l'accueil
      </button>
    </div>
  )
}

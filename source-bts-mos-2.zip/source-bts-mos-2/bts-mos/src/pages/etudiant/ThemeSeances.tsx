import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { THEMES, SEANCES } from '../../data/schema'
import { supabase } from '../../lib/supabase'
import Header from '../../components/ui/Header'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'
import BarreProgression from '../../components/ui/BarreProgression'

export default function ThemeSeances() {
  const navigate = useNavigate()
  const { themeId } = useParams<{ themeId: string }>()
  const theme = THEMES.find(t => t.id === themeId)
  const seances = SEANCES.filter(s => s.theme_id === themeId)
  const [seancesOuvertes, setSeancesOuvertes] = useState<Set<string>>(new Set())
  const [chargement, setChargement] = useState(true)

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const navigate_inner = (url: string) => { window.location.href = url }
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate_inner('/etudiant/connexion')
    })
    return stop
  }, [])
useEffect(() => {
    const charger = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      const userId = user?.id ?? null
      const { data } = await supabase
        .from('deverrouillages')
        .select('seance_id, user_id, ferme_a')
        .is('ferme_a', null)
      const ouvertes = new Set<string>()
      ;(data ?? []).forEach((d: { seance_id: string; user_id: string; ferme_a: string | null }) => {
        if (d.user_id === 'all' || d.user_id === userId) ouvertes.add(d.seance_id)
      })
      setSeancesOuvertes(ouvertes)
      setChargement(false)
    }
    charger()
  }, [])

  if (!theme) return <div style={{ padding: '2rem', fontFamily: 'Arial' }}>Thème introuvable.</div>

  const ouvertesTheme = seances.filter(s => seancesOuvertes.has(s.id)).length
  const progression = seances.length > 0 ? Math.round((ouvertesTheme / seances.length) * 100) : 0

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <Header retourVers="/etudiant" messagerieVers="/etudiant/messagerie" couleurFond="#FFFFFF" />
      <BandeauHorsLigne />

      <div style={{ backgroundColor: theme.couleur, padding: '1.25rem 1rem' }}>
        <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '0.7rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.25rem 0' }}>
          Thème {theme.numero}
        </p>
        <h1 style={{ color: '#FFFFFF', fontSize: '1.125rem', fontWeight: '700', margin: '0 0 0.75rem 0', lineHeight: '1.3' }}>
          {theme.titre}
        </h1>
        <BarreProgression valeur={progression} couleur="rgba(255,255,255,0.9)" hauteur="6px" />
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.75rem', margin: '0.4rem 0 0 0' }}>
          {chargement ? '...' : `${ouvertesTheme} / ${seances.length} séances accessibles`}
        </p>
      </div>

      <main style={{ padding: '1rem', maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {seances.map((seance, i) => {
            const ouverte = seancesOuvertes.has(seance.id)
            return (
              <motion.button
                key={seance.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.06 }}
                whileTap={{ scale: ouverte ? 0.98 : 1 }}
                disabled={!ouverte && !chargement}
                onClick={() => {
                  if (!ouverte) return
                  navigate(seance.type === 'evaluation' ? `/etudiant/evaluation/${seance.id}` : `/etudiant/seance/${seance.id}`)
                }}
                style={{
                  backgroundColor: ouverte ? '#FFFFFF' : '#F9FAFB',
                  border: `1px solid ${ouverte ? '#E5E7EB' : '#E5E7EB'}`,
                  borderRadius: '10px',
                  padding: '1rem',
                  cursor: ouverte ? 'pointer' : 'default',
                  textAlign: 'left',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem',
                  minHeight: '44px',
                  fontFamily: 'Arial',
                  opacity: chargement ? 0.7 : 1,
                }}
              >
                {/* Numéro */}
                <div style={{
                  backgroundColor: ouverte ? theme.couleur : '#D1D5DB',
                  color: '#FFFFFF',
                  borderRadius: '50%',
                  width: '36px',
                  height: '36px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '0.875rem',
                  fontWeight: '700',
                  flexShrink: 0,
                }}>
                  {seance.numero}
                </div>

                {/* Titre */}
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: '600', color: ouverte ? '#111827' : '#9CA3AF', lineHeight: '1.35' }}>
                    {seance.titre}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: ouverte ? '#059669' : '#D1D5DB', marginTop: '0.2rem' }}>
                    {chargement ? '...' : ouverte ? 'Accessible' : 'Verrouillée'}
                  </div>
                </div>

                {/* Icône */}
                {ouverte
                  ? <svg width="16" height="16" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                  : <svg width="16" height="16" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                }
              </motion.button>
            )
          })}
        </div>
      </main>
    </div>
  )
}

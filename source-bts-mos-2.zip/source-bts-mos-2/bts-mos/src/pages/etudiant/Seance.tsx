import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { SEANCES, ONGLETS } from '../../data/schema'
import type { OngletId } from '../../data/schema'
import { supabase } from '../../lib/supabase'
import { marquerOngletVisite } from '../../lib/progression'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'
import OngletCapsule from '../../components/capsule/OngletCapsule'
import OngletFiche from '../../components/capsule/OngletFiche'
import OngletPresentiel from '../../components/capsule/OngletPresentiel'
import OngletActivites from '../../components/activities/OngletActivites'
import OngletTravaux from '../../components/capsule/OngletTravaux'
import OngletJournal from '../../components/capsule/OngletJournal'
import { getContenuSeance } from '../../data/contenus'

export default function Seance() {
  const navigate = useNavigate()
  const { seanceId, onglet } = useParams<{ seanceId: string; onglet?: string }>()
  const seance = SEANCES.find(s => s.id === seanceId)
  const ongletActif: OngletId = (onglet as OngletId) ?? 'capsule'
  const contenu = seanceId ? getContenuSeance(seanceId) : undefined

  // Enregistrer la visite de l'onglet
  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const navigate_inner = (url: string) => { window.location.href = url }
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate_inner('/etudiant/connexion')
    })
    return stop
  }, [])
useEffect(() => {
    const enregistrer = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user || !seanceId) return
      await marquerOngletVisite(user.id, seanceId, ongletActif)
    }
    enregistrer()
  }, [seanceId, ongletActif])

  if (!seance) return <div style={{ padding: '2rem', fontFamily: 'Arial' }}>Séance introuvable.</div>

  const renderOnglet = () => {
    if (!contenu) return (
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.5rem', border: '1px solid #D1D5DB', textAlign: 'center', color: '#9CA3AF', fontSize: '0.875rem' }}>
        Contenu non disponible pour cette séance.
      </div>
    )
    switch (ongletActif) {
      case 'capsule':    return <OngletCapsule capsule={contenu.capsule} couleur={seance.couleur} seanceId={seance.id} />
      case 'fiche':      return <OngletFiche fiche={contenu.fiche_ressource} couleur={seance.couleur} seanceId={seance.id} />
      case 'presentiel': return <OngletPresentiel cours={contenu.cours_presentiel} couleur={seance.couleur} seanceId={seance.id} />
      case 'activites':  return <OngletActivites activites={contenu.activites} couleur={seance.couleur} seanceId={seance.id} />
      case 'travaux':    return <OngletTravaux travail={contenu.travail_a_rendre} couleur={seance.couleur} seanceId={seance.id} />
      case 'journal':    return <OngletJournal couleur={seance.couleur} seanceId={seance.id} />
      default:           return null
    }
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <header style={{ backgroundColor: '#FFFFFF', borderBottom: '1px solid #D1D5DB', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate(`/etudiant/theme/${seance.theme_id}`)}
          style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <button onClick={() => navigate('/etudiant')}
          style={{ background: 'none', border: 'none', fontWeight: '700', fontSize: '0.875rem', color: '#111827', cursor: 'pointer', minHeight: '44px', fontFamily: 'Arial' }}>
          Accueil
        </button>
        <button onClick={() => navigate('/etudiant/messagerie')}
          style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: '44px', minWidth: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="22" height="22" fill="none" stroke="#374151" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </button>
      </header>

      <BandeauHorsLigne />

      <div style={{ backgroundColor: seance.couleur, padding: '0.875rem 1.25rem' }}>
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.7rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.2rem 0' }}>
          Séance {seance.numero}
        </p>
        <h1 style={{ color: '#FFFFFF', fontSize: '1rem', fontWeight: '700', margin: 0, lineHeight: '1.35' }}>
          {seance.titre}
        </h1>
      </div>

      {/* Onglets */}
      <div style={{ backgroundColor: '#FFFFFF', borderBottom: '1px solid #E5E7EB', overflowX: 'auto', display: 'flex' }}>
        {ONGLETS.map(o => (
          <button key={o.id} onClick={() => navigate(`/etudiant/seance/${seanceId}/${o.id}`)}
            style={{ padding: '0.75rem 1rem', border: 'none', borderBottom: `2px solid ${ongletActif === o.id ? seance.couleur : 'transparent'}`, backgroundColor: 'transparent', color: ongletActif === o.id ? seance.couleur : '#6B7280', fontWeight: ongletActif === o.id ? '700' : '400', fontSize: '0.8rem', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'Arial', minHeight: '44px' }}>
            {o.label}
          </button>
        ))}
      </div>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        {renderOnglet()}
      </main>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { supabase } from '../../lib/supabase'
import { ACTIVITES_BLOC3, COMPETENCES } from '../../data/competences'
import Header from '../../components/ui/Header'

interface ScoreCompetence {
  id: string
  competence_id: string
  seance_id: string
  points_obtenus: number
  points_max: number
  niveau_auto: string
  niveau_manuel: string | null
  created_at: string
}

const NIVEAUX = ['novice', 'debrouille', 'averti', 'expert'] as const
type Niveau = typeof NIVEAUX[number]

const LABELS: Record<Niveau, string> = {
  novice: 'Novice', debrouille: 'Débrouillé', averti: 'Averti', expert: 'Expert',
}
const COULEURS: Record<Niveau, { bg: string; texte: string; bordure: string }> = {
  novice:     { bg: '#FEE2E2', texte: '#DC2626', bordure: '#FECACA' },
  debrouille: { bg: '#FEF3C7', texte: '#D97706', bordure: '#FDE68A' },
  averti:     { bg: '#DCFCE7', texte: '#16A34A', bordure: '#86EFAC' },
  expert:     { bg: '#14532D20', texte: '#15803D', bordure: '#16A34A' },
}
const ICONES: Record<Niveau, string> = {
  novice: '○', debrouille: '◔', averti: '◑', expert: '●',
}

function niveauEffectif(scores: ScoreCompetence[]): Niveau | null {
  if (scores.length === 0) return null
  // Si ajustement manuel sur le dernier score, on le prend
  const dernierManuel = [...scores].reverse().find(s => s.niveau_manuel)
  if (dernierManuel) return dernierManuel.niveau_manuel as Niveau
  // Sinon meilleur niveau auto
  const ordre: Niveau[] = ['novice', 'debrouille', 'averti', 'expert']
  let meilleur: Niveau = 'novice'
  for (const s of scores) {
    const n = s.niveau_auto as Niveau
    if (ordre.indexOf(n) > ordre.indexOf(meilleur)) meilleur = n
  }
  return meilleur
}

export default function MesCompetences() {
  const navigate = useNavigate()
  const [scores, setScores] = useState<ScoreCompetence[]>([])
  const [chargement, setChargement] = useState(true)

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/etudiant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => {
    const charger = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { navigate('/etudiant/connexion'); return }
      const { data } = await supabase
        .from('scores_competences')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true })
      setScores((data ?? []) as ScoreCompetence[])
      setChargement(false)
    }
    charger()
  }, [navigate])

  const scoresPourComp = (compId: string) => scores.filter(s => s.competence_id === compId)

  const atteintes = COMPETENCES.filter(c => {
    const n = niveauEffectif(scoresPourComp(c.id))
    return n === 'averti' || n === 'expert'
  }).length
  const travaillees = COMPETENCES.filter(c => scoresPourComp(c.id).length > 0).length
  const pct = COMPETENCES.length > 0 ? Math.round((atteintes / COMPETENCES.length) * 100) : 0

  const fmt = (iso: string) => new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit' })

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <Header titre="Mes compétences" messagerieVers="/etudiant/messagerie" />
      <div style={{ backgroundColor: '#C25A00', padding: '0.5rem 1.25rem' }}>
        <button onClick={() => navigate('/etudiant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial', padding: 0 }}>
          &larr; Retour
        </button>
      </div>

      {chargement ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
      ) : (
        <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>

          {/* Récapitulatif */}
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', border: '1px solid #E5E7EB', padding: '1.25rem', marginBottom: '1.5rem' }}>
            <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.75rem' }}>
              Bloc 3 — U52 Gestion de la relation client
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ flex: 1, height: '10px', backgroundColor: '#F3F4F6', borderRadius: '5px', overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${pct}%`, backgroundColor: '#15803D', borderRadius: '5px', transition: 'width 0.5s ease' }} />
              </div>
              <span style={{ fontSize: '1rem', fontWeight: '700', color: '#15803D', flexShrink: 0 }}>{pct}%</span>
            </div>
            <div style={{ display: 'flex', gap: '0.625rem' }}>
              {[
                { label: 'Travaillées', val: travaillees, bg: '#EFF6FF', color: '#1D4ED8' },
                { label: 'Averti/Expert', val: atteintes, bg: '#F0FDF4', color: '#15803D' },
                { label: 'Non travaillées', val: COMPETENCES.length - travaillees, bg: '#F3F4F6', color: '#9CA3AF' },
              ].map(item => (
                <div key={item.label} style={{ flex: 1, textAlign: 'center', backgroundColor: item.bg, borderRadius: '8px', padding: '0.625rem 0.25rem' }}>
                  <div style={{ fontSize: '1.375rem', fontWeight: '700', color: item.color }}>{item.val}</div>
                  <div style={{ fontSize: '0.6rem', color: item.color, fontWeight: '600', lineHeight: '1.3' }}>{item.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Légende niveaux */}
          <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
            {NIVEAUX.map(n => (
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                <span style={{ fontSize: '0.75rem', color: COULEURS[n].texte, fontWeight: '700' }}>{ICONES[n]}</span>
                <span style={{ fontSize: '0.7rem', color: '#6B7280' }}>{LABELS[n]}</span>
              </div>
            ))}
          </div>

          {/* Par activité */}
          {ACTIVITES_BLOC3.map(activite => (
            <div key={activite.id} style={{ marginBottom: '1.5rem' }}>
              <div style={{ fontSize: '0.7rem', fontWeight: '700', color: activite.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem', paddingLeft: '0.25rem' }}>
                {activite.code} — {activite.titre}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
                {activite.competences.map(comp => {
                  const sc = scoresPourComp(comp.id)
                  const niveau = niveauEffectif(sc)
                  const c = niveau ? COULEURS[niveau] : { bg: '#F3F4F6', texte: '#9CA3AF', bordure: '#E5E7EB' }
                  return (
                    <div key={comp.id} style={{ backgroundColor: '#FFFFFF', border: `1px solid ${c.bordure}`, borderLeft: `4px solid ${activite.couleur}`, borderRadius: '8px', overflow: 'hidden' }}>
                      {/* En-tête compétence */}
                      <div style={{ padding: '0.875rem 1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '0.75rem' }}>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '0.65rem', fontWeight: '700', color: activite.couleur, marginBottom: '0.2rem' }}>{comp.code}</div>
                          <div style={{ fontSize: '0.85rem', color: '#111827', lineHeight: '1.5' }}>{comp.libelle}</div>
                        </div>
                        <div style={{ flexShrink: 0, textAlign: 'center' }}>
                          {niveau ? (
                            <span style={{ display: 'inline-block', backgroundColor: c.bg, color: c.texte, fontSize: '0.7rem', fontWeight: '700', padding: '0.25rem 0.625rem', borderRadius: '20px', border: `1px solid ${c.bordure}` }}>
                              {ICONES[niveau]} {LABELS[niveau]}
                            </span>
                          ) : (
                            <span style={{ fontSize: '0.7rem', color: '#9CA3AF' }}>Non évaluée</span>
                          )}
                        </div>
                      </div>

                      {/* Historique évaluations */}
                      {sc.length > 0 && (
                        <div style={{ borderTop: '1px solid #F3F4F6', padding: '0.625rem 1rem', backgroundColor: '#FAFAFA' }}>
                          <div style={{ fontSize: '0.65rem', fontWeight: '700', color: '#6B7280', marginBottom: '0.375rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                            Historique ({sc.length} évaluation{sc.length > 1 ? 's' : ''})
                          </div>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                            {sc.map((s, idx) => {
                              const nAuto = s.niveau_auto as Niveau
                              const nFinal = (s.niveau_manuel ?? s.niveau_auto) as Niveau
                              const pct2 = s.points_max > 0 ? Math.round((s.points_obtenus / s.points_max) * 100) : 0
                              const cf = COULEURS[nFinal] ?? COULEURS.novice
                              return (
                                <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.7rem' }}>
                                  <span style={{ color: '#9CA3AF', flexShrink: 0 }}>#{idx + 1} {fmt(s.created_at)}</span>
                                  <span style={{ color: '#374151', fontWeight: '600' }}>{s.points_obtenus}/{s.points_max} ({pct2}%)</span>
                                  <span style={{ backgroundColor: cf.bg, color: cf.texte, padding: '0.1rem 0.375rem', borderRadius: '4px', fontWeight: '700', flexShrink: 0 }}>
                                    {LABELS[nFinal]}
                                    {s.niveau_manuel && s.niveau_manuel !== nAuto && ' *'}
                                  </span>
                                </div>
                              )
                            })}
                            {sc.some(s => s.niveau_manuel) && (
                              <div style={{ fontSize: '0.6rem', color: '#9CA3AF', marginTop: '0.125rem' }}>* ajusté par l'enseignant</div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          ))}

          <div style={{ marginTop: '1rem', padding: '0.875rem 1rem', backgroundColor: '#EFF6FF', borderRadius: '8px', border: '1px solid #BFDBFE' }}>
            <div style={{ fontSize: '0.75rem', color: '#1E40AF', lineHeight: '1.6' }}>
              Le niveau est calculé automatiquement à partir de vos résultats aux évaluations. Averti ou Expert signifie que la compétence est acquise.
            </div>
          </div>
        </main>
      )}
    </div>
  )
}

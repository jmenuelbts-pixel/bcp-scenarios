import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'

export default function InscriptionEtudiant() {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    nom: '', prenom: '', date_naissance: '', email: '', mdp: '', mdp_confirm: '',
  })
  const [erreur, setErreur] = useState('')
  const [succes, setSucces] = useState(false)
  const [chargement, setChargement] = useState(false)
  const [charteOuverte, setCharteOuverte] = useState(false)
  const [charteScrollee, setCharteScrollee] = useState(false)
  const [charteAcceptee, setCharteAcceptee] = useState(false)

  const set = (champ: string, val: string) => setForm(f => ({ ...f, [champ]: val }))

  const handleInscription = async (e: React.FormEvent) => {
    e.preventDefault()
    setErreur('')

    if (!form.nom || !form.prenom || !form.date_naissance || !form.email || !form.mdp) {
      setErreur('Veuillez remplir tous les champs.'); return
    }
    if (form.mdp !== form.mdp_confirm) {
      setErreur('Les mots de passe ne correspondent pas.'); return
    }
    if (form.mdp.length < 6) {
      setErreur('Le mot de passe doit contenir au moins 6 caractères.'); return
    }

    setChargement(true)

    // Étape 1 : créer le compte Auth
    const { data, error: authError } = await supabase.auth.signUp({
      email: form.email.trim().toLowerCase(),
      password: form.mdp,
      options: {
        emailRedirectTo: undefined,
        data: { role: 'etudiant', statut_compte: 'en_attente' }
      }
    })

    if (authError) {
      setChargement(false)
      if (authError.message.includes('already registered')) {
        setErreur('Cette adresse email est déjà utilisée.')
      } else {
        setErreur('Erreur : ' + authError.message)
      }
      return
    }

    const userId = data.user?.id ?? data.session?.user?.id
    if (!userId) {
      setChargement(false)
      setErreur('Erreur lors de la création du compte. Veuillez réessayer.')
      return
    }

    // Étape 2 : enregistrer la demande avec le bon user_id
    const { error: demandeError } = await supabase
      .from('demandes_inscription')
      .insert({
        user_id: userId,
        nom: form.nom.trim().toUpperCase(),
        prenom: form.prenom.trim(),
        date_naissance: form.date_naissance,
        email: form.email.trim().toLowerCase(),
        statut: 'en_attente',
      })

    setChargement(false)

    if (demandeError) {
      setErreur('Compte créé mais erreur lors de l\'envoi de la demande : ' + demandeError.message)
      return
    }

    // Déconnecter — compte en attente de validation
    await supabase.auth.signOut()
    setSucces(true)
  }

  if (succes) {
    return (
      <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '400px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)', textAlign: 'center' }}>
          <div style={{ width: '48px', height: '48px', backgroundColor: '#D1FAE5', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
            <svg width="24" height="24" fill="none" stroke="#16A34A" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>
          </div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '700', color: '#111827', margin: '0 0 0.75rem 0' }}>Demande envoyée</h2>
          <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 1.5rem 0', lineHeight: '1.5' }}>
            Votre demande a été transmise à votre professeur. Vous pourrez vous connecter dès qu'il l'aura acceptée.
          </p>
          <button onClick={() => navigate('/etudiant/connexion')}
            style={{ backgroundColor: '#C25A00', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem 1.5rem', fontSize: '0.9rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
            Retour à la connexion
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '420px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
        <button onClick={() => navigate('/etudiant/connexion')}
          style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', marginBottom: '1.5rem', padding: 0, minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <h1 style={{ fontSize: '1.4rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0' }}>Créer mon compte</h1>
        <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 1.75rem 0' }}>Votre professeur devra valider votre inscription.</p>

        {erreur && (
          <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '8px', padding: '0.75rem', marginBottom: '1rem', fontSize: '0.875rem', color: '#DC2626' }}>
            {erreur}
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Nom</label>
              <input value={form.nom} onChange={e => set('nom', e.target.value)} placeholder="DUPONT"
                style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Prénom</label>
              <input value={form.prenom} onChange={e => set('prenom', e.target.value)} placeholder="Marie"
                style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Date de naissance</label>
            <input type="date" value={form.date_naissance} onChange={e => set('date_naissance', e.target.value)}
              style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Adresse email</label>
            <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="votre@email.fr"
              style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Mot de passe</label>
            <input type="password" value={form.mdp} onChange={e => set('mdp', e.target.value)} placeholder="6 caractères minimum"
              style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: '#374151', marginBottom: '0.3rem' }}>Confirmer le mot de passe</label>
            <input type="password" value={form.mdp_confirm} onChange={e => set('mdp_confirm', e.target.value)} placeholder="Répétez le mot de passe"
              style={{ width: '100%', padding: '0.7rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.9rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>

          {/* Charte RGPD */}
          <div style={{ marginBottom: '1rem' }}>
            <button onClick={() => { setCharteOuverte(true); setCharteScrollee(false) }}
              style={{ width: '100%', padding: '0.75rem 1rem', backgroundColor: '#FEF3C7', border: '1px solid #FCD34D', borderRadius: '10px', cursor: 'pointer', textAlign: 'left', fontFamily: 'Arial', fontSize: '0.875rem', color: '#92400E', fontWeight: '600', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>Lire la charte de confidentialité (obligatoire)</span>
              <span style={{ fontSize: '1rem' }}>{charteAcceptee ? '✓' : '→'}</span>
            </button>
          </div>

          {/* Modale charte */}
          {charteOuverte && (
            <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
              <div style={{ backgroundColor: '#FFFFFF', borderRadius: '14px', width: '100%', maxWidth: '480px', maxHeight: '80dvh', display: 'flex', flexDirection: 'column' }}>
                {/* En-tête modale */}
                <div style={{ padding: '1.25rem 1.5rem 0.75rem', borderBottom: '1px solid #E5E7EB' }}>
                  <div style={{ fontSize: '1rem', fontWeight: '700', color: '#C25A00' }}>Charte de confidentialité</div>
                  <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: '0.2rem' }}>Faites défiler jusqu'en bas pour accepter</div>
                </div>

                {/* Contenu scrollable */}
                <div
                  onScroll={(e) => {
                    const el = e.currentTarget
                    if (el.scrollHeight - el.scrollTop <= el.clientHeight + 20) {
                      setCharteScrollee(true)
                    }
                  }}
                  style={{ flex: 1, overflowY: 'auto', padding: '1.25rem 1.5rem', fontSize: '0.8rem', color: '#374151', lineHeight: '1.7' }}>
                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>1. Responsable du traitement</p>
                  <p style={{ marginBottom: '1rem' }}>Le traitement des données personnelles est mis en oeuvre par J.M., professeur d'Économie-Gestion, Lycée Maria Deraismes, Paris 17e, dans le cadre de l'enseignement du BTS Management Opérationnel de la Sécurité, Pôle 3 — Unité U52.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>2. Données collectées</p>
                  <p style={{ marginBottom: '1rem' }}>Les données suivantes sont collectées : nom, prénom, adresse email, travaux rendus, progression pédagogique séance par séance, scores aux évaluations, niveau de maîtrise des compétences.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>3. Finalité du traitement</p>
                  <p style={{ marginBottom: '1rem' }}>Ces données sont utilisées exclusivement dans le cadre du suivi pédagogique de la formation BTS MOS, Pôle 3. Elles permettent à l'enseignant de suivre votre progression, corriger vos travaux et vous accompagner tout au long de la formation.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>4. Accès aux données</p>
                  <p style={{ marginBottom: '1rem' }}>Seul l'enseignant responsable a accès à vos données. Elles ne sont pas transmises à des tiers, ne sont pas utilisées à des fins commerciales et ne font l'objet d'aucune cession.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>5. Durée de conservation</p>
                  <p style={{ marginBottom: '1rem' }}>Vos données sont conservées pendant la durée de votre formation. Elles sont supprimées à l'issue de l'année scolaire ou sur demande de votre part.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>6. Vos droits</p>
                  <p style={{ marginBottom: '1rem' }}>Conformément au Règlement Général sur la Protection des Données (RGPD — Règlement UE 2016/679), vous disposez d'un droit d'accès, de rectification et d'effacement de vos données. Pour exercer ces droits, contactez votre enseignant directement via la messagerie de l'application.</p>

                  <p style={{ fontWeight: '700', marginBottom: '0.5rem' }}>7. Sécurité</p>
                  <p style={{ marginBottom: '1.5rem' }}>Les données sont hébergées sur des serveurs sécurisés situés en Europe (Supabase, région eu-west-1). L'accès est protégé par authentification. Aucune donnée n'est stockée localement sur votre appareil.</p>

                  {/* Case à cocher — visible seulement après scroll complet */}
                  {charteScrollee && (
                    <div style={{ borderTop: '1px solid #E5E7EB', paddingTop: '1rem', display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                      <input type="checkbox" id="accepter-charte" checked={charteAcceptee}
                        onChange={e => {
                          setCharteAcceptee(e.target.checked)
                          if (e.target.checked) setTimeout(() => setCharteOuverte(false), 400)
                        }}
                        style={{ width: '18px', height: '18px', marginTop: '2px', cursor: 'pointer', flexShrink: 0, accentColor: '#C25A00' }} />
                      <label htmlFor="accepter-charte" style={{ fontSize: '0.85rem', color: '#111827', cursor: 'pointer', fontWeight: '600', lineHeight: '1.5' }}>
                        J'ai lu et j'accepte la charte de confidentialité. Je comprends que mes données seront utilisées uniquement dans le cadre de mon suivi pédagogique.
                      </label>
                    </div>
                  )}
                </div>

                {/* Pied modale */}
                {!charteScrollee && (
                  <div style={{ padding: '0.875rem 1.5rem', borderTop: '1px solid #E5E7EB', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.75rem', color: '#9CA3AF' }}>Continuez à faire défiler pour lire la charte en entier</div>
                  </div>
                )}
              </div>
            </div>
          )}

          <motion.button whileTap={{ scale: 0.98 }} onClick={handleInscription} disabled={chargement || !charteAcceptee}
            style={{ backgroundColor: (!charteAcceptee || chargement) ? '#D1D5DB' : '#C25A00', color: (!charteAcceptee || chargement) ? '#9CA3AF' : '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '1rem', fontWeight: '600', cursor: (!charteAcceptee || chargement) ? 'not-allowed' : 'pointer', minHeight: '44px', marginTop: '0.25rem', fontFamily: 'Arial', opacity: 1 }}>
            {chargement ? 'Envoi en cours...' : 'Envoyer ma demande'}
          </motion.button>
        </div>
      </motion.div>
    </div>
  )
}

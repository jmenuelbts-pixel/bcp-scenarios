import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuth } from '../../lib/auth'
import { supabase } from '../../lib/supabase'

export default function ConnexionEtudiant() {
  const navigate = useNavigate()
  const { signInEtudiant } = useAuth()
  const [email, setEmail] = useState('')
  const [mdp, setMdp] = useState('')
  const [erreur, setErreur] = useState('')
  const [chargement, setChargement] = useState(false)

  const handleConnexion = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !mdp) { setErreur('Veuillez remplir tous les champs.'); return }
    setChargement(true)
    setErreur('')
    const { error } = await signInEtudiant(email, mdp)
    if (error) { setChargement(false); setErreur(error); return }
    // Vérifier que l'inscription est acceptée
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: demande, error: errDemande } = await supabase
        .from('demandes_inscription')
        .select('statut')
        .eq('user_id', user.id)
        .single()
      if (errDemande || !demande || demande.statut !== 'accepte') {
        await supabase.auth.signOut()
        setChargement(false)
        if (demande?.statut === 'refuse') {
          setErreur("Votre demande d'inscription a été refusée. Contactez votre professeur.")
        } else {
          setErreur('Votre inscription est en attente de validation par votre professeur.')
        }
        return
      }
    }
    setChargement(false)
    navigate('/etudiant')
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '400px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
        <button onClick={() => navigate('/')}
          style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', marginBottom: '1.5rem', padding: 0, minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0' }}>Espace étudiant</h1>
        <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 2rem 0' }}>Connectez-vous à votre compte</p>

        {erreur && (
          <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '8px', padding: '0.75rem', marginBottom: '1rem', fontSize: '0.875rem', color: '#DC2626' }}>
            {erreur}
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.375rem' }}>Adresse email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="votre@email.fr"
              style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '1rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.375rem' }}>Mot de passe</label>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.375rem' }}>
              <label style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>Mot de passe</label>
              <button type="button" onClick={() => navigate('/etudiant/mot-de-passe-oublie')}
                style={{ background: 'none', border: 'none', color: '#C25A00', fontSize: '0.78rem', cursor: 'pointer', fontFamily: 'Arial', padding: 0 }}>
                Mot de passe oublie ?
              </button>
            </div>
            <input type="password" value={mdp} onChange={e => setMdp(e.target.value)} placeholder="••••••••"
              style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '1rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>
          <motion.button whileTap={{ scale: 0.98 }} onClick={handleConnexion} disabled={chargement}
            style={{ backgroundColor: chargement ? '#9CA3AF' : '#C25A00', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '1rem', fontWeight: '600', cursor: chargement ? 'not-allowed' : 'pointer', minHeight: '44px', marginTop: '0.5rem', fontFamily: 'Arial' }}>
            {chargement ? 'Connexion...' : 'Se connecter'}
          </motion.button>
        </div>

        {/* Séparateur */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', margin: '1.5rem 0' }}>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#E5E7EB' }} />
          <span style={{ fontSize: '0.8rem', color: '#9CA3AF' }}>ou</span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#E5E7EB' }} />
        </div>

        {/* Lien inscription */}
        <button onClick={() => navigate('/etudiant/inscription')}
          style={{ width: '100%', backgroundColor: 'transparent', border: '1px solid #D1D5DB', borderRadius: '8px', padding: '0.875rem', fontSize: '0.9rem', fontWeight: '600', color: '#374151', cursor: 'pointer', minHeight: '44px', fontFamily: 'Arial' }}>
          Créer mon compte
        </button>
        <p style={{ textAlign: 'center', fontSize: '0.75rem', color: '#9CA3AF', margin: '0.75rem 0 0 0' }}>
          Votre professeur devra valider votre inscription.
        </p>
      </motion.div>
    </div>
  )
}

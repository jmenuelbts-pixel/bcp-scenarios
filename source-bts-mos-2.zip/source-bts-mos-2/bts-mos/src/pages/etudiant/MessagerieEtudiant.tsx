import { useEffect, useState, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '../../lib/supabase'

interface Message {
  id: string
  expediteur_id: string
  destinataire_id: string
  contenu: string
  lu: boolean
  created_at: string
}

const ENSEIGNANT_ID = 'enseignant'

export default function MessagerieEtudiant() {
  const navigate = useNavigate()
  const [messages, setMessages] = useState<Message[]>([])
  const [nouveau, setNouveau] = useState('')
  const [envoi, setEnvoi] = useState(false)
  const [chargement, setChargement] = useState(true)
  const bassePage = useRef<HTMLDivElement>(null)
  const uidRef = useRef<string | null>(null)

  const charger = useCallback(async (uid: string) => {
    const [{ data: envoyes }, { data: recus }, { data: groupe }] = await Promise.all([
      supabase.from('messages').select('*').eq('expediteur_id', uid).eq('destinataire_id', ENSEIGNANT_ID),
      supabase.from('messages').select('*').eq('expediteur_id', ENSEIGNANT_ID).eq('destinataire_id', uid),
      supabase.from('messages').select('*').eq('expediteur_id', ENSEIGNANT_ID).eq('destinataire_id', 'groupe'),
    ])
    const tous = [...(envoyes ?? []), ...(recus ?? []), ...(groupe ?? [])]
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    setMessages(tous as Message[])
    await supabase.from('messages').update({ lu: true }).eq('destinataire_id', uid).eq('lu', false)
  }, [])

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/etudiant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => {
    let channel: ReturnType<typeof supabase.channel>
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) { navigate('/etudiant/connexion'); return }
      uidRef.current = user.id
      charger(user.id).then(() => setChargement(false))
      channel = supabase.channel('msgs-etudiant')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' },
          () => { if (uidRef.current) charger(uidRef.current) })
        .subscribe()
    })
    return () => { channel?.unsubscribe() }
  }, [charger, navigate])

  useEffect(() => {
    bassePage.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const envoyer = async () => {
    if (!nouveau.trim() || !uidRef.current || envoi) return
    setEnvoi(true)
    const { error } = await supabase.from('messages').insert({
      expediteur_id: uidRef.current,
      destinataire_id: ENSEIGNANT_ID,
      contenu: nouveau.trim(),
      lu: false,
    })
    if (!error) { setNouveau(''); charger(uidRef.current) }
    setEnvoi(false)
  }

  const fmt = (iso: string) => {
    const d = new Date(iso)
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) + ' ' +
      d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', display: 'flex', flexDirection: 'column', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#FFFFFF', borderBottom: '1px solid #D1D5DB', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/etudiant')} style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Accueil</button>
        <span style={{ fontWeight: '700', fontSize: '0.9rem', color: '#111827' }}>Messagerie</span>
        <div style={{ width: '60px' }} />
      </header>

      <main style={{ flex: 1, padding: '1rem', maxWidth: '600px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Chargement...</div>
        ) : messages.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun message. Écrivez à votre professeur.</div>
        ) : (
          <AnimatePresence>
            {messages.map(m => {
              const deMoi = m.expediteur_id === uidRef.current
              return (
                <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  style={{ display: 'flex', flexDirection: 'column', alignItems: deMoi ? 'flex-end' : 'flex-start' }}>
                  <div style={{ backgroundColor: deMoi ? '#C25A00' : '#FFFFFF', color: deMoi ? '#FFFFFF' : '#111827', border: deMoi ? 'none' : '1px solid #E5E7EB', borderRadius: deMoi ? '12px 12px 2px 12px' : '12px 12px 12px 2px', padding: '0.625rem 0.875rem', maxWidth: '80%', fontSize: '0.875rem', lineHeight: '1.5' }}>
                    {!deMoi && <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#1B6B3A', marginBottom: '0.2rem' }}>{m.destinataire_id === 'groupe' ? 'Professeur — groupe' : 'Professeur'}</div>}
                    {m.contenu}
                  </div>
                  <div style={{ fontSize: '0.7rem', color: '#9CA3AF', marginTop: '0.2rem' }}>{fmt(m.created_at)}</div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        )}
        <div ref={bassePage} />
      </main>

      <div style={{ backgroundColor: '#FFFFFF', borderTop: '1px solid #D1D5DB', padding: '0.75rem 1rem', position: 'sticky', bottom: 0 }}>
        <div style={{ maxWidth: '600px', margin: '0 auto', display: 'flex', gap: '0.75rem', alignItems: 'flex-end' }}>
          <textarea value={nouveau} onChange={e => setNouveau(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); envoyer() } }}
            placeholder="Écrire un message..." rows={1}
            style={{ flex: 1, padding: '0.625rem 0.875rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'none', minHeight: '44px', lineHeight: '1.5' }} />
          <motion.button whileTap={{ scale: 0.95 }} onClick={envoyer} disabled={envoi || !nouveau.trim()}
            style={{ backgroundColor: nouveau.trim() ? '#C25A00' : '#D1D5DB', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.625rem 1rem', fontSize: '0.875rem', fontWeight: '600', cursor: nouveau.trim() ? 'pointer' : 'default', minHeight: '44px', fontFamily: 'Arial', flexShrink: 0 }}>
            {envoi ? '...' : 'Envoyer'}
          </motion.button>
        </div>
      </div>
    </div>
  )
}

import { useState, useEffect, useRef } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion, AnimatePresence } from 'framer-motion'
import { getContenuSeance } from '../../data/contenus'

type Mode = 'accueil' | 'sujet' | 'correction'
type AutoEval = 'juste' | 'partiel' | 'retravailler' | null

export default function SeanceEvaluation() {
  const navigate = useNavigate()
  const { seanceId } = useParams<{ seanceId: string }>()
  const contenu = seanceId ? getContenuSeance(seanceId) as any : null

  const [mode, setMode] = useState<Mode>('accueil')
  const [docActif, setDocActif] = useState(0)
  const [partieActive, setPartieActive] = useState(0)
  const [questionActive, setQuestionActive] = useState(0)
  const [reponses, setReponses] = useState<Record<string, string>>({})
  const [reponsesTableau, setReponsesTableau] = useState<Record<string, string>>({})
  const [copieRemise, setCopieRemise] = useState(false)
  const [confirmerRemise, setConfirmerRemise] = useState(false)
  const [correctionOuverte, setCorrectionOuverte] = useState<Record<string, boolean>>({})
  const [autoEval, setAutoEval] = useState<Record<string, AutoEval>>({})
  const [correctionsSaisies, setCorrectionsSaisies] = useState<Record<string, string>>({})
  const [docDrawerOuvert, setDocDrawerOuvert] = useState(false)

  // Chronomètre
  const dureeSecondes = (contenu?.duree_minutes ?? 90) * 60
  const [secondesRestantes, setSecondesRestantes] = useState(dureeSecondes)
  const [chronometre, setChronometre] = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const navigate_inner = (url: string) => { window.location.href = url }
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate_inner('/etudiant/connexion')
    })
    return stop
  }, [])
useEffect(() => {
    if (chronometre && !copieRemise) {
      intervalRef.current = setInterval(() => {
        setSecondesRestantes(s => {
          if (s <= 1) { clearInterval(intervalRef.current!); setCopieRemise(true); return 0 }
          return s - 1
        })
      }, 1000)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [chronometre, copieRemise])

  if (!contenu) return <div style={{ padding: '2rem', fontFamily: 'Arial' }}>Évaluation introuvable.</div>

  const parties = contenu.parties ?? []
  const documents = contenu.documents ?? []
  const partieActuelle = parties[partieActive]
  const questions = partieActuelle?.questions ?? []
  const questionActuelle = questions[questionActive]
  const totalQuestions = parties.reduce((acc: number, p: any) => acc + p.questions.length, 0)
  const numeroGlobal = parties.slice(0, partieActive).reduce((acc: number, p: any) => acc + p.questions.length, 0) + questionActive + 1

  const mm = Math.floor(secondesRestantes / 60).toString().padStart(2, '0')
  const ss = (secondesRestantes % 60).toString().padStart(2, '0')
  const alerteTemps = secondesRestantes <= 900 && secondesRestantes > 0
  const tempsEcoule = secondesRestantes === 0

  const couleurTheme = '#1A56A0'

  const styleHeader = {
    backgroundColor: couleurTheme,
    padding: '0 1rem',
    height: '52px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    position: 'sticky' as const,
    top: 0,
    zIndex: 200,
  }

  const handleRemettrecopie = () => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    setCopieRemise(true)
    setConfirmerRemise(false)
    setMode('correction')
  }

  const setReponse = (id: string, val: string) => {
    if (copieRemise) return
    setReponses(r => ({ ...r, [id]: val }))
  }

  const setTableau = (id: string, ri: number, ci: number, val: string) => {
    if (copieRemise) return
    setReponsesTableau(r => ({ ...r, [`${id}_${ri}_${ci}`]: val }))
  }

  // ===================== ÉCRAN ACCUEIL =====================
  if (mode === 'accueil') return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial' }}>
      <header style={styleHeader}>
        <button onClick={() => navigate('/etudiant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.8)', cursor: 'pointer', fontSize: '0.875rem', fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.875rem' }}>Évaluation formative</span>
        <div style={{ width: '60px' }} />
      </header>

      <div style={{ padding: '2rem 1rem', maxWidth: '600px', margin: '0 auto' }}>
        {/* Badge évaluation */}
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1.5rem' }}>
          <span style={{ backgroundColor: '#FEF3C7', color: '#92400E', borderRadius: '9999px', padding: '0.375rem 1rem', fontSize: '0.8rem', fontWeight: '700', border: '1px solid #FDE68A' }}>
            Évaluation formative — Bilan A3.1
          </span>
        </div>

        <h1 style={{ fontSize: '1.375rem', fontWeight: '700', color: '#111827', textAlign: 'center', margin: '0 0 0.5rem 0' }}>
          {contenu.titre}
        </h1>
        <p style={{ color: '#6B7280', textAlign: 'center', fontSize: '0.875rem', margin: '0 0 2rem 0' }}>
          {contenu.date}
        </p>

        {/* Infos pratiques */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.5rem' }}>
          {[
            { label: 'Durée', valeur: `${contenu.duree_minutes} min` },
            { label: 'Total', valeur: '20 points' },
            { label: 'Documents', valeur: contenu.documents_autorises ? 'Autorisés' : 'Non autorisés' },
            { label: 'Calculatrice', valeur: contenu.calculatrice_autorisee ? 'Autorisée' : 'Non autorisée' },
          ].map((info, i) => (
            <div key={i} style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '0.875rem', textAlign: 'center' }}>
              <p style={{ fontSize: '0.7rem', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em', margin: '0 0 0.25rem 0', fontWeight: '600' }}>{info.label}</p>
              <p style={{ fontSize: '1rem', fontWeight: '700', color: couleurTheme, margin: 0 }}>{info.valeur}</p>
            </div>
          ))}
        </div>

        {/* Barème */}
        <div style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '1.25rem', marginBottom: '1.5rem' }}>
          <p style={{ fontSize: '0.8rem', fontWeight: '700', color: '#374151', margin: '0 0 0.75rem 0', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Barème</p>
          {parties.map((p: any) => (
            <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid #F3F4F6' }}>
              <div>
                <span style={{ fontSize: '0.875rem', fontWeight: '600', color: '#111827' }}>Partie {p.numero}</span>
                <span style={{ fontSize: '0.8rem', color: '#6B7280', marginLeft: '0.5rem' }}>{p.titre}</span>
              </div>
              <span style={{ fontSize: '0.875rem', fontWeight: '700', color: couleurTheme }}>{p.points} pts</span>
            </div>
          ))}
        </div>

        {/* Contexte */}
        <div style={{ backgroundColor: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: '10px', padding: '1.25rem', marginBottom: '2rem' }}>
          <p style={{ fontSize: '0.75rem', fontWeight: '700', color: couleurTheme, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '0 0 0.5rem 0' }}>Contexte</p>
          <p style={{ fontSize: '0.85rem', color: '#1E3A5F', margin: 0, lineHeight: '1.6' }}>{contenu.contexte}</p>
        </div>

        <motion.button whileTap={{ scale: 0.98 }}
          onClick={() => { setMode('sujet'); setChronometre(true) }}
          style={{ width: '100%', backgroundColor: couleurTheme, color: '#FFFFFF', border: 'none', borderRadius: '10px', padding: '1rem', fontSize: '1rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial' }}>
          Commencer l'évaluation
        </motion.button>
      </div>
    </div>
  )

  // ===================== MODE ÉVALUATION =====================
  if (mode === 'sujet') return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial', display: 'flex', flexDirection: 'column' }}>

      {/* Header avec chrono */}
      <header style={{ ...styleHeader, backgroundColor: alerteTemps ? '#DC2626' : tempsEcoule ? '#6B7280' : couleurTheme }}>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.8rem' }}>S5 — Évaluation</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {alerteTemps && <span style={{ color: '#FCA5A5', fontSize: '0.7rem', fontWeight: '600' }}>Temps limité !</span>}
          <span style={{ backgroundColor: 'rgba(255,255,255,0.2)', color: '#FFFFFF', padding: '0.25rem 0.75rem', borderRadius: '9999px', fontSize: '0.9rem', fontWeight: '700', fontFamily: 'monospace' }}>
            {mm}:{ss}
          </span>
        </div>
        <button onClick={() => setConfirmerRemise(true)}
          style={{ background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)', color: '#FFFFFF', borderRadius: '6px', padding: '0.25rem 0.75rem', fontSize: '0.75rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
          Remettre
        </button>
      </header>

      {/* Layout responsive */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* SIDEBAR DESKTOP — documents + plan */}
        <aside style={{ width: '220px', flexShrink: 0, borderRight: '1px solid #E5E7EB', backgroundColor: '#FFFFFF', overflowY: 'auto', display: 'none' }} className="sidebar-desktop">
          <div style={{ padding: '0.75rem' }}>
            <p style={{ fontSize: '0.65rem', fontWeight: '700', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.5rem 0' }}>Dossier</p>
            {documents.map((doc: any, i: number) => (
              <button key={doc.id} onClick={() => setDocActif(i)}
                style={{ width: '100%', textAlign: 'left', padding: '0.5rem 0.625rem', marginBottom: '3px', borderRadius: '6px', border: 'none', backgroundColor: docActif === i ? couleurTheme : '#F9FAFB', color: docActif === i ? '#FFFFFF' : '#374151', fontSize: '0.75rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
                {doc.titre_court} — {doc.titre.replace(/^Doc \d — /, '')}
              </button>
            ))}
            <div style={{ margin: '0.75rem 0', borderTop: '1px solid #E5E7EB' }} />
            <p style={{ fontSize: '0.65rem', fontWeight: '700', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.5rem 0' }}>Questions</p>
            {parties.map((p: any, pi: number) => (
              <div key={p.id} style={{ marginBottom: '0.5rem' }}>
                <p style={{ fontSize: '0.7rem', fontWeight: '700', color: partieActive === pi ? couleurTheme : '#6B7280', margin: '0 0 0.25rem 0' }}>
                  Partie {p.numero} — {p.points} pts
                </p>
                {p.questions.map((q: any, qi: number) => (
                  <button key={q.id} onClick={() => { setPartieActive(pi); setQuestionActive(qi) }}
                    style={{ width: '100%', textAlign: 'left', padding: '0.25rem 0.5rem', borderRadius: '4px', border: 'none', backgroundColor: partieActive === pi && questionActive === qi ? '#EFF6FF' : 'transparent', color: partieActive === pi && questionActive === qi ? couleurTheme : '#6B7280', fontSize: '0.7rem', cursor: 'pointer', fontFamily: 'Arial' }}>
                    Q{q.numero} — {q.points} pt{q.points > 1 ? 's' : ''} {reponses[q.id] || (q.type === 'tableau' && reponsesTableau[`${q.id}_0_1`]) ? '✓' : ''}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </aside>

        {/* CONTENU PRINCIPAL */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* BARRE DOCS MOBILE */}
          <div style={{ backgroundColor: '#FFFFFF', borderBottom: '1px solid #E5E7EB', padding: '0.5rem 0.75rem', display: 'flex', gap: '0.375rem', overflowX: 'auto' }}>
            {documents.map((doc: any, i: number) => (
              <button key={doc.id} onClick={() => { setDocActif(i); setDocDrawerOuvert(true) }}
                style={{ flexShrink: 0, padding: '0.3rem 0.625rem', borderRadius: '6px', border: `1.5px solid ${docActif === i && docDrawerOuvert ? couleurTheme : '#E5E7EB'}`, backgroundColor: docActif === i && docDrawerOuvert ? couleurTheme : '#FAFAFA', color: docActif === i && docDrawerOuvert ? '#FFFFFF' : '#374151', fontSize: '0.75rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial', whiteSpace: 'nowrap' }}>
                {doc.titre_court}
              </button>
            ))}
          </div>

          {/* DRAWER DOCUMENT MOBILE */}
          <AnimatePresence>
            {docDrawerOuvert && (
              <motion.div initial={{ height: 0 }} animate={{ height: '45%' }} exit={{ height: 0 }}
                style={{ overflow: 'hidden', borderBottom: '1px solid #E5E7EB', backgroundColor: '#FFFBEB', flexShrink: 0 }}>
                <div style={{ height: '100%', overflowY: 'auto', padding: '0.75rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#92400E' }}>{documents[docActif]?.titre}</span>
                    <button onClick={() => setDocDrawerOuvert(false)}
                      style={{ background: 'none', border: 'none', fontSize: '1rem', cursor: 'pointer', color: '#6B7280' }}>✕</button>
                  </div>
                  <pre style={{ fontSize: '0.75rem', color: '#374151', lineHeight: '1.6', whiteSpace: 'pre-wrap', fontFamily: 'Arial', margin: 0 }}>
                    {documents[docActif]?.contenu}
                  </pre>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* DOCUMENT + QUESTION CÔTE À CÔTE (DESKTOP) */}
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

            {/* Document actif — desktop uniquement (CSS class) */}
            <div style={{ width: '45%', flexShrink: 0, borderRight: '1px solid #E5E7EB', overflowY: 'auto', padding: '1rem', backgroundColor: '#FFFBEB', display: 'none' }} className="doc-panel-desktop">
              <p style={{ fontSize: '0.7rem', fontWeight: '700', color: '#92400E', textTransform: 'uppercase', letterSpacing: '0.04em', margin: '0 0 0.5rem 0' }}>{documents[docActif]?.titre}</p>
              <pre style={{ fontSize: '0.8rem', color: '#374151', lineHeight: '1.65', whiteSpace: 'pre-wrap', fontFamily: 'Arial', margin: 0 }}>
                {documents[docActif]?.contenu}
              </pre>
            </div>

            {/* Zone question */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '1rem' }}>
              {/* En-tête partie */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.7rem', fontWeight: '700', color: couleurTheme, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Partie {partieActuelle?.numero} — {partieActuelle?.savoirs}
                </span>
                <span style={{ fontSize: '0.7rem', color: '#9CA3AF' }}>Q{numeroGlobal} / {totalQuestions}</span>
              </div>

              {/* Question */}
              {questionActuelle && (
                <div style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '1.25rem', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#111827' }}>Question {questionActuelle.numero}</span>
                    <span style={{ backgroundColor: '#EFF6FF', color: couleurTheme, borderRadius: '9999px', padding: '0.2rem 0.6rem', fontSize: '0.75rem', fontWeight: '700' }}>
                      {questionActuelle.points} pt{questionActuelle.points > 1 ? 's' : ''}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.65', margin: '0 0 1rem 0', whiteSpace: 'pre-line' }}>
                    {questionActuelle.enonce}
                  </p>

                  {/* Zone de réponse selon type */}
                  {questionActuelle.type === 'texte_libre' && (
                    <textarea
                      value={reponses[questionActuelle.id] ?? ''}
                      onChange={e => setReponse(questionActuelle.id, e.target.value)}
                      readOnly={copieRemise}
                      placeholder={copieRemise ? '' : 'Votre réponse...'}
                      style={{ width: '100%', minHeight: '120px', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.6', backgroundColor: copieRemise ? '#F9FAFB' : '#FFFFFF' }}
                    />
                  )}

                  {(questionActuelle.type === 'tableau' || questionActuelle.type === 'tableau_cap') && (() => {
                    const colonnes: string[] = questionActuelle.type === 'tableau_cap'
                      ? ['', 'Votre réponse']
                      : (questionActuelle.colonnes ?? [])
                    const lignes: string[][] = questionActuelle.type === 'tableau_cap'
                      ? (questionActuelle.lignes_cap ?? []).map((l: string) => [l, ''])
                      : (questionActuelle.lignes ?? [])
                    return (
                      <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
                          <thead>
                            <tr>
                              {colonnes.map((col: string, j: number) => (
                                <th key={j} style={{ backgroundColor: couleurTheme, color: '#FFFFFF', padding: '0.5rem 0.625rem', textAlign: 'left', fontWeight: '600', fontSize: '0.75rem' }}>{col}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {lignes.map((ligne: string[], ri: number) => (
                              <tr key={ri} style={{ backgroundColor: ri % 2 === 0 ? '#FAFAFA' : '#FFFFFF' }}>
                                {ligne.map((cell: string, ci: number) => (
                                  <td key={ci} style={{ padding: '0.375rem 0.5rem', border: '1px solid #E5E7EB', verticalAlign: 'top' }}>
                                    {cell === '' ? (
                                      <textarea
                                        value={reponsesTableau[`${questionActuelle.id}_${ri}_${ci}`] ?? ''}
                                        onChange={e => setTableau(questionActuelle.id, ri, ci, e.target.value)}
                                        readOnly={copieRemise}
                                        style={{ width: '100%', minHeight: '52px', padding: '0.375rem', border: '1px solid #D1D5DB', borderRadius: '4px', fontSize: '0.8rem', fontFamily: 'Arial', resize: 'vertical' }}
                                      />
                                    ) : (
                                      <span style={{ fontWeight: ci === 0 ? '600' : '400' }}>{cell}</span>
                                    )}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )
                  })()}
                </div>
              )}

              {/* Navigation questions */}
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {(questionActive > 0 || partieActive > 0) && (
                  <button onClick={() => {
                    if (questionActive > 0) setQuestionActive(q => q - 1)
                    else { setPartieActive(p => p - 1); setQuestionActive(parties[partieActive - 1].questions.length - 1) }
                  }}
                    style={{ padding: '0.625rem 1rem', borderRadius: '8px', border: '1px solid #D1D5DB', backgroundColor: '#FFFFFF', color: '#374151', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial' }}>
                    ← Précédente
                  </button>
                )}
                <div style={{ flex: 1 }} />
                {numeroGlobal < totalQuestions ? (
                  <button onClick={() => {
                    if (questionActive < questions.length - 1) setQuestionActive(q => q + 1)
                    else { setPartieActive(p => p + 1); setQuestionActive(0) }
                  }}
                    style={{ padding: '0.625rem 1rem', borderRadius: '8px', border: 'none', backgroundColor: couleurTheme, color: '#FFFFFF', fontSize: '0.875rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
                    Suivante →
                  </button>
                ) : (
                  <button onClick={() => setConfirmerRemise(true)}
                    style={{ padding: '0.625rem 1.25rem', borderRadius: '8px', border: 'none', backgroundColor: '#16A34A', color: '#FFFFFF', fontSize: '0.875rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial' }}>
                    Remettre ma copie
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal confirmation remise */}
      <AnimatePresence>
        {confirmerRemise && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 500, padding: '1rem' }}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              style={{ backgroundColor: '#FFFFFF', borderRadius: '14px', padding: '2rem', maxWidth: '380px', width: '100%', textAlign: 'center' }}>
              <p style={{ fontSize: '1.125rem', fontWeight: '700', color: '#111827', margin: '0 0 0.5rem 0' }}>Remettre la copie ?</p>
              <p style={{ fontSize: '0.875rem', color: '#6B7280', margin: '0 0 1.5rem 0', lineHeight: '1.5' }}>
                Une fois remise, vous ne pourrez plus modifier vos réponses. Temps restant : {mm}:{ss}.
              </p>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button onClick={() => setConfirmerRemise(false)}
                  style={{ flex: 1, padding: '0.75rem', borderRadius: '8px', border: '1px solid #D1D5DB', backgroundColor: '#F9FAFB', color: '#374151', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial' }}>
                  Annuler
                </button>
                <button onClick={handleRemettrecopie}
                  style={{ flex: 1, padding: '0.75rem', borderRadius: '8px', border: 'none', backgroundColor: '#16A34A', color: '#FFFFFF', fontSize: '0.875rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial' }}>
                  Confirmer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CSS responsive via style tag */}
      <style>{`
        @media (min-width: 768px) {
          .sidebar-desktop { display: block !important; }
          .doc-panel-desktop { display: block !important; }
        }
      `}</style>
    </div>
  )

  // ===================== MODE CORRECTION =====================
  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial' }}>
      <header style={styleHeader}>
        <button onClick={() => navigate('/etudiant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.8)', cursor: 'pointer', fontSize: '0.875rem', fontFamily: 'Arial' }}>
          ← Accueil
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.875rem' }}>Correction — S5</span>
        <div style={{ width: '60px' }} />
      </header>

      <div style={{ padding: '1.25rem 1rem', maxWidth: '760px', margin: '0 auto' }}>
        {/* Bandeau copie remise */}
        <div style={{ backgroundColor: '#D1FAE5', border: '1px solid #6EE7B7', borderRadius: '10px', padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <span style={{ fontSize: '1.25rem' }}>✓</span>
          <div>
            <p style={{ fontSize: '0.875rem', fontWeight: '700', color: '#065F46', margin: 0 }}>Copie remise</p>
            <p style={{ fontSize: '0.8rem', color: '#047857', margin: 0 }}>
              Complétez votre correction ci-dessous pendant la correction collective.
            </p>
          </div>
        </div>

        {parties.map((partie: any) => (
          <div key={partie.id} style={{ marginBottom: '2rem' }}>
            <div style={{ backgroundColor: couleurTheme, borderRadius: '10px 10px 0 0', padding: '0.875rem 1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9375rem' }}>Partie {partie.numero} — {partie.titre}</span>
              <span style={{ backgroundColor: 'rgba(255,255,255,0.2)', color: '#FFFFFF', borderRadius: '9999px', padding: '0.2rem 0.625rem', fontSize: '0.75rem', fontWeight: '700' }}>{partie.points} pts</span>
            </div>

            <div style={{ border: '1px solid #E5E7EB', borderTop: 'none', borderRadius: '0 0 10px 10px', overflow: 'hidden' }}>
              {partie.questions.map((q: any, qi: number) => {
                const estOuvert = correctionOuverte[q.id] !== false
                const maReponse = reponses[q.id] || Object.entries(reponsesTableau).filter(([k]) => k.startsWith(`${q.id}_`)).map(([, v]) => v).filter(Boolean).join(' | ') || '—'
                const eval_ = autoEval[q.id]

                return (
                  <div key={q.id} style={{ borderBottom: qi < partie.questions.length - 1 ? '1px solid #E5E7EB' : 'none', backgroundColor: '#FFFFFF' }}>

                    {/* En-tête question */}
                    <button onClick={() => setCorrectionOuverte(o => ({ ...o, [q.id]: !estOuvert }))}
                      style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Arial', textAlign: 'left' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: '700', color: '#111827' }}>Question {q.numero}</span>
                        <span style={{ fontSize: '0.75rem', color: couleurTheme, fontWeight: '600' }}>{q.points} pt{q.points > 1 ? 's' : ''}</span>
                        {eval_ && (
                          <span style={{
                            fontSize: '0.7rem', fontWeight: '700', borderRadius: '9999px', padding: '0.15rem 0.5rem',
                            backgroundColor: eval_ === 'juste' ? '#D1FAE5' : eval_ === 'partiel' ? '#FEF3C7' : '#FEE2E2',
                            color: eval_ === 'juste' ? '#065F46' : eval_ === 'partiel' ? '#92400E' : '#991B1B',
                          }}>
                            {eval_ === 'juste' ? 'Acquis' : eval_ === 'partiel' ? 'Partiel' : 'À retravailler'}
                          </span>
                        )}
                      </div>
                      <span style={{ color: '#9CA3AF', fontSize: '0.75rem' }}>{estOuvert ? '▲' : '▼'}</span>
                    </button>

                    {estOuvert && (
                      <div style={{ padding: '0 1.25rem 1.25rem' }}>

                        {/* Ma réponse */}
                        <div style={{ backgroundColor: '#F9FAFB', borderRadius: '8px', padding: '0.875rem', marginBottom: '1rem', border: '1px solid #E5E7EB' }}>
                          <p style={{ fontSize: '0.7rem', fontWeight: '700', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.04em', margin: '0 0 0.375rem 0' }}>Ma réponse</p>
                          <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, lineHeight: '1.6', fontStyle: maReponse === '—' ? 'italic' : 'normal' }}>{maReponse}</p>
                        </div>

                        {/* Éléments attendus */}
                        <div style={{ backgroundColor: '#EFF6FF', borderRadius: '8px', padding: '0.875rem', marginBottom: '1rem', border: '1px solid #BFDBFE' }}>
                          <p style={{ fontSize: '0.7rem', fontWeight: '700', color: couleurTheme, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '0 0 0.5rem 0' }}>Éléments attendus</p>
                          <ul style={{ margin: 0, paddingLeft: '1.25rem' }}>
                            {q.corrige.map((point: string, pi: number) => (
                              <li key={pi} style={{ fontSize: '0.85rem', color: '#1E3A5F', lineHeight: '1.6', marginBottom: '0.375rem' }}>{point}</li>
                            ))}
                          </ul>
                        </div>

                        {/* Auto-évaluation */}
                        <div style={{ marginBottom: '1rem' }}>
                          <p style={{ fontSize: '0.75rem', fontWeight: '700', color: '#374151', margin: '0 0 0.5rem 0' }}>Mon auto-évaluation</p>
                          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                            {(['juste', 'partiel', 'retravailler'] as const).map(val => (
                              <button key={val} onClick={() => setAutoEval(a => ({ ...a, [q.id]: val }))}
                                style={{
                                  padding: '0.375rem 0.875rem', borderRadius: '9999px', border: '1.5px solid',
                                  borderColor: eval_ === val ? (val === 'juste' ? '#6EE7B7' : val === 'partiel' ? '#FDE68A' : '#FECACA') : '#E5E7EB',
                                  backgroundColor: eval_ === val ? (val === 'juste' ? '#D1FAE5' : val === 'partiel' ? '#FEF3C7' : '#FEE2E2') : '#FFFFFF',
                                  color: eval_ === val ? (val === 'juste' ? '#065F46' : val === 'partiel' ? '#92400E' : '#991B1B') : '#6B7280',
                                  fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial',
                                }}>
                                {val === 'juste' ? '✓ J\'avais juste' : val === 'partiel' ? '~ Partiellement' : '✗ À retravailler'}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Zone correction saisie */}
                        <div>
                          <p style={{ fontSize: '0.75rem', fontWeight: '700', color: '#374151', margin: '0 0 0.375rem 0' }}>Ma correction (ce que je retiens)</p>
                          <textarea
                            value={correctionsSaisies[q.id] ?? ''}
                            onChange={e => setCorrectionsSaisies(c => ({ ...c, [q.id]: e.target.value }))}
                            placeholder="Notez ici ce que vous retenez de la correction collective..."
                            style={{ width: '100%', minHeight: '80px', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.85rem', fontFamily: 'Arial', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.5' }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

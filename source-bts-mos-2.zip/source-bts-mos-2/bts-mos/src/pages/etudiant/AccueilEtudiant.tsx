import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { THEMES, SEANCES } from '../../data/schema'
import { supabase } from '../../lib/supabase'
import { calcProgressionGlobale } from '../../lib/progression'
import { BADGES_DEF, getBadgesEtudiant, verifierEtAttribuerBadges } from '../../lib/badges'
import Header from '../../components/ui/Header'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import BarreProgression from '../../components/ui/BarreProgression'

export default function AccueilEtudiant() {
  const navigate = useNavigate()
  const [seancesOuvertes, setSeancesOuvertes] = useState<Set<string>>(new Set())
  const [progressions, setProgressions] = useState<{ seance_id: string; onglet: string }[]>([])
  const [badges, setBadges] = useState<{ badge_id: string; obtenu_a: string }[]>([])
  const [nouveauBadge, setNouveauBadge] = useState<string | null>(null)
  const [chargement, setChargement] = useState(true)
  const [prenom, setPrenom] = useState('')

  useEffect(() => {
    const charger = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { navigate('/etudiant/connexion'); return }
      // Vérifier statut inscription
      const { data: dem } = await supabase.from('demandes_inscription').select('statut').eq('user_id', user.id).single()
      if (!dem || dem.statut !== 'accepte') {
        await supabase.auth.signOut()
        navigate('/etudiant/connexion')
        return
      }
      const userId = user?.id ?? null
      // Récupérer le prénom
      const { data: profil } = await supabase.from('demandes_inscription').select('prenom').eq('user_id', userId ?? '').single()
      if (profil) setPrenom(profil.prenom)

      const [{ data: deverr }, { data: prog }] = await Promise.all([
        supabase.from('deverrouillages').select('seance_id, user_id').is('ferme_a', null),
        userId ? supabase.from('progressions').select('seance_id, onglet').eq('user_id', userId) : { data: [] },
      ])

      const ouvertes = new Set<string>()
      ;(deverr ?? []).forEach((d: { seance_id: string; user_id: string }) => {
        if (d.user_id === 'all' || d.user_id === userId) ouvertes.add(d.seance_id)
      })
      setSeancesOuvertes(ouvertes)
      const progs = (prog ?? []) as { seance_id: string; onglet: string }[]
      setProgressions(progs)

      if (userId) {
        const badgesObtenu = await getBadgesEtudiant(userId)
        setBadges(badgesObtenu)
        const nouveaux = await verifierEtAttribuerBadges(userId, progs)
        if (nouveaux.length > 0) {
          setNouveauBadge(nouveaux[0])
          const badgesMaj = await getBadgesEtudiant(userId)
          setBadges(badgesMaj)
          setTimeout(() => setNouveauBadge(null), 4000)
        }
      }
      setChargement(false)
    }
    charger()
  }, [])

  // Déconnexion après 5 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/etudiant/connexion')
    })
    return stop
  }, [navigate])

  const seancesOuvertesArr = Array.from(seancesOuvertes)
  const progressionGlobale = calcProgressionGlobale(progressions, seancesOuvertesArr)
  const badgeNouveau = nouveauBadge ? BADGES_DEF.find(b => b.id === nouveauBadge) : null

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <Header titre="MOS Pro P3" messagerieVers="/etudiant/messagerie" onDeconnecter={async () => { await deconnecter(); navigate('/etudiant/connexion') }} />
      {prenom && (
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          style={{ backgroundColor: '#C25A00', padding: '0.875rem 1.25rem', display: 'flex', justifyContent: 'flex-end' }}>
          <span style={{ fontSize: '1.125rem', fontWeight: '700', color: '#FFFFFF', letterSpacing: '0.01em' }}>
            Bonjour {prenom}
          </span>
        </motion.div>
      )}
      <BandeauHorsLigne />

      {/* Notification nouveau badge */}
      <AnimatePresence>
        {badgeNouveau && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            style={{ position: 'fixed', top: '60px', left: '50%', transform: 'translateX(-50%)', backgroundColor: badgeNouveau.couleur, color: '#FFFFFF', borderRadius: '12px', padding: '0.75rem 1.25rem', zIndex: 200, display: 'flex', alignItems: 'center', gap: '0.75rem', boxShadow: '0 4px 16px rgba(0,0,0,0.15)', maxWidth: '320px', width: '90%' }}>
            <span style={{ fontSize: '1.5rem' }}>{badgeNouveau.icon}</span>
            <div>
              <div style={{ fontSize: '0.75rem', opacity: 0.85 }}>Nouveau badge obtenu !</div>
              <div style={{ fontSize: '0.875rem', fontWeight: '700' }}>{badgeNouveau.label}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main style={{ padding: '1.5rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        <h1 style={{ fontSize: '1.25rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0' }}>Mes thèmes</h1>
        <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 1.5rem 0' }}>BTS MOS — Pôle 3 — Unité U52 — Coefficient 5</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem' }}>
          {THEMES.map((theme, i) => {
            const seancesTheme = SEANCES.filter(s => s.theme_id === theme.id)
            const ouvertesTheme = seancesTheme.filter(s => seancesOuvertes.has(s.id))
            return (
              <motion.button key={theme.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                whileTap={{ scale: 0.97 }} onClick={() => navigate(`/etudiant/theme/${theme.id}`)}
                style={{ backgroundColor: theme.couleur, color: '#FFFFFF', border: 'none', borderRadius: '14px', padding: '1.5rem 1.25rem', cursor: 'pointer', textAlign: 'left', minHeight: '150px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontFamily: 'Arial' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '700', opacity: 0.8, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Thème {theme.numero}</div>
                <div>
                  <div style={{ fontSize: '1rem', fontWeight: '700', lineHeight: '1.3', marginBottom: '0.5rem' }}>{theme.titre}</div>
                  <div style={{ fontSize: '0.7rem', opacity: 0.75, marginTop: '0.3rem' }}>
                    {chargement ? '...' : `${ouvertesTheme.length} / ${seancesTheme.length} séances`}
                  </div>
                </div>
              </motion.button>
            )
          })}
        </div>

        {/* Progression globale */}
        <div style={{ marginTop: '1.5rem', backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '1.25rem', border: '1px solid #D1D5DB' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.9rem', fontWeight: '600', color: '#374151' }}>Progression globale</span>
            <span style={{ fontSize: '0.875rem', fontWeight: '700', color: '#1A56A0' }}>{progressionGlobale}%</span>
          </div>
          <BarreProgression valeur={progressionGlobale} couleur="#1A56A0" />
          <p style={{ fontSize: '0.75rem', color: '#9CA3AF', margin: '0.5rem 0 0 0' }}>
            {seancesOuvertesArr.length} séance{seancesOuvertesArr.length > 1 ? 's' : ''} accessible{seancesOuvertesArr.length > 1 ? 's' : ''}
          </p>
        </div>

        {/* Bouton Mes compétences */}
        <button
          onClick={() => navigate('/etudiant/competences')}
          style={{ width: '100%', marginTop: '1rem', backgroundColor: '#FFFFFF', border: '1px solid #D1D5DB', borderLeft: '4px solid #059669', borderRadius: '12px', padding: '1rem 1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', fontFamily: 'Arial', textAlign: 'left' }}>
          <div>
            <div style={{ fontSize: '0.9rem', fontWeight: '700', color: '#059669', marginBottom: '0.2rem' }}>Mes compétences</div>
            <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>Bloc 3 -- U52 Gestion de la relation client</div>
          </div>
          <span style={{ fontSize: '1.25rem', color: '#059669' }}>&rarr;</span>
        </button>

        {/* Badges */}
        {badges.length > 0 && (
          <div style={{ marginTop: '1rem', backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '1.25rem', border: '1px solid #D1D5DB' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.75rem' }}>
              Mes badges ({badges.length})
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              {badges.map(b => {
                const def = BADGES_DEF.find(d => d.id === b.badge_id)
                if (!def) return null
                return (
                  <div key={b.badge_id} title={def.desc}
                    style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem', minWidth: '56px' }}>
                    <div style={{ width: '44px', height: '44px', borderRadius: '50%', backgroundColor: def.couleur + '20', border: `2px solid ${def.couleur}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.25rem' }}>
                      {def.icon}
                    </div>
                    <span style={{ fontSize: '0.65rem', color: '#6B7280', textAlign: 'center', lineHeight: '1.2' }}>{def.label}</span>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'

export default function MotDePasseOublie() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [statut, setStatut] = useState<'idle' | 'envoye' | 'erreur'>('idle')
  const [chargement, setChargement] = useState(false)
  const [message, setMessage] = useState('')

  const handleEnvoi = async () => {
    if (!email.trim()) { setMessage('Saisissez votre adresse email.'); setStatut('erreur'); return }
    setChargement(true)
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
      redirectTo: `${window.location.origin}/etudiant/nouveau-mot-de-passe`,
    })
    setChargement(false)
    if (error) {
      setMessage('Erreur : ' + error.message)
      setStatut('erreur')
    } else {
      setStatut('envoye')
    }
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '400px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
        <button onClick={() => navigate('/etudiant/connexion')}
          style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', marginBottom: '1.5rem', padding: 0, fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <h1 style={{ fontSize: '1.4rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0' }}>Mot de passe oublie</h1>
        <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 1.75rem 0' }}>
          Saisissez votre adresse email. Vous recevrez un lien pour reinitialiser votre mot de passe.
        </p>

        {statut === 'envoye' ? (
          <div style={{ backgroundColor: '#D1FAE5', border: '1px solid #6EE7B7', borderRadius: '8px', padding: '1rem', textAlign: 'center' }}>
            <p style={{ color: '#065F46', fontWeight: '600', margin: '0 0 0.5rem 0', fontSize: '0.9rem' }}>Email envoye</p>
            <p style={{ color: '#065F46', fontSize: '0.8rem', margin: 0 }}>
              Verifiez votre boite mail et cliquez sur le lien pour reinitialiser votre mot de passe.
            </p>
          </div>
        ) : (
          <>
            {statut === 'erreur' && (
              <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '8px', padding: '0.75rem', marginBottom: '1rem', fontSize: '0.875rem', color: '#DC2626' }}>
                {message}
              </div>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.375rem' }}>
                  Adresse email
                </label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="votre@email.fr"
                  onKeyDown={e => e.key === 'Enter' && handleEnvoi()}
                  style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '1rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
              </div>
              <button onClick={handleEnvoi} disabled={chargement}
                style={{ backgroundColor: chargement ? '#9CA3AF' : '#C25A00', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '1rem', fontWeight: '600', cursor: chargement ? 'not-allowed' : 'pointer', minHeight: '44px', fontFamily: 'Arial' }}>
                {chargement ? 'Envoi...' : 'Envoyer le lien'}
              </button>
            </div>
          </>
        )}
      </motion.div>
    </div>
  )
}

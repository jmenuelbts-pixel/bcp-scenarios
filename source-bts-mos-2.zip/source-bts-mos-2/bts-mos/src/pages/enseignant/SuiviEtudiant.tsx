import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { supabase } from '../../lib/supabase'
import { SEANCES, THEMES } from '../../data/schema'
import { calcProgressionSeance } from '../../lib/progression'
import { ACTIVITES_BLOC3, COMPETENCES } from '../../data/competences'

interface InfoEtudiant { nom: string; prenom: string; email: string }

interface ScoreComp {
  id: string
  competence_id: string
  seance_id: string
  points_obtenus: number
  points_max: number
  niveau_auto: string
  niveau_manuel: string | null
  created_at: string
}

type NivComp = 'novice' | 'debrouille' | 'averti' | 'expert'
const NIVEAUX_LABELS: Record<NivComp, string> = { novice: 'Novice', debrouille: 'Débrouillé', averti: 'Averti', expert: 'Expert' }
const NIVEAUX_COULEURS: Record<NivComp, { bg: string; texte: string; bordure: string }> = {
  novice:     { bg: '#FEE2E2', texte: '#DC2626', bordure: '#FECACA' },
  debrouille: { bg: '#FEF3C7', texte: '#D97706', bordure: '#FDE68A' },
  averti:     { bg: '#DCFCE7', texte: '#16A34A', bordure: '#86EFAC' },
  expert:     { bg: '#F0FDF4', texte: '#15803D', bordure: '#16A34A' },
}
const NIVEAUX_ICONES: Record<NivComp, string> = { novice: '○', debrouille: '◔', averti: '◑', expert: '●' }
const ORDRE_NIVEAUX: NivComp[] = ['novice', 'debrouille', 'averti', 'expert']

function niveauEffectif(scoresComp: ScoreComp[]): NivComp | null {
  if (scoresComp.length === 0) return null
  const dernierManuel = [...scoresComp].reverse().find(s => s.niveau_manuel)
  if (dernierManuel) return dernierManuel.niveau_manuel as NivComp
  let meilleur: NivComp = 'novice'
  for (const s of scoresComp) {
    const n = s.niveau_auto as NivComp
    if (ORDRE_NIVEAUX.indexOf(n) > ORDRE_NIVEAUX.indexOf(meilleur)) meilleur = n
  }
  return meilleur
}

export default function SuiviEtudiant() {
  const navigate = useNavigate()
  const { etudiantId } = useParams<{ etudiantId: string }>()
  const [info, setInfo] = useState<InfoEtudiant | null>(null)
  const [progressions, setProgressions] = useState<{ seance_id: string; onglet: string }[]>([])
  const [devoirs, setDevoirs] = useState<{ seance_id: string; statut: string; remis_at: string }[]>([])
  const [chargement, setChargement] = useState(true)
  const [ongletActif, setOngletActif] = useState<'progression' | 'competences'>('progression')
  const [scores, setScores] = useState<ScoreComp[]>([])
  const [ajustement, setAjustement] = useState<{ compId: string; niveau: string } | null>(null)
  const [sauvAjust, setSauvAjust] = useState(false)
  const [suppression, setSuppression] = useState(false)
  const [msgSuppr, setMsgSuppr] = useState<string | null>(null)

  const supprimerDonnees = async (type: 'tout' | 'devoirs' | 'journal' | 'progressions' | 'messages' | 'badges') => {
    if (!etudiantId) return
    const labels: Record<string, string> = {
      tout: 'TOUTES les données', devoirs: 'les devoirs', journal: 'le journal de bord',
      progressions: 'la progression', messages: 'les messages', badges: 'les badges'
    }
    if (!confirm(`Supprimer définitivement ${labels[type]} de cet étudiant ?`)) return
    setSuppression(true)
    if (type === 'tout' || type === 'devoirs') await supabase.from('devoirs').delete().eq('user_id', etudiantId)
    if (type === 'tout' || type === 'journal') await supabase.from('journal_bord').delete().eq('user_id', etudiantId)
    if (type === 'tout' || type === 'progressions') await supabase.from('progressions').delete().eq('user_id', etudiantId)
    if (type === 'tout' || type === 'messages') await supabase.from('messages').delete().eq('expediteur_id', etudiantId)
    if (type === 'tout' || type === 'badges') await supabase.from('badges').delete().eq('user_id', etudiantId)
    setSuppression(false)
    setMsgSuppr(`${labels[type].charAt(0).toUpperCase() + labels[type].slice(1)} supprimé(es).`)
    setTimeout(() => setMsgSuppr(null), 3000)
    // Recharger
    const [{ data: progs }, { data: dev }] = await Promise.all([
      supabase.from('progressions').select('seance_id, onglet').eq('user_id', etudiantId),
      supabase.from('devoirs').select('seance_id, statut, remis_at').eq('user_id', etudiantId),
    ])
    setProgressions((progs ?? []) as { seance_id: string; onglet: string }[])
    setDevoirs((dev ?? []) as { seance_id: string; statut: string; remis_at: string }[])
  }

  const chargerScores = async () => {
    const { data: sc } = await supabase
      .from('scores_competences')
      .select('*')
      .eq('user_id', etudiantId)
      .order('created_at', { ascending: true })
    setScores((sc ?? []) as ScoreComp[])
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const navigate_inner = (url: string) => { window.location.href = url }
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate_inner('/enseignant/connexion')
    })
    return stop
  }, [])
useEffect(() => {
    const charger = async () => {
      const [{ data: insc }, { data: progs }, { data: dev }] = await Promise.all([
        supabase.from('demandes_inscription').select('nom, prenom, email').eq('user_id', etudiantId).single(),
        supabase.from('progressions').select('seance_id, onglet').eq('user_id', etudiantId),
        supabase.from('devoirs').select('seance_id, statut, remis_at').eq('user_id', etudiantId),
      ])
      if (insc) setInfo(insc as InfoEtudiant)
      setProgressions((progs ?? []) as { seance_id: string; onglet: string }[])
      setDevoirs((dev ?? []) as { seance_id: string; statut: string; remis_at: string }[])
      await chargerScores()
      setChargement(false)
    }
    charger()
  }, [etudiantId])

  const appliquerAjustement = async () => {
    if (!ajustement || !etudiantId) return
    setSauvAjust(true)
    // Chercher le dernier score de cette compétence et mettre à jour niveau_manuel
    const scoreExistant = [...scores].reverse().find(s => s.competence_id === ajustement.compId)
    if (scoreExistant) {
      await supabase.from('scores_competences')
        .update({ niveau_manuel: ajustement.niveau })
        .eq('id', scoreExistant.id)
    } else {
      // Créer un score manuel sans évaluation (points 0/0)
      await supabase.from('scores_competences').insert({
        user_id: etudiantId,
        seance_id: 'manuel',
        competence_id: ajustement.compId,
        points_obtenus: 0,
        points_max: 0,
        niveau_auto: ajustement.niveau,
        niveau_manuel: ajustement.niveau,
      })
    }
    await chargerScores()
    setSauvAjust(false)
    setAjustement(null)
  }

  const ongletLabels: Record<string, string> = {
    capsule: 'Capsule', fiche: 'Fiche', presentiel: 'Présentiel',
    activites: 'Activités', travaux: 'Travaux', journal: 'Journal'
  }


  const scoresPourComp = (compId: string) => scores.filter(s => s.competence_id === compId)
  const atteintes = COMPETENCES.filter(c => { const n = niveauEffectif(scoresPourComp(c.id)); return n === 'averti' || n === 'expert' }).length
  const travaillees = COMPETENCES.filter(c => scoresPourComp(c.id).length > 0).length
  const pctComp = COMPETENCES.length > 0 ? Math.round((atteintes / COMPETENCES.length) * 100) : 0
  const fmt = (iso: string) => new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit' })

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant/etudiants')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Retour</button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>{info ? `${info.prenom} ${info.nom}` : 'Chargement...'}</span>
        <div style={{ width: '80px' }} />
      </header>

      {chargement ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
      ) : (
        <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
          {/* Infos */}
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem 1.25rem', border: '1px solid #E5E7EB', marginBottom: '1.25rem' }}>
            <div style={{ fontSize: '0.875rem', color: '#6B7280' }}>{info?.email}</div>
          </div>

          {/* Onglets navigation */}
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem', backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '0.375rem', border: '1px solid #E5E7EB' }}>
            {[
              { id: 'progression' as const, label: 'Progression séances' },
              { id: 'competences' as const, label: 'Compétences Bloc 3' },
            ].map(tab => (
              <button key={tab.id} onClick={() => setOngletActif(tab.id)}
                style={{ flex: 1, padding: '0.5rem 0.75rem', borderRadius: '7px', border: 'none', cursor: 'pointer', fontFamily: 'Arial', fontSize: '0.8rem', fontWeight: '700',
                  backgroundColor: ongletActif === tab.id ? '#1B6B3A' : 'transparent',
                  color: ongletActif === tab.id ? '#FFFFFF' : '#6B7280',
                }}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Message suppression */}
          {msgSuppr && (
            <div style={{ backgroundColor: '#D1FAE5', border: '1px solid #6EE7B7', borderRadius: '8px', padding: '0.75rem 1rem', marginBottom: '1rem', fontSize: '0.875rem', color: '#065F46' }}>
              {msgSuppr}
            </div>
          )}

          {ongletActif === 'progression' && (<>

          {/* Zone suppression données */}
          <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '10px', padding: '1rem 1.25rem', marginBottom: '1.25rem' }}>
            <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#DC2626', marginBottom: '0.75rem' }}>
              Supprimer les données de test
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              {[
                { label: 'Devoirs', type: 'devoirs' as const },
                { label: 'Journal', type: 'journal' as const },
                { label: 'Progression', type: 'progressions' as const },
                { label: 'Messages', type: 'messages' as const },
                { label: 'Badges', type: 'badges' as const },
                { label: 'Tout supprimer', type: 'tout' as const },
              ].map(btn => (
                <button key={btn.type} onClick={() => supprimerDonnees(btn.type)} disabled={suppression}
                  style={{ backgroundColor: btn.type === 'tout' ? '#DC2626' : '#FFFFFF', color: btn.type === 'tout' ? '#FFFFFF' : '#DC2626', border: '1px solid #FECACA', borderRadius: '6px', padding: '0.375rem 0.75rem', fontSize: '0.75rem', fontWeight: '600', cursor: suppression ? 'not-allowed' : 'pointer', fontFamily: 'Arial', opacity: suppression ? 0.6 : 1 }}>
                  {suppression ? '...' : btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Progression par thème */}
          {THEMES.map(theme => {
            const seancesTheme = SEANCES.filter(s => s.theme_id === theme.id)
            return (
              <div key={theme.id} style={{ marginBottom: '1.25rem' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '700', color: theme.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>
                  Thème {theme.numero} — {theme.titre}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {seancesTheme.map(seance => {
                    const prog = calcProgressionSeance(progressions, seance.id)
                    const ongletsFaits = progressions.filter(p => p.seance_id === seance.id).map(p => p.onglet)
                    const devoir = devoirs.find(d => d.seance_id === seance.id)
                    return (
                      <div key={seance.id} style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px', padding: '0.875rem 1rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                          <div style={{ fontSize: '0.8rem', fontWeight: '600', color: '#111827' }}>S{seance.numero} — {seance.titre.substring(0, 45)}{seance.titre.length > 45 ? '...' : ''}</div>
                          <div style={{ fontSize: '0.8rem', fontWeight: '700', color: prog === 100 ? '#059669' : prog > 0 ? '#D97706' : '#9CA3AF', flexShrink: 0, marginLeft: '0.5rem' }}>{prog}%</div>
                        </div>
                        <div style={{ height: '4px', backgroundColor: '#F3F4F6', borderRadius: '2px', overflow: 'hidden', marginBottom: '0.5rem' }}>
                          <div style={{ height: '100%', width: `${prog}%`, backgroundColor: prog === 100 ? '#059669' : theme.couleur, borderRadius: '2px' }} />
                        </div>
                        <div style={{ display: 'flex', gap: '0.25rem', flexWrap: 'wrap' }}>
                          {Object.entries(ongletLabels).map(([key, label]) => (
                            <span key={key} style={{ fontSize: '0.65rem', padding: '0.15rem 0.4rem', borderRadius: '4px', backgroundColor: ongletsFaits.includes(key) ? '#D1FAE5' : '#F3F4F6', color: ongletsFaits.includes(key) ? '#065F46' : '#9CA3AF', fontWeight: '600' }}>
                              {label}
                            </span>
                          ))}
                          {devoir && (
                            <span style={{ fontSize: '0.65rem', padding: '0.15rem 0.4rem', borderRadius: '4px', backgroundColor: '#DBEAFE', color: '#1E40AF', fontWeight: '600' }}>
                              Devoir remis
                            </span>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
          </>)}

          {ongletActif === 'competences' && (
            <div>
              {/* Récapitulatif */}
              <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', border: '1px solid #E5E7EB', padding: '1rem 1.25rem', marginBottom: '1.25rem' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.75rem' }}>
                  Bloc 3 — U52 Gestion de la relation client
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.875rem' }}>
                  <div style={{ flex: 1, height: '8px', backgroundColor: '#F3F4F6', borderRadius: '4px', overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${pctComp}%`, backgroundColor: '#15803D', borderRadius: '4px' }} />
                  </div>
                  <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#15803D', flexShrink: 0 }}>{pctComp}%</span>
                </div>
                <div style={{ display: 'flex', gap: '0.625rem' }}>
                  {[
                    { label: 'Travaillées', val: travaillees, bg: '#EFF6FF', color: '#1D4ED8' },
                    { label: 'Averti/Expert', val: atteintes, bg: '#F0FDF4', color: '#15803D' },
                    { label: 'Non travaillées', val: COMPETENCES.length - travaillees, bg: '#F3F4F6', color: '#9CA3AF' },
                  ].map(item => (
                    <div key={item.label} style={{ flex: 1, textAlign: 'center', backgroundColor: item.bg, borderRadius: '8px', padding: '0.5rem 0.25rem' }}>
                      <div style={{ fontSize: '1.25rem', fontWeight: '700', color: item.color }}>{item.val}</div>
                      <div style={{ fontSize: '0.6rem', color: item.color, fontWeight: '600', lineHeight: '1.3' }}>{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Modale ajustement manuel */}
              {ajustement && (
                <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
                  <div style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '1.5rem', maxWidth: '360px', width: '100%' }}>
                    <div style={{ fontSize: '0.875rem', fontWeight: '700', color: '#111827', marginBottom: '0.25rem' }}>Ajustement manuel</div>
                    <div style={{ fontSize: '0.75rem', color: '#6B7280', marginBottom: '1rem' }}>
                      {COMPETENCES.find(c => c.id === ajustement.compId)?.code} — {COMPETENCES.find(c => c.id === ajustement.compId)?.libelle}
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1rem' }}>
                      {(['novice', 'debrouille', 'averti', 'expert'] as NivComp[]).map(n => {
                        const c = NIVEAUX_COULEURS[n]
                        return (
                          <button key={n} onClick={() => setAjustement(a => a ? { ...a, niveau: n } : null)}
                            style={{ padding: '0.625rem 1rem', borderRadius: '8px', border: `2px solid ${ajustement.niveau === n ? c.texte : c.bordure}`, backgroundColor: ajustement.niveau === n ? c.bg : '#FFFFFF', color: c.texte, fontWeight: '700', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial', textAlign: 'left' }}>
                            {NIVEAUX_ICONES[n]} {NIVEAUX_LABELS[n]}
                          </button>
                        )
                      })}
                    </div>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button onClick={() => setAjustement(null)}
                        style={{ flex: 1, padding: '0.625rem', borderRadius: '8px', border: '1px solid #E5E7EB', backgroundColor: '#FFFFFF', color: '#6B7280', fontWeight: '600', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial' }}>
                        Annuler
                      </button>
                      <button onClick={appliquerAjustement} disabled={sauvAjust}
                        style={{ flex: 1, padding: '0.625rem', borderRadius: '8px', border: 'none', backgroundColor: '#1B6B3A', color: '#FFFFFF', fontWeight: '700', fontSize: '0.875rem', cursor: sauvAjust ? 'not-allowed' : 'pointer', fontFamily: 'Arial', opacity: sauvAjust ? 0.7 : 1 }}>
                        {sauvAjust ? 'Sauvegarde...' : 'Confirmer'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Détail par activité */}
              {ACTIVITES_BLOC3.map(activite => (
                <div key={activite.id} style={{ marginBottom: '1.25rem' }}>
                  <div style={{ fontSize: '0.7rem', fontWeight: '700', color: activite.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>
                    {activite.code} — {activite.titre}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {activite.competences.map(comp => {
                      const sc = scoresPourComp(comp.id)
                      const niveau = niveauEffectif(sc)
                      const c = niveau ? NIVEAUX_COULEURS[niveau] : { bg: '#F3F4F6', texte: '#9CA3AF', bordure: '#E5E7EB' }
                      return (
                        <div key={comp.id} style={{ backgroundColor: '#FFFFFF', border: `1px solid ${c.bordure}`, borderLeft: `4px solid ${activite.couleur}`, borderRadius: '8px', overflow: 'hidden' }}>
                          <div style={{ padding: '0.75rem 1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '0.75rem' }}>
                            <div style={{ flex: 1 }}>
                              <div style={{ fontSize: '0.65rem', fontWeight: '700', color: activite.couleur, marginBottom: '0.2rem' }}>{comp.code}</div>
                              <div style={{ fontSize: '0.8rem', color: '#111827', lineHeight: '1.5' }}>{comp.libelle}</div>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.375rem', flexShrink: 0 }}>
                              {niveau ? (
                                <span style={{ backgroundColor: c.bg, color: c.texte, fontSize: '0.65rem', fontWeight: '700', padding: '0.2rem 0.5rem', borderRadius: '20px', border: `1px solid ${c.bordure}` }}>
                                  {NIVEAUX_ICONES[niveau]} {NIVEAUX_LABELS[niveau]}
                                </span>
                              ) : (
                                <span style={{ fontSize: '0.65rem', color: '#9CA3AF' }}>Non évaluée</span>
                              )}
                              {/* Bouton ajustement manuel */}
                              <button
                                onClick={() => setAjustement({ compId: comp.id, niveau: niveau ?? 'novice' })}
                                style={{ fontSize: '0.6rem', color: '#1B6B3A', background: 'none', border: '1px solid #D1FAE5', borderRadius: '4px', padding: '0.15rem 0.4rem', cursor: 'pointer', fontFamily: 'Arial', fontWeight: '600' }}>
                                Ajuster
                              </button>
                            </div>
                          </div>
                          {/* Historique */}
                          {sc.length > 0 && (
                            <div style={{ borderTop: '1px solid #F3F4F6', padding: '0.5rem 1rem', backgroundColor: '#FAFAFA' }}>
                              <div style={{ fontSize: '0.6rem', fontWeight: '700', color: '#6B7280', marginBottom: '0.25rem', textTransform: 'uppercase' }}>
                                {sc.length} évaluation{sc.length > 1 ? 's' : ''}
                              </div>
                              {sc.map((s, idx) => {
                                const nFinal = (s.niveau_manuel ?? s.niveau_auto) as NivComp
                                const cf = NIVEAUX_COULEURS[nFinal] ?? NIVEAUX_COULEURS.novice
                                const pct2 = s.points_max > 0 ? Math.round((s.points_obtenus / s.points_max) * 100) : 0
                                return (
                                  <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.65rem', marginBottom: '0.2rem' }}>
                                    <span style={{ color: '#9CA3AF' }}>#{idx + 1} {fmt(s.created_at)}</span>
                                    {s.points_max > 0 && <span style={{ color: '#374151', fontWeight: '600' }}>{s.points_obtenus}/{s.points_max} ({pct2}%)</span>}
                                    <span style={{ backgroundColor: cf.bg, color: cf.texte, padding: '0.1rem 0.3rem', borderRadius: '4px', fontWeight: '700' }}>
                                      {NIVEAUX_LABELS[nFinal]}{s.niveau_manuel ? ' *' : ''}
                                    </span>
                                  </div>
                                )
                              })}
                              {sc.some(s => s.niveau_manuel) && <div style={{ fontSize: '0.55rem', color: '#9CA3AF', marginTop: '0.125rem' }}>* ajusté manuellement</div>}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

        </main>
      )}
    </div>
  )
}

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'

interface Etudiant {
  user_id: string
  nom: string
  prenom: string
  email: string
  statut: string
  created_at: string
}

export default function GestionComptes() {
  const navigate = useNavigate()
  const [etudiants, setEtudiants] = useState<Etudiant[]>([])
  const [chargement, setChargement] = useState(true)
  const [resetId, setResetId] = useState<string | null>(null)
  const [nouveauMdp, setNouveauMdp] = useState('')
  const [enCours, setEnCours] = useState<string | null>(null)
  const [message, setMessage] = useState<{ id: string; texte: string; ok: boolean } | null>(null)
  const [recherche, setRecherche] = useState('')

  useEffect(() => {
    const charger = async () => {
      const { data } = await supabase
        .from('demandes_inscription')
        .select('user_id, nom, prenom, email, statut, created_at')
        .order('nom')
      setEtudiants(data ?? [])
      setChargement(false)
    }
    charger()
  }, [])

  const reinitialiserMdp = async (userId: string) => {
    if (!nouveauMdp || nouveauMdp.length < 6) {
      setMessage({ id: userId, texte: 'Le mot de passe doit contenir au moins 6 caracteres.', ok: false })
      return
    }
    setEnCours(userId)
    // Utiliser la fonction RPC Supabase pour reset le mdp sans affecter les données
    const { error } = await supabase.rpc('reset_user_password', {
      target_user_id: userId,
      new_password: nouveauMdp,
    })
    setEnCours(null)
    if (error) {
      setMessage({ id: userId, texte: 'Erreur : ' + error.message, ok: false })
    } else {
      setMessage({ id: userId, texte: 'Mot de passe reinitialise avec succes.', ok: true })
      setResetId(null)
      setNouveauMdp('')
    }
  }

  const filtres = etudiants.filter(e =>
    `${e.nom} ${e.prenom} ${e.email}`.toLowerCase().includes(recherche.toLowerCase())
  )

  const statutLabel = (s: string) => {
    if (s === 'accepte') return { texte: 'Actif', bg: '#D1FAE5', col: '#065F46' }
    if (s === 'en_attente') return { texte: 'En attente', bg: '#FEF3C7', col: '#92400E' }
    if (s === 'refuse') return { texte: 'Refuse', bg: '#FEE2E2', col: '#991B1B' }
    return { texte: s, bg: '#F3F4F6', col: '#374151' }
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Tableau de bord
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Gestion des comptes</span>
        <div style={{ width: '100px' }} />
      </header>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '800px', margin: '0 auto' }}>
        {/* Recherche */}
        <input
          type="text"
          placeholder="Rechercher par nom, prenom ou email..."
          value={recherche}
          onChange={e => setRecherche(e.target.value)}
          style={{ width: '100%', padding: '0.75rem 1rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', boxSizing: 'border-box', marginBottom: '1rem' }}
        />

        <div style={{ fontSize: '0.75rem', color: '#6B7280', marginBottom: '0.75rem' }}>
          {filtres.length} etudiant{filtres.length > 1 ? 's' : ''}
        </div>

        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
        ) : filtres.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Aucun compte trouve.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {filtres.map(e => {
              const s = statutLabel(e.statut)
              const enReset = resetId === e.user_id
              const msg = message?.id === e.user_id ? message : null
              return (
                <div key={e.user_id} style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '1rem 1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.75rem', flexWrap: 'wrap' }}>
                    <div>
                      <div style={{ fontWeight: '700', color: '#111827', fontSize: '0.9rem' }}>{e.prenom} {e.nom}</div>
                      <div style={{ fontSize: '0.8rem', color: '#6B7280', marginTop: '2px' }}>{e.email}</div>
                      <div style={{ fontSize: '0.72rem', color: '#9CA3AF', marginTop: '2px' }}>
                        Inscrit le {new Date(e.created_at).toLocaleDateString('fr-FR')}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                      <span style={{ fontSize: '0.72rem', fontWeight: '700', backgroundColor: s.bg, color: s.col, borderRadius: '20px', padding: '2px 8px' }}>
                        {s.texte}
                      </span>
                      <button
                        onClick={() => { setResetId(enReset ? null : e.user_id); setNouveauMdp(''); setMessage(null) }}
                        style={{ fontSize: '0.75rem', padding: '4px 10px', borderRadius: '6px', border: '1px solid #D1D5DB', background: enReset ? '#F3F4F6' : '#FFFFFF', color: '#374151', cursor: 'pointer', fontFamily: 'Arial' }}>
                        {enReset ? 'Annuler' : 'Reinitialiser mdp'}
                      </button>
                    </div>
                  </div>

                  {enReset && (
                    <div style={{ marginTop: '0.75rem', display: 'flex', gap: '0.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
                      <input
                        type="text"
                        placeholder="Nouveau mot de passe (6 car. min.)"
                        value={nouveauMdp}
                        onChange={ev => setNouveauMdp(ev.target.value)}
                        style={{ flex: 1, minWidth: '200px', padding: '0.5rem 0.75rem', border: '1px solid #D1D5DB', borderRadius: '7px', fontSize: '0.875rem', fontFamily: 'Arial' }}
                      />
                      <button
                        onClick={() => reinitialiserMdp(e.user_id)}
                        disabled={enCours === e.user_id}
                        style={{ padding: '0.5rem 1rem', backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '7px', fontSize: '0.875rem', fontWeight: '600', cursor: enCours === e.user_id ? 'not-allowed' : 'pointer', fontFamily: 'Arial', opacity: enCours === e.user_id ? 0.6 : 1 }}>
                        {enCours === e.user_id ? '...' : 'Valider'}
                      </button>
                    </div>
                  )}

                  {msg && (
                    <div style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: msg.ok ? '#065F46' : '#DC2626', backgroundColor: msg.ok ? '#D1FAE5' : '#FEF2F2', padding: '6px 10px', borderRadius: '6px' }}>
                      {msg.texte}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}

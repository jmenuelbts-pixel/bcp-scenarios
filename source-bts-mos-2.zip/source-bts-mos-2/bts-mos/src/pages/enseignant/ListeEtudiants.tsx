import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { SEANCES } from '../../data/schema'
import { calcProgressionGlobale } from '../../lib/progression'

interface Etudiant {
  user_id: string
  nom: string
  prenom: string
  email: string
  statut: string
  progressions: { seance_id: string; onglet: string }[]
  nbDevoirs: number
}

export default function ListeEtudiants() {
  const navigate = useNavigate()
  const [etudiants, setEtudiants] = useState<Etudiant[]>([])
  const [chargement, setChargement] = useState(true)
  const [supprimant, setSupprimant] = useState<string | null>(null)

  const supprimerEtudiant = async (userId: string, nom: string, prenom: string) => {
    if (!confirm(`Supprimer définitivement ${prenom} ${nom} et toutes ses données ?`)) return
    setSupprimant(userId)
    await Promise.all([
      supabase.from('devoirs').delete().eq('user_id', userId),
      supabase.from('journal_bord').delete().eq('user_id', userId),
      supabase.from('progressions').delete().eq('user_id', userId),
      supabase.from('messages').delete().eq('expediteur_id', userId),
      supabase.from('badges').delete().eq('user_id', userId),
      supabase.from('scores_competences').delete().eq('user_id', userId),
      supabase.from('deverrouillages').delete().eq('user_id', userId),
    ])
    await supabase.from('demandes_inscription').delete().eq('user_id', userId)
    await supabase.auth.admin.deleteUser(userId).catch(() => {})
    setEtudiants(e => e.filter(x => x.user_id !== userId))
    setSupprimant(null)
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => {
    const charger = async () => {
      const { data: inscrits } = await supabase
        .from('demandes_inscription')
        .select('user_id, nom, prenom, email, statut')
        .in('statut', ['accepte', 'desactive'])
        .order('nom')

      const { data: progs } = await supabase.from('progressions').select('user_id, seance_id, onglet')
      const { data: devoirs } = await supabase.from('devoirs').select('user_id, statut')

      const liste: Etudiant[] = (inscrits ?? []).map((e: { user_id: string; nom: string; prenom: string; email: string; statut: string }) => ({
        ...e,
        progressions: (progs ?? []).filter((p: { user_id: string }) => p.user_id === e.user_id),
        nbDevoirs: (devoirs ?? []).filter((d: { user_id: string; statut: string }) => d.user_id === e.user_id && d.statut === 'remis').length,
      }))
      setEtudiants(liste)
      setChargement(false)
    }
    charger()
  }, [])

  const toutes = SEANCES.map(s => s.id)

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Tableau de bord</button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Suivi des étudiants</span>
        <div style={{ width: '100px' }} />
      </header>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
        ) : etudiants.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun étudiant inscrit.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {etudiants.map((e, i) => {
              const prog = calcProgressionGlobale(e.progressions, toutes)
              return (
                <motion.div key={e.user_id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', overflow: 'hidden' }}>
                  <button onClick={() => navigate(`/enseignant/etudiants/${e.user_id}`)}
                    style={{ width: '100%', padding: '1rem 1.25rem', cursor: 'pointer', textAlign: 'left', fontFamily: 'Arial', background: 'none', border: 'none' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.625rem' }}>
                      <div>
                        <div style={{ fontSize: '0.9rem', fontWeight: '700', color: '#111827' }}>{e.prenom} {e.nom}</div>
                        <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: '0.1rem' }}>{e.email}</div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: '1rem', fontWeight: '700', color: '#1B6B3A' }}>{prog}%</div>
                        <div style={{ fontSize: '0.7rem', color: '#9CA3AF' }}>{e.nbDevoirs} devoir{e.nbDevoirs > 1 ? 's' : ''} rendu{e.nbDevoirs > 1 ? 's' : ''}</div>
                      </div>
                    </div>
                    <div style={{ height: '6px', backgroundColor: '#F3F4F6', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${prog}%`, backgroundColor: '#1B6B3A', borderRadius: '3px', transition: 'width 0.5s' }} />
                    </div>
                  </button>
                  <div style={{ borderTop: '1px solid #F3F4F6', padding: '0.5rem 1.25rem', display: 'flex', justifyContent: 'flex-end' }}>
                    <button onClick={() => supprimerEtudiant(e.user_id, e.nom, e.prenom)} disabled={supprimant === e.user_id}
                      style={{ fontSize: '0.7rem', color: '#DC2626', background: 'none', border: '1px solid #FECACA', borderRadius: '6px', padding: '0.25rem 0.625rem', cursor: supprimant === e.user_id ? 'not-allowed' : 'pointer', fontFamily: 'Arial', fontWeight: '600', opacity: supprimant === e.user_id ? 0.5 : 1 }}>
                      {supprimant === e.user_id ? 'Suppression...' : 'Supprimer'}
                    </button>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}

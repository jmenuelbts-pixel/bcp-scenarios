import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'

interface Demande {
  id: string
  user_id: string
  nom: string
  prenom: string
  date_naissance: string
  email: string
  statut: 'en_attente' | 'accepte' | 'refuse'
  created_at: string
}

export default function DemandesInscription() {
  const navigate = useNavigate()
  const [demandes, setDemandes] = useState<Demande[]>([])
  const [chargement, setChargement] = useState(true)
  const [traitement, setTraitement] = useState<string | null>(null)
  const [message, setMessage] = useState<{ texte: string; type: 'succes' | 'erreur' } | null>(null)

  const chargerDemandes = async () => {
    const { data } = await supabase
      .from('demandes_inscription')
      .select('*')
      .order('created_at', { ascending: false })
    setDemandes((data as Demande[]) ?? [])
    setChargement(false)
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => { chargerDemandes() }, [])

  const traiter = async (demande: Demande, action: 'accepte' | 'refuse') => {
    setTraitement(demande.id)
    setMessage(null)

    const { error } = await supabase
      .from('demandes_inscription')
      .update({ statut: action, traite_at: new Date().toISOString() })
      .eq('id', demande.id)

    if (error) {
      setMessage({ texte: 'Erreur : ' + error.message, type: 'erreur' })
    } else {
      setMessage({
        texte: action === 'accepte'
          ? `${demande.prenom} ${demande.nom} a été accepté(e).`
          : `${demande.prenom} ${demande.nom} a été refusé(e).`,
        type: 'succes'
      })
      chargerDemandes()
    }

    setTraitement(null)
  }

  const enAttente = demandes.filter(d => d.statut === 'en_attente')
  const traitees = demandes.filter(d => d.statut !== 'en_attente')
  const formatDate = (iso: string) => new Date(iso).toLocaleDateString('fr-FR')

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Tableau de bord
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Demandes d'inscription</span>
        <div style={{ width: '100px' }} />
      </header>
      <BandeauHorsLigne />

      <main style={{ padding: '1.5rem 1rem', maxWidth: '640px', margin: '0 auto' }}>

        {/* Message retour */}
        {message && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
            style={{
              backgroundColor: message.type === 'succes' ? '#D1FAE5' : '#FEF2F2',
              border: `1px solid ${message.type === 'succes' ? '#6EE7B7' : '#FECACA'}`,
              borderRadius: '8px', padding: '0.75rem 1rem', marginBottom: '1rem',
              fontSize: '0.875rem', color: message.type === 'succes' ? '#065F46' : '#DC2626',
            }}>
            {message.texte}
          </motion.div>
        )}

        {/* En attente */}
        <h2 style={{ fontSize: '1rem', fontWeight: '700', color: '#111827', margin: '0 0 1rem 0', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          Demandes en attente
          {enAttente.length > 0 && (
            <span style={{ backgroundColor: '#DC2626', color: '#FFFFFF', borderRadius: '9999px', fontSize: '0.7rem', fontWeight: '700', padding: '0.15rem 0.5rem' }}>
              {enAttente.length}
            </span>
          )}
        </h2>

        {chargement && <p style={{ color: '#9CA3AF', fontSize: '0.875rem' }}>Chargement...</p>}

        {!chargement && enAttente.length === 0 && (
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.5rem', border: '1px solid #D1D5DB', textAlign: 'center', color: '#9CA3AF', fontSize: '0.875rem', marginBottom: '2rem' }}>
            Aucune demande en attente.
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '2rem' }}>
          {enAttente.map((d, i) => (
            <motion.div key={d.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
              style={{ backgroundColor: '#FFFFFF', border: '2px solid #FEF3C7', borderRadius: '10px', padding: '1rem' }}>
              <div style={{ marginBottom: '0.75rem' }}>
                <div style={{ fontWeight: '700', color: '#111827', fontSize: '0.9375rem' }}>
                  {d.prenom} {d.nom}
                </div>
                <div style={{ fontSize: '0.8rem', color: '#6B7280', marginTop: '0.15rem' }}>{d.email}</div>
                <div style={{ fontSize: '0.8rem', color: '#6B7280' }}>Né(e) le {formatDate(d.date_naissance)}</div>
                <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: '0.25rem' }}>
                  Demande reçue le {formatDate(d.created_at)}
                </div>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button
                  onClick={() => traiter(d, 'accepte')}
                  disabled={traitement === d.id}
                  style={{ flex: 1, backgroundColor: '#16A34A', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.75rem', fontSize: '0.875rem', fontWeight: '600', cursor: traitement === d.id ? 'not-allowed' : 'pointer', minHeight: '44px', fontFamily: 'Arial', opacity: traitement === d.id ? 0.6 : 1 }}>
                  {traitement === d.id ? 'Traitement...' : 'Accepter'}
                </button>
                <button
                  onClick={() => traiter(d, 'refuse')}
                  disabled={traitement === d.id}
                  style={{ flex: 1, backgroundColor: '#FFFFFF', color: '#DC2626', border: '1px solid #FECACA', borderRadius: '8px', padding: '0.75rem', fontSize: '0.875rem', fontWeight: '600', cursor: traitement === d.id ? 'not-allowed' : 'pointer', minHeight: '44px', fontFamily: 'Arial', opacity: traitement === d.id ? 0.6 : 1 }}>
                  Refuser
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Traitées */}
        {traitees.length > 0 && (
          <>
            <h2 style={{ fontSize: '1rem', fontWeight: '700', color: '#111827', margin: '0 0 1rem 0' }}>
              Demandes traitées
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {traitees.map(d => (
                <div key={d.id} style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '0.875rem 1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: '600', color: '#374151', fontSize: '0.875rem' }}>{d.prenom} {d.nom}</div>
                    <div style={{ fontSize: '0.75rem', color: '#9CA3AF' }}>{d.email}</div>
                  </div>
                  <span style={{
                    backgroundColor: d.statut === 'accepte' ? '#D1FAE5' : '#FEE2E2',
                    color: d.statut === 'accepte' ? '#065F46' : '#991B1B',
                    borderRadius: '9999px', fontSize: '0.7rem', fontWeight: '600', padding: '0.2rem 0.6rem'
                  }}>
                    {d.statut === 'accepte' ? 'Accepté' : 'Refusé'}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  )
}

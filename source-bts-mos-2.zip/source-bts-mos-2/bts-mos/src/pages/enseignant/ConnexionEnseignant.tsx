import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuth } from '../../lib/auth'

export default function ConnexionEnseignant() {
  const navigate = useNavigate()
  const { signInEnseignant } = useAuth()
  const [email, setEmail] = useState('')
  const [mdp, setMdp] = useState('')
  const [erreur, setErreur] = useState('')
  const [chargement, setChargement] = useState(false)

  const handleConnexion = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !mdp) { setErreur('Veuillez remplir tous les champs.'); return }
    setChargement(true)
    setErreur('')
    const { error } = await signInEnseignant(email, mdp)
    setChargement(false)
    if (error) { setErreur(error); return }
    navigate('/enseignant')
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        style={{ backgroundColor: '#FFFFFF', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '400px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
        <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: '0.875rem', marginBottom: '1.5rem', padding: 0, minHeight: '44px' }}>
          &larr; Retour
        </button>
        <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0' }}>Espace professeur</h1>
        <p style={{ color: '#6B7280', fontSize: '0.875rem', margin: '0 0 2rem 0' }}>Connectez-vous à votre compte</p>

        {erreur && (
          <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '8px', padding: '0.75rem', marginBottom: '1rem', fontSize: '0.875rem', color: '#DC2626' }}>
            {erreur}
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.375rem' }}>Adresse email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="votre@email.fr"
              style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '1rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.375rem' }}>Mot de passe</label>
            <input type="password" value={mdp} onChange={e => setMdp(e.target.value)} placeholder="••••••••"
              style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '1rem', fontFamily: 'Arial', boxSizing: 'border-box' }} />
          </div>
          <motion.button whileTap={{ scale: 0.98 }} onClick={handleConnexion} disabled={chargement}
            style={{ backgroundColor: chargement ? '#9CA3AF' : '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '1rem', fontWeight: '600', cursor: chargement ? 'not-allowed' : 'pointer', minHeight: '44px', marginTop: '0.5rem', fontFamily: 'Arial' }}>
            {chargement ? 'Connexion...' : 'Se connecter'}
          </motion.button>
        </div>
      </motion.div>
    </div>
  )
}

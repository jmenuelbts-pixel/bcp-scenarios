import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { SEANCES } from '../../data/schema'

interface Etudiant { user_id: string; nom: string; prenom: string }

export default function Exports() {
  const navigate = useNavigate()
  const [etudiants, setEtudiants] = useState<Etudiant[]>([])
  const [chargement, setChargement] = useState(true)
  const [generation, setGeneration] = useState<string | null>(null)

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => {
    supabase.from('demandes_inscription').select('user_id, nom, prenom').eq('statut', 'accepte').order('nom')
      .then(({ data }) => { setEtudiants((data ?? []) as Etudiant[]); setChargement(false) })
  }, [])

  const exporterJournal = async (etudiant: Etudiant) => {
    setGeneration(etudiant.user_id + '_journal')
    const { data: entrees } = await supabase.from('journal_bord').select('seance_id, contenu, created_at')
      .eq('user_id', etudiant.user_id).order('created_at')

    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Journal de bord — ${etudiant.prenom} ${etudiant.nom}</title>
    <style>body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;color:#111;}
    h1{color:#1B6B3A;border-bottom:2px solid #1B6B3A;padding-bottom:8px;}
    h2{color:#374151;font-size:1rem;margin-top:24px;}
    .entree{background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:16px;margin-bottom:16px;}
    .date{font-size:0.8rem;color:#9ca3af;margin-bottom:8px;}
    .contenu{white-space:pre-wrap;line-height:1.6;}
    @media print{body{margin:20px;}}</style></head><body>
    <h1>Journal de bord — ${etudiant.prenom} ${etudiant.nom}</h1>
    <p style="color:#6b7280">BTS MOS — Pôle 3 — Exporté le ${new Date().toLocaleDateString('fr-FR')}</p>
    ${(entrees ?? []).map((e: { seance_id: string; contenu: string; created_at: string }) => {
      const seance = SEANCES.find(s => s.id === e.seance_id)
      return `<div class="entree">
        <h2>S${seance?.numero} — ${seance?.titre ?? e.seance_id}</h2>
        <div class="date">${new Date(e.created_at).toLocaleDateString('fr-FR')}</div>
        <div class="contenu">${e.contenu || '<em>Pas de contenu</em>'}</div>
      </div>`
    }).join('')}
    </body></html>`

    ouvrir(html)
    setGeneration(null)
  }

  const exporterResultats = async (etudiant: Etudiant) => {
    setGeneration(etudiant.user_id + '_resultats')
    const { data: progs } = await supabase.from('progressions').select('seance_id, onglet').eq('user_id', etudiant.user_id)
    const { data: devoirs } = await supabase.from('devoirs').select('seance_id, statut, note, bareme, remis_at').eq('user_id', etudiant.user_id)

    const onglets = ['capsule', 'fiche', 'presentiel', 'activites', 'travaux', 'journal']
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Résultats — ${etudiant.prenom} ${etudiant.nom}</title>
    <style>body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;color:#111;}
    h1{color:#1B6B3A;border-bottom:2px solid #1B6B3A;padding-bottom:8px;}
    table{width:100%;border-collapse:collapse;margin-top:16px;}
    th{background:#1B6B3A;color:#fff;padding:8px 12px;text-align:left;font-size:0.875rem;}
    td{padding:8px 12px;border-bottom:1px solid #e5e7eb;font-size:0.875rem;}
    tr:nth-child(even){background:#f9fafb;}
    .badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:0.75rem;font-weight:700;}
    @media print{body{margin:20px;}}</style></head><body>
    <h1>Résultats — ${etudiant.prenom} ${etudiant.nom}</h1>
    <p style="color:#6b7280">BTS MOS — Pôle 3 — Exporté le ${new Date().toLocaleDateString('fr-FR')}</p>
    <table><thead><tr><th>Séance</th><th>Progression</th><th>Devoir</th><th>Note</th></tr></thead><tbody>
    ${SEANCES.map(s => {
      const seanceProgs = (progs ?? []).filter((p: { seance_id: string }) => p.seance_id === s.id)
      const nb = onglets.filter(o => seanceProgs.some((p: { onglet: string }) => p.onglet === o)).length
      const pct = Math.round((nb / 6) * 100)
      const devoir = (devoirs ?? []).find((d: { seance_id: string }) => d.seance_id === s.id)
      return `<tr>
        <td>S${s.numero} — ${s.titre.substring(0, 50)}${s.titre.length > 50 ? '...' : ''}</td>
        <td>${pct}% (${nb}/6 onglets)</td>
        <td>${devoir ? (devoir.statut === 'remis' ? 'Rendu' : 'Brouillon') : '—'}</td>
        <td>${devoir?.note !== null && devoir?.note !== undefined ? `${devoir.note}/${devoir.bareme}` : '—'}</td>
      </tr>`
    }).join('')}
    </tbody></table></body></html>`

    ouvrir(html)
    setGeneration(null)
  }

  const exporterDevoirs = async (etudiant: Etudiant) => {
    setGeneration(etudiant.user_id + '_devoirs')
    const { data: devoirs } = await supabase.from('devoirs').select('*')
      .eq('user_id', etudiant.user_id).eq('statut', 'remis').order('remis_at')

    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Devoirs rendus — ${etudiant.prenom} ${etudiant.nom}</title>
    <style>body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;color:#111;}
    h1{color:#1B6B3A;border-bottom:2px solid #1B6B3A;padding-bottom:8px;}
    h2{color:#374151;margin-top:32px;font-size:1rem;background:#f3f4f6;padding:8px 12px;border-radius:6px;}
    .question{margin:16px 0;}
    .label{font-size:0.75rem;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:0.05em;}
    .reponse{background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:12px;margin-top:4px;white-space:pre-wrap;line-height:1.6;}
    .correction{background:#f0fdf4;border:1px solid #6ee7b7;border-radius:6px;padding:12px;margin-top:8px;}
    .note{font-size:1.25rem;font-weight:700;color:#1B6B3A;}
    @media print{body{margin:20px;}h2{page-break-before:always;}}</style></head><body>
    <h1>Devoirs rendus — ${etudiant.prenom} ${etudiant.nom}</h1>
    <p style="color:#6b7280">BTS MOS — Pôle 3 — Exporté le ${new Date().toLocaleDateString('fr-FR')}</p>
    ${(devoirs ?? []).map((d: { seance_id: string; remis_at: string; note: number; bareme: number; commentaire_prof: string; correction_envoyee: boolean; corrections_par_question: Record<string, { commentaire: string; points: string }>; contenu: Record<string, string> }) => {
      const seance = SEANCES.find(s => s.id === d.seance_id)
      return `<h2>S${seance?.numero} — ${seance?.titre ?? d.seance_id} — Rendu le ${new Date(d.remis_at).toLocaleDateString('fr-FR')}</h2>
      ${d.note !== null && d.note !== undefined ? `<div class="note">${d.note} / ${d.bareme}</div>` : ''}
      ${d.commentaire_prof ? `<div class="correction"><strong>Commentaire général :</strong> ${d.commentaire_prof}</div>` : ''}
      ${Object.entries(d.contenu ?? {}).map(([key, val], i) => `
        <div class="question">
          <div class="label">Question ${i + 1}</div>
          <div class="reponse">${val || '<em>Pas de réponse</em>'}</div>
          ${d.corrections_par_question?.[key] ? `<div class="correction">
            ${d.corrections_par_question[key].commentaire ? `<p>${d.corrections_par_question[key].commentaire}</p>` : ''}
            ${d.corrections_par_question[key].points ? `<strong>${d.corrections_par_question[key].points} pts</strong>` : ''}
          </div>` : ''}
        </div>`).join('')}`
    }).join('')}
    </body></html>`

    ouvrir(html)
    setGeneration(null)
  }

  const ouvrir = (html: string) => {
    const w = window.open('', '_blank')
    if (!w) return
    w.document.write(html)
    w.document.close()
    setTimeout(() => w.print(), 500)
  }

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Tableau de bord</button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Exports PDF</span>
        <div style={{ width: '100px' }} />
      </header>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        <p style={{ fontSize: '0.875rem', color: '#6B7280', marginBottom: '1.25rem' }}>
          Choisissez un étudiant et le type d'export. Le document s'ouvrira dans un nouvel onglet — utilisez l'impression du navigateur pour générer le PDF.
        </p>

        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
        ) : etudiants.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun étudiant inscrit.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {etudiants.map((e, i) => (
              <motion.div key={e.user_id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '10px', padding: '1rem 1.25rem' }}>
                <div style={{ fontSize: '0.9rem', fontWeight: '700', color: '#111827', marginBottom: '0.75rem' }}>
                  {e.prenom} {e.nom}
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {[
                    { label: 'Journal de bord', fn: () => exporterJournal(e), key: e.user_id + '_journal' },
                    { label: 'Résultats', fn: () => exporterResultats(e), key: e.user_id + '_resultats' },
                    { label: 'Devoirs + corrections', fn: () => exporterDevoirs(e), key: e.user_id + '_devoirs' },
                  ].map(btn => (
                    <motion.button key={btn.key} whileTap={{ scale: 0.97 }} onClick={btn.fn}
                      disabled={generation === btn.key}
                      style={{ backgroundColor: generation === btn.key ? '#D1D5DB' : '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '7px', padding: '0.5rem 1rem', fontSize: '0.8rem', fontWeight: '600', cursor: generation === btn.key ? 'default' : 'pointer', fontFamily: 'Arial' }}>
                      {generation === btn.key ? 'Génération...' : btn.label}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

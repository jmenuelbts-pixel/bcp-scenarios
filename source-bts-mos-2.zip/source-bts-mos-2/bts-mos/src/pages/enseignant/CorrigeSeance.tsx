import { useNavigate, useParams } from 'react-router-dom'
import { SEANCES } from '../../data/schema'
import { getContenuSeance } from '../../data/contenus'
import OngletFiche from '../../components/capsule/OngletFiche'
import OngletPresentiel from '../../components/capsule/OngletPresentiel'

export default function CorrigeSeance() {
  const navigate = useNavigate()
  const { seanceId } = useParams<{ seanceId: string }>()
  const seance = SEANCES.find(s => s.id === seanceId)
  const contenu = seanceId ? getContenuSeance(seanceId) : undefined

  if (!seance) return <div style={{ padding: '2rem', fontFamily: 'Arial' }}>Séance introuvable.</div>

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Retour
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Corrigé — S{seance.numero}</span>
        <div style={{ width: '80px' }} />
      </header>

      <div style={{ backgroundColor: seance.couleur, padding: '0.875rem 1.25rem' }}>
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.7rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.2rem 0' }}>
          Séance {seance.numero} — Corrigé enseignant
        </p>
        <h1 style={{ color: '#FFFFFF', fontSize: '1rem', fontWeight: '700', margin: 0, lineHeight: '1.35' }}>
          {seance.titre}
        </h1>
      </div>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        {!contenu ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>
            Contenu non disponible pour cette séance.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Fiche ressource */}
            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: seance.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.75rem' }}>
                Fiche ressource
              </div>
              <OngletFiche fiche={contenu.fiche_ressource} couleur={seance.couleur} seanceId={seance.id} />
            </div>

            {/* Corrigé du cours présentiel */}
            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: seance.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.75rem' }}>
                Corrigé — Cours en présentiel
              </div>
              <OngletPresentiel cours={contenu.cours_presentiel} couleur={seance.couleur} seanceId={seance.id} />
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

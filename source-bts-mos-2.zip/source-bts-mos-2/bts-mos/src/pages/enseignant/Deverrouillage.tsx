import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { THEMES, SEANCES } from '../../data/schema'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'

interface Deverrouillage {
  id: string
  seance_id: string
  user_id: string
  ouvert_a: string
  ferme_a: string | null
}

type Filtre = 'tous' | 'ouverts' | 'fermes'

export default function Deverrouillage() {
  const navigate = useNavigate()
  const [deverrouillages, setDeverrouillages] = useState<Deverrouillage[]>([])
  const [chargement, setChargement] = useState(true)
  const [filtre, setFiltre] = useState<Filtre>('tous')
  const [traitement, setTraitement] = useState<string | null>(null)
  const [message, setMessage] = useState<{ texte: string; type: 'succes' | 'erreur' } | null>(null)

  const charger = async () => {
    const { data } = await supabase
      .from('deverrouillages')
      .select('*')
      .order('ouvert_a', { ascending: false })
    setDeverrouillages((data as Deverrouillage[]) ?? [])
    setChargement(false)
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => { charger() }, [])

  const maintenant = () => new Date().toISOString()

  const ouvrirTous = async (seanceId: string) => {
    setTraitement(seanceId + '_ouvrir')
    setMessage(null)
    // Fermer les anciens si existants
    await supabase
      .from('deverrouillages')
      .update({ ferme_a: maintenant() })
      .eq('seance_id', seanceId)
      .eq('user_id', 'all')
      .is('ferme_a', null)

    const { error } = await supabase
      .from('deverrouillages')
      .insert({ seance_id: seanceId, user_id: 'all', onglet: 'all', ouvert_a: maintenant(), ferme_a: null })

    if (error) {
      setMessage({ texte: 'Erreur : ' + error.message, type: 'erreur' })
    } else {
      setMessage({ texte: 'Séance ouverte pour tous les étudiants.', type: 'succes' })
      await charger()
    }
    setTraitement(null)
    setTimeout(() => setMessage(null), 3000)
  }

  const fermerTous = async (seanceId: string) => {
    setTraitement(seanceId + '_fermer')
    setMessage(null)
    const { error } = await supabase
      .from('deverrouillages')
      .update({ ferme_a: maintenant() })
      .eq('seance_id', seanceId)
      .eq('user_id', 'all')
      .is('ferme_a', null)

    if (error) {
      setMessage({ texte: 'Erreur : ' + error.message, type: 'erreur' })
    } else {
      setMessage({ texte: 'Séance fermée.', type: 'succes' })
      await charger()
    }
    setTraitement(null)
    setTimeout(() => setMessage(null), 3000)
  }

  const estOuverte = (seanceId: string) =>
    deverrouillages.some(d => d.seance_id === seanceId && d.user_id === 'all' && !d.ferme_a)

  const seancesFiltrees = SEANCES.filter(s => {
    if (filtre === 'ouverts') return estOuverte(s.id)
    if (filtre === 'fermes') return !estOuverte(s.id)
    return true
  })

  const nbOuverts = SEANCES.filter(s => estOuverte(s.id)).length

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; Tableau de bord
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Déverrouillage</span>
        <div style={{ width: '100px' }} />
      </header>

      <BandeauHorsLigne />

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>

        {/* Message retour */}
        <AnimatePresence>
          {message && (
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              style={{ backgroundColor: message.type === 'succes' ? '#D1FAE5' : '#FEE2E2', border: `1px solid ${message.type === 'succes' ? '#6EE7B7' : '#FECACA'}`, borderRadius: '8px', padding: '0.75rem 1rem', marginBottom: '1rem', fontSize: '0.875rem', color: message.type === 'succes' ? '#065F46' : '#991B1B' }}>
              {message.texte}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bandeau résumé */}
        <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem 1.25rem', border: '1px solid #D1D5DB', marginBottom: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1B6B3A' }}>{nbOuverts} / {SEANCES.length}</div>
            <div style={{ fontSize: '0.8rem', color: '#6B7280' }}>séances ouvertes</div>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button onClick={async () => {
              if (!confirm('Ouvrir TOUTES les séances pour tous les étudiants ?')) return
              setTraitement('global_ouvrir')
              for (const s of SEANCES) { if (!estOuverte(s.id)) await ouvrirTous(s.id) }
              setTraitement(null)
              setMessage({ texte: 'Toutes les séances ont été ouvertes.', type: 'succes' })
              setTimeout(() => setMessage(null), 3000)
            }}
              style={{ backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '7px', padding: '0.5rem 0.875rem', fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
              Tout ouvrir
            </button>
            <button onClick={async () => {
              if (!confirm('Fermer TOUTES les séances ?')) return
              setTraitement('global_fermer')
              for (const s of SEANCES) { if (estOuverte(s.id)) await fermerTous(s.id) }
              setTraitement(null)
              setMessage({ texte: 'Toutes les séances ont été fermées.', type: 'succes' })
              setTimeout(() => setMessage(null), 3000)
            }}
              style={{ backgroundColor: '#FFFFFF', color: '#374151', border: '1px solid #D1D5DB', borderRadius: '7px', padding: '0.5rem 0.875rem', fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
              Tout fermer
            </button>
          </div>
        </div>

        {/* Filtres */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
          {(['tous', 'ouverts', 'fermes'] as Filtre[]).map(f => (
            <button key={f} onClick={() => setFiltre(f)}
              style={{ padding: '0.4rem 1rem', borderRadius: '9999px', border: `1.5px solid ${filtre === f ? '#1B6B3A' : '#D1D5DB'}`, backgroundColor: filtre === f ? '#1B6B3A' : '#FFFFFF', color: filtre === f ? '#FFFFFF' : '#374151', fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
              {f === 'tous' ? 'Toutes' : f === 'ouverts' ? 'Ouvertes' : 'Fermées'}
            </button>
          ))}
        </div>

        {/* Liste par thème */}
        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
        ) : (
          THEMES.map(theme => {
            const seancesDuTheme = seancesFiltrees.filter(s => s.theme_id === theme.id)
            if (seancesDuTheme.length === 0) return null
            return (
              <div key={theme.id} style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '700', color: theme.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem', paddingLeft: '0.25rem' }}>
                  Thème {theme.numero} — {theme.titre}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {seancesDuTheme.map(seance => {
                    const ouverte = estOuverte(seance.id)
                    const enTraitement = traitement === seance.id + '_ouvrir' || traitement === seance.id + '_fermer' || traitement === 'global_ouvrir' || traitement === 'global_fermer'
                    return (
                      <div key={seance.id}
                        style={{ backgroundColor: '#FFFFFF', border: `1px solid ${ouverte ? '#6EE7B7' : '#E5E7EB'}`, borderRadius: '10px', padding: '0.875rem 1rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        {/* Indicateur */}
                        <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: ouverte ? '#10B981' : '#D1D5DB', flexShrink: 0 }} />
                        {/* Numéro */}
                        <div style={{ backgroundColor: theme.couleur, color: '#FFFFFF', borderRadius: '50%', width: '30px', height: '30px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: '700', flexShrink: 0 }}>
                          {seance.numero}
                        </div>
                        {/* Titre */}
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '0.8rem', fontWeight: '600', color: '#111827', lineHeight: '1.3' }}>{seance.titre}</div>
                          <div style={{ fontSize: '0.7rem', color: ouverte ? '#059669' : '#9CA3AF', marginTop: '0.1rem' }}>
                            {ouverte ? 'Ouverte — accessible aux étudiants' : 'Verrouillée'}
                          </div>
                        </div>
                        {/* Bouton */}
                        <motion.button
                          whileTap={{ scale: 0.96 }}
                          disabled={enTraitement}
                          onClick={() => ouverte ? fermerTous(seance.id) : ouvrirTous(seance.id)}
                          style={{
                            backgroundColor: ouverte ? '#FEF2F2' : '#F0FDF4',
                            color: ouverte ? '#DC2626' : '#059669',
                            border: `1px solid ${ouverte ? '#FECACA' : '#6EE7B7'}`,
                            borderRadius: '7px',
                            padding: '0.4rem 0.875rem',
                            fontSize: '0.8rem',
                            fontWeight: '600',
                            cursor: enTraitement ? 'not-allowed' : 'pointer',
                            fontFamily: 'Arial',
                            flexShrink: 0,
                            opacity: enTraitement ? 0.6 : 1,
                          }}>
                          {enTraitement ? '...' : ouverte ? 'Fermer' : 'Ouvrir'}
                        </motion.button>
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })
        )}
      </main>
    </div>
  )
}

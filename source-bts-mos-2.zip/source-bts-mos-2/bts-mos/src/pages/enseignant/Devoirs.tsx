import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { SEANCES } from '../../data/schema'

interface Devoir {
  id: string
  seance_id: string
  user_id: string
  statut: string
  remis_at: string
  nom: string | null
  prenom: string | null
  correction_envoyee?: boolean
  commentaire_prof?: string
}

export default function Devoirs() {
  const navigate = useNavigate()
  const [devoirs, setDevoirs] = useState<Devoir[]>([])
  const [chargement, setChargement] = useState(true)
  const [filtre, setFiltre] = useState<'tous' | 'remis' | 'brouillon'>('remis')
  const [supprimant, setSupprimant] = useState<string | null>(null)

  const supprimerDevoir = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (!confirm('Supprimer définitivement ce devoir ?')) return
    setSupprimant(id)
    await supabase.from('devoirs').delete().eq('id', id)
    setDevoirs(d => d.filter(x => x.id !== id))
    setSupprimant(null)
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => {
    const charger = async () => {
      const { data: dev } = await supabase.from('devoirs').select('*').order('remis_at', { ascending: false })
      const { data: inscrits } = await supabase.from('demandes_inscription').select('user_id, nom, prenom')

      const liste: Devoir[] = (dev ?? [])
        .map((d: { id: string; seance_id: string; user_id: string; statut: string; remis_at: string }) => {
          const etudiant = (inscrits ?? []).find((i: { user_id: string }) => i.user_id === d.user_id) as { nom: string; prenom: string } | undefined
          return { ...d, nom: etudiant?.nom ?? null, prenom: etudiant?.prenom ?? null }
        })
        .filter((d: any) => d.nom !== null)
      setDevoirs(liste)
      setChargement(false)
    }
    charger()
  }, [])

  const fmt = (iso: string) => iso ? new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—'

  const filtres = devoirs.filter(d => filtre === 'tous' ? true : d.statut === filtre)
  const nbRemis = devoirs.filter(d => d.statut === 'remis').length

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Tableau de bord</button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Travaux à rendre</span>
        <div style={{ width: '100px' }} />
      </header>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>
        {/* Résumé */}
        <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem 1.25rem', border: '1px solid #E5E7EB', marginBottom: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1B6B3A' }}>{nbRemis}</div>
            <div style={{ fontSize: '0.8rem', color: '#6B7280' }}>devoir{nbRemis > 1 ? 's' : ''} rendu{nbRemis > 1 ? 's' : ''}</div>
          </div>
          <div style={{ fontSize: '0.875rem', color: '#9CA3AF' }}>{devoirs.length - nbRemis} brouillon{devoirs.length - nbRemis > 1 ? 's' : ''}</div>
        </div>

        {/* Filtres */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
          {(['remis', 'tous', 'brouillon'] as const).map(f => (
            <button key={f} onClick={() => setFiltre(f)}
              style={{ padding: '0.4rem 1rem', borderRadius: '9999px', border: `1.5px solid ${filtre === f ? '#1B6B3A' : '#D1D5DB'}`, backgroundColor: filtre === f ? '#1B6B3A' : '#FFFFFF', color: filtre === f ? '#FFFFFF' : '#374151', fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial' }}>
              {f === 'remis' ? 'Rendus' : f === 'tous' ? 'Tous' : 'Brouillons'}
            </button>
          ))}
        </div>

        {/* Bouton envoyer toutes les corrections */}
        {devoirs.filter(d => d.statut === 'remis' && !d.correction_envoyee && d.commentaire_prof).length > 0 && (
          <motion.button whileTap={{ scale: 0.97 }}
            onClick={async () => {
              const aEnvoyer = devoirs.filter((d: any) => d.statut === 'remis' && !d.correction_envoyee && d.commentaire_prof)
              if (!confirm(`Envoyer ${aEnvoyer.length} correction(s) aux étudiants ?`)) return
              for (const d of aEnvoyer) {
                await supabase.from('devoirs').update({ correction_envoyee: true, correction_envoyee_at: new Date().toISOString() }).eq('id', d.id)
              }
              alert(`${aEnvoyer.length} correction(s) envoyée(s).`)
              window.location.reload()
            }}
            style={{ width: '100%', backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.75rem', fontSize: '0.875rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial', marginBottom: '1rem' }}>
            Envoyer toutes les corrections rédigées
          </motion.button>
        )}

        {chargement ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
        ) : filtres.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun devoir.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {filtres.map((d, i) => {
              const seance = SEANCES.find(s => s.id === d.seance_id)
              return (
                <motion.div key={d.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  style={{ backgroundColor: '#FFFFFF', border: `1px solid ${d.statut === 'remis' ? '#E5E7EB' : '#FEF3C7'}`, borderRadius: '10px', overflow: 'hidden' }}>
                  <button onClick={() => navigate(`/enseignant/devoirs/${d.id}`)}
                    style={{ width: '100%', padding: '1rem 1.25rem', cursor: 'pointer', textAlign: 'left', fontFamily: 'Arial', background: 'none', border: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '700', color: '#111827' }}>{d.prenom} {d.nom}</div>
                      <div style={{ fontSize: '0.75rem', color: '#6B7280', marginTop: '0.2rem' }}>S{seance?.numero} — {seance?.titre.substring(0, 40)}{(seance?.titre.length ?? 0) > 40 ? '...' : ''}</div>
                      <div style={{ fontSize: '0.7rem', color: '#9CA3AF', marginTop: '0.1rem' }}>{d.statut === 'remis' ? `Rendu le ${fmt(d.remis_at)}` : 'Brouillon en cours'}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem', borderRadius: '4px', backgroundColor: d.statut === 'remis' ? '#D1FAE5' : '#FEF3C7', color: d.statut === 'remis' ? '#065F46' : '#92400E', fontWeight: '700' }}>
                        {d.statut === 'remis' ? 'Rendu' : 'Brouillon'}
                      </span>
                      <svg width="14" height="14" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </div>
                  </button>
                  <div style={{ borderTop: '1px solid #F3F4F6', padding: '0.375rem 1.25rem', display: 'flex', justifyContent: 'flex-end' }}>
                    <button onClick={(e) => supprimerDevoir(d.id, e)} disabled={supprimant === d.id}
                      style={{ fontSize: '0.7rem', color: '#DC2626', background: 'none', border: '1px solid #FECACA', borderRadius: '6px', padding: '0.2rem 0.6rem', cursor: supprimant === d.id ? 'not-allowed' : 'pointer', fontFamily: 'Arial', fontWeight: '600', opacity: supprimant === d.id ? 0.5 : 1 }}>
                      {supprimant === d.id ? 'Suppression...' : 'Supprimer'}
                    </button>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}

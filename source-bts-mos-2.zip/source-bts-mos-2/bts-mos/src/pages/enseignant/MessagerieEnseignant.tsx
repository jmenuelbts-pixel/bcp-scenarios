import { useEffect, useState, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '../../lib/supabase'

interface Message { id: string; expediteur_id: string; destinataire_id: string; contenu: string; lu: boolean; created_at: string }
interface Etudiant { user_id: string; nom: string; prenom: string; nbNonLus: number }

const ENSEIGNANT_ID = 'enseignant'

export default function MessagerieEnseignant() {
  const navigate = useNavigate()
  const [etudiants, setEtudiants] = useState<Etudiant[]>([])
  const [etudiantActif, setEtudiantActif] = useState<Etudiant | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [nouveau, setNouveau] = useState('')
  const [msgGroupe, setMsgGroupe] = useState('')
  const [envoi, setEnvoi] = useState(false)
  const [envoiGroupe, setEnvoiGroupe] = useState(false)
  const [chargement, setChargement] = useState(true)
  const [supprimant, setSupprimant] = useState<string | null>(null)

  const supprimerConversation = async (userId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (!confirm('Supprimer définitivement tous les messages de cette conversation ?')) return
    setSupprimant(userId)
    await supabase.from('messages').delete().or(`expediteur_id.eq.${userId},destinataire_id.eq.${userId}`)
    setEtudiants(list => list.map(x => x.user_id === userId ? { ...x, nbNonLus: 0 } : x))
    setSupprimant(null)
  }
  const [vue, setVue] = useState<'liste' | 'conversation'>('liste')
  const bassePage = useRef<HTMLDivElement>(null)
  const etudiantActifRef = useRef<Etudiant | null>(null)

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])
useEffect(() => { etudiantActifRef.current = etudiantActif }, [etudiantActif])

  const chargerEtudiants = useCallback(async () => {
    const { data: inscrits } = await supabase.from('demandes_inscription').select('user_id, nom, prenom').eq('statut', 'accepte').order('nom')
    const { data: msgs } = await supabase.from('messages').select('expediteur_id, lu')
    const liste: Etudiant[] = (inscrits ?? []).map((e: { user_id: string; nom: string; prenom: string }) => ({
      user_id: e.user_id, nom: e.nom, prenom: e.prenom,
      nbNonLus: (msgs ?? []).filter((m: { expediteur_id: string; lu: boolean }) => m.expediteur_id === e.user_id && !m.lu).length
    }))
    setEtudiants(liste)
    setChargement(false)
  }, [])

  const chargerConversation = useCallback(async (uid: string) => {
    const [{ data: envoyes }, { data: recus }] = await Promise.all([
      supabase.from('messages').select('*').eq('expediteur_id', uid).eq('destinataire_id', ENSEIGNANT_ID),
      supabase.from('messages').select('*').eq('expediteur_id', ENSEIGNANT_ID).eq('destinataire_id', uid),
    ])
    const tous = [...(envoyes ?? []), ...(recus ?? [])]
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    setMessages(tous as Message[])
  }, [])

  useEffect(() => {
    chargerEtudiants()
    const channel = supabase.channel('msgs-enseignant')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
        chargerEtudiants()
        if (etudiantActifRef.current) chargerConversation(etudiantActifRef.current.user_id)
      })
      .subscribe()
    return () => { channel.unsubscribe() }
  }, [chargerEtudiants, chargerConversation])

  useEffect(() => { bassePage.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const ouvrirConversation = async (e: Etudiant) => {
    setEtudiantActif(e)
    setVue('conversation')
    await chargerConversation(e.user_id)
    await supabase.from('messages').update({ lu: true }).eq('expediteur_id', e.user_id).eq('lu', false)
    chargerEtudiants()
  }

  const envoyerAEtudiant = async () => {
    if (!nouveau.trim() || !etudiantActif || envoi) return
    setEnvoi(true)
    const { error } = await supabase.from('messages').insert({
      expediteur_id: ENSEIGNANT_ID, destinataire_id: etudiantActif.user_id, contenu: nouveau.trim(), lu: false,
    })
    if (!error) { setNouveau(''); chargerConversation(etudiantActif.user_id) }
    setEnvoi(false)
  }

  const envoyerATous = async () => {
    if (!msgGroupe.trim() || envoiGroupe) return
    if (!confirm(`Envoyer à tous les ${etudiants.length} étudiants ?`)) return
    setEnvoiGroupe(true)
    await supabase.from('messages').insert({ expediteur_id: ENSEIGNANT_ID, destinataire_id: 'groupe', contenu: msgGroupe.trim(), lu: false })
    setMsgGroupe('')
    setEnvoiGroupe(false)
  }

  const fmt = (iso: string) => {
    const d = new Date(iso)
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
  }

  const totalNonLus = etudiants.reduce((s, e) => s + e.nbNonLus, 0)

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', display: 'flex', flexDirection: 'column', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => vue === 'conversation' ? (setVue('liste'), setEtudiantActif(null)) : navigate('/enseignant')}
          style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>
          &larr; {vue === 'conversation' ? 'Retour' : 'Tableau de bord'}
        </button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>
          {vue === 'conversation' && etudiantActif ? `${etudiantActif.prenom} ${etudiantActif.nom}` : 'Messagerie'}
        </span>
        <div style={{ width: '100px' }} />
      </header>

      {vue === 'liste' ? (
        <main style={{ flex: 1, padding: '1.25rem 1rem', maxWidth: '600px', width: '100%', margin: '0 auto' }}>
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem', border: '1px solid #D1D5DB', marginBottom: '1.25rem' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151', marginBottom: '0.5rem' }}>Message au groupe ({etudiants.length} étudiant{etudiants.length > 1 ? 's' : ''})</div>
            <textarea value={msgGroupe} onChange={e => setMsgGroupe(e.target.value)} placeholder="Écrire pour tous..." rows={2}
              style={{ width: '100%', padding: '0.625rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'none', boxSizing: 'border-box', marginBottom: '0.5rem' }} />
            <button onClick={envoyerATous} disabled={envoiGroupe || !msgGroupe.trim()}
              style={{ backgroundColor: msgGroupe.trim() ? '#1B6B3A' : '#D1D5DB', color: '#FFFFFF', border: 'none', borderRadius: '7px', padding: '0.5rem 1rem', fontSize: '0.875rem', fontWeight: '600', cursor: msgGroupe.trim() ? 'pointer' : 'default', fontFamily: 'Arial' }}>
              {envoiGroupe ? '...' : 'Envoyer au groupe'}
            </button>
          </div>

          <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>
            Conversations {totalNonLus > 0 && `— ${totalNonLus} non lu${totalNonLus > 1 ? 's' : ''}`}
          </div>

          {chargement ? <div style={{ textAlign: 'center', padding: '2rem', color: '#9CA3AF' }}>Chargement...</div>
            : etudiants.length === 0 ? <div style={{ textAlign: 'center', padding: '2rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun étudiant inscrit.</div>
            : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {etudiants.map(e => (
                  <motion.div key={e.user_id}
                    style={{ backgroundColor: '#FFFFFF', border: `1px solid ${e.nbNonLus > 0 ? '#FCD34D' : '#E5E7EB'}`, borderRadius: '10px', overflow: 'hidden' }}>
                    <button onClick={() => ouvrirConversation(e)}
                      style={{ width: '100%', padding: '0.875rem 1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', fontFamily: 'Arial', textAlign: 'left', background: 'none', border: 'none' }}>
                      <div>
                        <div style={{ fontSize: '0.875rem', fontWeight: '600', color: '#111827' }}>{e.prenom} {e.nom}</div>
                        <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: '0.1rem' }}>Voir la conversation</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        {e.nbNonLus > 0 && <div style={{ backgroundColor: '#EF4444', color: '#FFFFFF', borderRadius: '9999px', minWidth: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: '700', padding: '0 4px' }}>{e.nbNonLus}</div>}
                        <svg width="14" height="14" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                      </div>
                    </button>
                    <div style={{ borderTop: '1px solid #F3F4F6', padding: '0.375rem 1rem', display: 'flex', justifyContent: 'flex-end' }}>
                      <button onClick={(ev) => supprimerConversation(e.user_id, ev)} disabled={supprimant === e.user_id}
                        style={{ fontSize: '0.7rem', color: '#DC2626', background: 'none', border: '1px solid #FECACA', borderRadius: '6px', padding: '0.2rem 0.6rem', cursor: supprimant === e.user_id ? 'not-allowed' : 'pointer', fontFamily: 'Arial', fontWeight: '600', opacity: supprimant === e.user_id ? 0.5 : 1 }}>
                        {supprimant === e.user_id ? 'Suppression...' : 'Supprimer la conversation'}
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
        </main>
      ) : (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <main style={{ flex: 1, padding: '1rem', maxWidth: '600px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '0.75rem', overflowY: 'auto' }}>
            {messages.length === 0
              ? <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF', fontSize: '0.875rem' }}>Aucun message.</div>
              : <AnimatePresence>
                  {messages.map(m => {
                    const deMoi = m.expediteur_id === ENSEIGNANT_ID
                    return (
                      <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                        style={{ display: 'flex', flexDirection: 'column', alignItems: deMoi ? 'flex-end' : 'flex-start' }}>
                        <div style={{ backgroundColor: deMoi ? '#1B6B3A' : '#FFFFFF', color: deMoi ? '#FFFFFF' : '#111827', border: deMoi ? 'none' : '1px solid #E5E7EB', borderRadius: deMoi ? '12px 12px 2px 12px' : '12px 12px 12px 2px', padding: '0.625rem 0.875rem', maxWidth: '80%', fontSize: '0.875rem', lineHeight: '1.5' }}>
                          {!deMoi && <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#C25A00', marginBottom: '0.2rem' }}>{etudiantActif?.prenom} {etudiantActif?.nom}</div>}
                          {m.contenu}
                        </div>
                        <div style={{ fontSize: '0.7rem', color: '#9CA3AF', marginTop: '0.2rem' }}>{fmt(m.created_at)}</div>
                      </motion.div>
                    )
                  })}
                </AnimatePresence>
            }
            <div ref={bassePage} />
          </main>
          <div style={{ backgroundColor: '#FFFFFF', borderTop: '1px solid #D1D5DB', padding: '0.75rem 1rem', position: 'sticky', bottom: 0 }}>
            <div style={{ maxWidth: '600px', margin: '0 auto', display: 'flex', gap: '0.75rem', alignItems: 'flex-end' }}>
              <textarea value={nouveau} onChange={e => setNouveau(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); envoyerAEtudiant() } }}
                placeholder="Répondre..." rows={1}
                style={{ flex: 1, padding: '0.625rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'none', minHeight: '44px', lineHeight: '1.5' }} />
              <motion.button whileTap={{ scale: 0.95 }} onClick={envoyerAEtudiant} disabled={envoi || !nouveau.trim()}
                style={{ backgroundColor: nouveau.trim() ? '#1B6B3A' : '#D1D5DB', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.625rem 1rem', fontSize: '0.875rem', fontWeight: '600', cursor: nouveau.trim() ? 'pointer' : 'default', minHeight: '44px', fontFamily: 'Arial', flexShrink: 0 }}>
                {envoi ? '...' : 'Envoyer'}
              </motion.button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

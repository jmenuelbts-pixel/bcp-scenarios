import { useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { SEANCES, THEMES } from '../../data/schema'
import BandeauHorsLigne from '../../components/ui/BandeauHorsLigne'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'

type OngletTDB = 'tableau' | 'corriges' | 'apropos'

export default function AccueilEnseignant() {
  const navigate = useNavigate()
  const [onglet, setOnglet] = useState<OngletTDB>('tableau')
  const [nbEnAttente, setNbEnAttente] = useState(0)
  const [nbMsgsNonLus, setNbMsgsNonLus] = useState(0)
  const [nbDevoirs, setNbDevoirs] = useState(0)

  const charger = async () => {
    const [{ count: att }, { count: msgs }, { count: dev }] = await Promise.all([
      supabase.from('demandes_inscription').select('id', { count: 'exact', head: true }).eq('statut', 'en_attente'),
      supabase.from('messages').select('id', { count: 'exact', head: true }).eq('destinataire_id', 'enseignant').eq('lu', false),
      supabase.from('devoirs').select('id', { count: 'exact', head: true }).eq('statut', 'remis').eq('correction_envoyee', false),
    ])
    setNbEnAttente(att ?? 0)
    setNbMsgsNonLus(msgs ?? 0)
    setNbDevoirs(dev ?? 0)
  }

  // Déconnexion après 5 min d'inactivité
  useEffect(() => {
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate('/enseignant/connexion')
    })
    return stop
  }, [navigate])

  useEffect(() => {
    charger()
    const channel = supabase.channel('accueil-enseignant')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, charger)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'demandes_inscription' }, charger)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'devoirs' }, charger)
      .subscribe()
    return () => { channel.unsubscribe() }
  }, [])

  const MENU = [
    { label: "Demandes d'inscription", desc: 'Accepter ou refuser les nouveaux étudiants', path: '/enseignant/inscriptions', nb: nbEnAttente, couleur: '#FEF3C7', borderCouleur: '#FCD34D' },
    { label: 'Déverrouillage',         desc: 'Ouvrir et fermer les séances',                path: '/enseignant/deverrouillage', couleur: '#FDE8D8', borderCouleur: '#FDBA74' },
    { label: 'Exports PDF',            desc: 'Journaux de bord, résultats, devoirs',        path: '/enseignant/exports', couleur: '#FCE7F3', borderCouleur: '#F9A8D4' },
    { label: 'Gestion des comptes',    desc: 'Réinitialiser les mots de passe, gérer les accès', path: '/enseignant/gestion-comptes', couleur: '#ECFDF5', borderCouleur: '#6EE7B7' },
    { label: 'Messagerie',             desc: 'Messages individuels et collectifs',           path: '/enseignant/messagerie',    nb: nbMsgsNonLus, couleur: '#EDE9FE', borderCouleur: '#C4B5FD' },
    { label: 'Suivi des étudiants',    desc: 'Progression, connexions, résultats',         path: '/enseignant/etudiants', couleur: '#DBEAFE', borderCouleur: '#93C5FD' },
    { label: 'Travaux à rendre',       desc: 'Devoirs rendus et corrections',               path: '/enseignant/devoirs',       nb: nbDevoirs, couleur: '#D1FAE5', borderCouleur: '#6EE7B7' },
  ]

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '1rem' }}>MOS Pro P3 - Jacky MENUEL</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button onClick={() => navigate('/enseignant/messagerie')}
            style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: '44px', minWidth: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
            <svg width="22" height="22" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            {nbMsgsNonLus > 0 && (
              <div style={{ position: 'absolute', top: '6px', right: '4px', backgroundColor: '#EF4444', color: '#FFFFFF', borderRadius: '9999px', minWidth: '16px', height: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.65rem', fontWeight: '700', padding: '0 3px' }}>
                {nbMsgsNonLus > 9 ? '9+' : nbMsgsNonLus}
              </div>
            )}
          </button>
          <button onClick={() => navigate('/')}
            style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.8)', cursor: 'pointer', fontSize: '0.8rem', minHeight: '44px', fontFamily: 'Arial' }}>
            Quitter
          </button>
        </div>
      </header>

      <BandeauHorsLigne />

      {/* Onglets */}
      <div style={{ backgroundColor: '#FFFFFF', borderBottom: '1px solid #E5E7EB', display: 'flex' }}>
        {([
          { id: 'tableau', label: 'Tableau de bord' },
          { id: 'corriges', label: 'Corrigés' },
        ] as { id: OngletTDB; label: string }[]).map(o => (
          <button key={o.id} onClick={() => setOnglet(o.id)}
            style={{ padding: '0.875rem 1.25rem', border: 'none', borderBottom: `2px solid ${onglet === o.id ? '#1B6B3A' : 'transparent'}`, backgroundColor: 'transparent', color: onglet === o.id ? '#1B6B3A' : '#6B7280', fontWeight: onglet === o.id ? '700' : '400', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial' }}>
            {o.label}
          </button>
        ))}
      </div>

      <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>

        {/* Tableau de bord */}
        {onglet === 'tableau' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {MENU.map((item, i) => (
              <motion.button key={item.path}
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                whileTap={{ scale: 0.98 }} onClick={() => navigate(item.path)}
                style={{ backgroundColor: (item as any).couleur ?? '#FFFFFF', border: `1px solid ${(item as any).borderCouleur ?? '#D1D5DB'}`, borderRadius: '10px', padding: '1rem 1.25rem', cursor: 'pointer', textAlign: 'left', fontFamily: 'Arial', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontWeight: '600', color: '#111827', fontSize: '0.9375rem' }}>{item.label}</div>
                  <div style={{ fontSize: '0.8rem', color: '#6B7280', marginTop: '0.2rem' }}>{item.desc}</div>
                </div>
                {item.nb && item.nb > 0 ? (
                  <span style={{ backgroundColor: '#DC2626', color: '#FFFFFF', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: '700', padding: '0.2rem 0.6rem', marginLeft: '0.5rem', flexShrink: 0 }}>{item.nb}</span>
                ) : (
                  <svg width="14" height="14" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                )}
              </motion.button>
            ))}
          </div>
        )}

        {/* Corrigés */}
        {onglet === 'corriges' && (
          <div>
            <p style={{ fontSize: '0.875rem', color: '#6B7280', marginBottom: '1.25rem' }}>
              Accès rapide aux corrigés de chaque séance. Réservé à l'enseignant.
            </p>
            {THEMES.map(theme => (
              <div key={theme.id} style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: '700', color: theme.couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>
                  Thème {theme.numero} — {theme.titre}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {SEANCES.filter(s => s.theme_id === theme.id).map(seance => (
                    <motion.button key={seance.id} whileTap={{ scale: 0.98 }}
                      onClick={() => navigate(`/enseignant/corriges/${seance.id}`)}
                      style={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px', padding: '0.75rem 1rem', cursor: 'pointer', textAlign: 'left', fontFamily: 'Arial', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <div style={{ backgroundColor: theme.couleur, color: '#FFFFFF', borderRadius: '50%', width: '28px', height: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: '700', flexShrink: 0 }}>
                        {seance.numero}
                      </div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '600', color: '#111827', flex: 1 }}>{seance.titre}</div>
                      <svg width="14" height="14" fill="none" stroke="#D1D5DB" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </motion.button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}


      </main>
    </div>
  )
}

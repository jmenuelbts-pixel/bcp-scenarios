import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { demarrerSurveillanceInactivite, deconnecter } from '../../lib/session'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import { SEANCES } from '../../data/schema'
import { COMPETENCES } from '../../data/competences'

interface Devoir {
  id: string
  seance_id: string
  user_id: string
  contenu: Record<string, string>
  statut: string
  remis_at: string
  note: number | null
  bareme: number
  commentaire_prof: string | null
  correction_envoyee: boolean
  corrections_par_question: Record<string, { commentaire: string; points: string; competence_id?: string }>
}

export default function CorrectionDevoir() {
  const navigate = useNavigate()
  const { devoirId } = useParams<{ devoirId: string }>()
  const [devoir, setDevoir] = useState<Devoir | null>(null)
  const [etudiant, setEtudiant] = useState<{ nom: string; prenom: string } | null>(null)
  const [commentaire, setCommentaire] = useState('')
  const [note, setNote] = useState('')
  const [bareme, setBareme] = useState(20)
  const [corrQ, setCorrQ] = useState<Record<string, { commentaire: string; points: string; competence_id?: string }>>({})
  const [sauvegarde, setSauvegarde] = useState(false)
  const [envoi, setEnvoi] = useState(false)
  const [chargement, setChargement] = useState(true)
  const [timer, setTimer] = useState<ReturnType<typeof setTimeout> | null>(null)

  const calcNiveau = (pts: number, max: number): string => {
    if (max <= 0) return 'novice'
    const pct = (pts / max) * 100
    if (pct >= 90) return 'expert'
    if (pct >= 70) return 'averti'
    if (pct >= 50) return 'debrouille'
    return 'novice'
  }

  
  // Déconnexion après 20 min d'inactivité
  useEffect(() => {
    const navigate_inner = (url: string) => { window.location.href = url }
    const stop = demarrerSurveillanceInactivite(async () => {
      await deconnecter()
      navigate_inner('/enseignant/connexion')
    })
    return stop
  }, [])
useEffect(() => {
    const charger = async () => {
      const { data: dev } = await supabase.from('devoirs').select('*').eq('id', devoirId).single()
      if (!dev) return
      const d = dev as Devoir
      setDevoir(d)
      setCommentaire(d.commentaire_prof ?? '')
      setNote(d.note !== null && d.note !== undefined ? String(d.note) : '')
      setBareme(d.bareme ?? 20)
      setCorrQ(d.corrections_par_question ?? {})
      const { data: insc } = await supabase.from('demandes_inscription').select('nom, prenom').eq('user_id', d.user_id).single()
      if (insc) setEtudiant(insc as { nom: string; prenom: string })
      setChargement(false)
    }
    charger()
  }, [devoirId])

  const sauvegarderAuto = (newComm: string, newNote: string, newBareme: number, newCorrQ: Record<string, { commentaire: string; points: string }>) => {
    if (timer) clearTimeout(timer)
    setTimer(setTimeout(async () => {
      setSauvegarde(true)
      await supabase.from('devoirs').update({
        commentaire_prof: newComm,
        note: newNote !== '' ? parseFloat(newNote) : null,
        bareme: newBareme,
        corrections_par_question: newCorrQ,
      }).eq('id', devoirId)
      setTimeout(() => setSauvegarde(false), 1000)
    }, 1500))
  }

  const updateCorrQ = (key: string, champ: 'commentaire' | 'points', val: string) => {
    const n = { ...corrQ, [key]: { ...(corrQ[key] ?? { commentaire: '', points: '' }), [champ]: val } }
    setCorrQ(n)
    sauvegarderAuto(commentaire, note, bareme, n)
  }

  const envoyerCorrection = async () => {
    if (!devoirId || envoi || !devoir) return
    setEnvoi(true)

    // Sauvegarder le devoir
    await supabase.from('devoirs').update({
      commentaire_prof: commentaire,
      note: note !== '' ? parseFloat(note) : null,
      bareme,
      corrections_par_question: corrQ,
      correction_envoyee: true,
      correction_envoyee_at: new Date().toISOString(),
    }).eq('id', devoirId)

    // Enregistrer les scores par compétence
    const scores = Object.entries(corrQ)
      .filter(([, v]) => v.competence_id && v.points !== '' && bareme > 0)
      .map(([, v]) => {
        const pts = parseFloat(v.points ?? '0') || 0
        return {
          user_id: devoir.user_id,
          seance_id: devoir.seance_id,
          competence_id: v.competence_id!,
          points_obtenus: pts,
          points_max: bareme,
          niveau_auto: calcNiveau(pts, bareme),
          niveau_manuel: null,
          created_at: new Date().toISOString(),
        }
      })

    if (scores.length > 0) {
      await supabase.from('scores_competences').insert(scores)
    }

    setDevoir(d => d ? { ...d, correction_envoyee: true } : d)
    setEnvoi(false)
    alert("Correction envoyée à l'étudiant.")
  }

  const valeursNote = () => {
    const vals = []
    for (let i = 0; i <= bareme; i += 0.5) {
      vals.push(i % 1 === 0 ? String(i) : String(i.toFixed(1)))
    }
    return vals
  }

  const seance = devoir ? SEANCES.find(s => s.id === devoir.seance_id) : null
  const fmt = (iso: string) => iso ? new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—'
  const contenuEntries = devoir ? Object.entries(devoir.contenu) : []

  return (
    <div style={{ minHeight: '100dvh', backgroundColor: '#F5F5F5', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: '16px' }}>
      <header style={{ backgroundColor: '#1B6B3A', padding: '0 1rem', height: '52px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
        <button onClick={() => navigate('/enseignant/devoirs')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.85)', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial' }}>&larr; Retour</button>
        <span style={{ color: '#FFFFFF', fontWeight: '700', fontSize: '0.9rem' }}>Correction</span>
        <div style={{ fontSize: '0.75rem', color: sauvegarde ? '#86EFAC' : 'rgba(255,255,255,0.5)' }}>
          {sauvegarde ? 'Sauvegardé' : 'Auto-save'}
        </div>
      </header>

      {chargement ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Chargement...</div>
      ) : !devoir ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#9CA3AF' }}>Devoir introuvable.</div>
      ) : (
        <main style={{ padding: '1.25rem 1rem', maxWidth: '720px', margin: '0 auto' }}>

          {/* En-tête */}
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem 1.25rem', border: '1px solid #E5E7EB', marginBottom: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
            <div>
              <div style={{ fontSize: '1rem', fontWeight: '700', color: '#111827' }}>{etudiant?.prenom} {etudiant?.nom}</div>
              <div style={{ fontSize: '0.8rem', color: '#6B7280', marginTop: '0.2rem' }}>S{seance?.numero} — {seance?.titre}</div>
              <div style={{ fontSize: '0.75rem', color: '#9CA3AF', marginTop: '0.2rem' }}>Rendu le {fmt(devoir.remis_at)}</div>
              {devoir.correction_envoyee && <div style={{ fontSize: '0.75rem', color: '#059669', marginTop: '0.2rem', fontWeight: '600' }}>Correction envoyée</div>}
            </div>
            {/* Note globale */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.5rem', flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ fontSize: '0.75rem', color: '#6B7280' }}>Sur</span>
                <select value={bareme} onChange={e => { const b = parseInt(e.target.value); setBareme(b); setNote(''); sauvegarderAuto(commentaire, '', b, corrQ) }}
                  style={{ padding: '0.25rem 0.5rem', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '0.875rem', fontFamily: 'Arial' }}>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                </select>
              </div>
              <select value={note} onChange={e => { setNote(e.target.value); sauvegarderAuto(commentaire, e.target.value, bareme, corrQ) }}
                style={{ padding: '0.4rem 0.75rem', border: '2px solid #1B6B3A', borderRadius: '8px', fontSize: '1.125rem', fontWeight: '700', fontFamily: 'Arial', color: '#111827', minWidth: '90px' }}>
                <option value=''>— /{bareme}</option>
                {valeursNote().map(v => <option key={v} value={v}>{v} /{bareme}</option>)}
              </select>
            </div>
          </div>

          {/* Réponses + correction par question */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.25rem' }}>
            {contenuEntries.map(([key, valeur], i) => (
              <div key={key} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
                {/* Réponse étudiant */}
                <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid #F3F4F6' }}>
                  <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
                    Question {i + 1} — Réponse de l'étudiant
                  </div>
                  <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.6', margin: 0, whiteSpace: 'pre-wrap' }}>
                    {valeur || <span style={{ color: '#D1D5DB', fontStyle: 'italic' }}>Pas de réponse</span>}
                  </p>
                </div>
                {/* Zone correction prof */}
                <div style={{ padding: '0.875rem 1.25rem', backgroundColor: '#F0FDF4' }}>
                  <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#1B6B3A', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
                    Votre correction — Q{i + 1}
                  </div>
                  <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                    <textarea value={corrQ[key]?.commentaire ?? ''} onChange={e => updateCorrQ(key, 'commentaire', e.target.value)}
                      placeholder="Commentaire sur cette réponse..." rows={2}
                      style={{ flex: 1, padding: '0.5rem 0.75rem', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '0.8rem', fontFamily: 'Arial', resize: 'vertical', backgroundColor: '#FFFFFF' }} />
                    <input type="text" value={corrQ[key]?.points ?? ''} onChange={e => updateCorrQ(key, 'points', e.target.value)}
                      placeholder="pts"
                      style={{ width: '60px', padding: '0.5rem', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '0.875rem', fontFamily: 'Arial', textAlign: 'center', backgroundColor: '#FFFFFF', flexShrink: 0 }} />
                  </div>
                  {/* Menu compétence */}
                  <div style={{ marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.65rem', fontWeight: '700', color: '#1B6B3A', textTransform: 'uppercase', letterSpacing: '0.04em', flexShrink: 0 }}>Compétence :</span>
                    <select
                      value={corrQ[key]?.competence_id ?? ''}
                      onChange={e => {
                        const n = { ...corrQ, [key]: { ...(corrQ[key] ?? { commentaire: '', points: '' }), competence_id: e.target.value } }
                        setCorrQ(n)
                        sauvegarderAuto(commentaire, note, bareme, n)
                      }}
                      style={{ flex: 1, padding: '0.3rem 0.5rem', border: '1px solid #D1D5DB', borderRadius: '6px', fontSize: '0.75rem', fontFamily: 'Arial', backgroundColor: '#FFFFFF', color: corrQ[key]?.competence_id ? '#111827' : '#9CA3AF' }}>
                      <option value=''>-- Aucune compétence --</option>
                      {COMPETENCES.map(c => (
                        <option key={c.id} value={c.id}>{c.code} — {c.libelle}</option>
                      ))}
                    </select>
                    {corrQ[key]?.competence_id && corrQ[key]?.points !== '' && bareme > 0 && (() => {
                      const pts = parseFloat(corrQ[key]?.points ?? '0') || 0
                      const niv = calcNiveau(pts, bareme)
                      const couleurs: Record<string, string> = { novice: '#DC2626', debrouille: '#D97706', averti: '#16A34A', expert: '#15803D' }
                      const labels: Record<string, string> = { novice: 'Novice', debrouille: 'Débrouillé', averti: 'Averti', expert: 'Expert' }
                      return (
                        <span style={{ fontSize: '0.65rem', fontWeight: '700', padding: '0.2rem 0.5rem', borderRadius: '4px', backgroundColor: couleurs[niv] + '20', color: couleurs[niv], flexShrink: 0 }}>
                          {labels[niv]}
                        </span>
                      )
                    })()}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Commentaire général */}
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #E5E7EB', marginBottom: '1.25rem' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: '700', color: '#374151', marginBottom: '0.75rem' }}>Commentaire général</div>
            <textarea value={commentaire} onChange={e => { setCommentaire(e.target.value); sauvegarderAuto(e.target.value, note, bareme, corrQ) }}
              placeholder="Commentaire global sur le devoir..." rows={4}
              style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.6' }} />
          </div>

          {/* Bouton envoyer */}
          {!devoir.correction_envoyee ? (
            <motion.button whileTap={{ scale: 0.97 }} onClick={envoyerCorrection} disabled={envoi}
              style={{ width: '100%', backgroundColor: '#1B6B3A', color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '0.9rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial' }}>
              {envoi ? 'Envoi...' : "Envoyer la correction à l'étudiant"}
            </motion.button>
          ) : (
            <div style={{ textAlign: 'center', padding: '0.875rem', backgroundColor: '#D1FAE5', borderRadius: '8px', fontSize: '0.875rem', color: '#065F46', fontWeight: '600' }}>
              Correction déjà envoyée à l'étudiant
            </div>
          )}
        </main>
      )}
    </div>
  )
}

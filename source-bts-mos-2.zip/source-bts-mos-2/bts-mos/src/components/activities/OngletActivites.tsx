import { useState } from 'react'
import { motion } from 'framer-motion'
import type { Activites } from '../../data/schema'

interface Props { activites: Activites; couleur: string; seanceId: string }

const TABS = [
  { id: 'flashcards', label: 'Flashcards' },
  { id: 'quiz', label: 'Quiz' },
  { id: 'glossaire', label: 'Glossaire' },
  { id: 'associations', label: 'Associations' },
]

export default function OngletActivites({ activites, couleur }: Props) {
  const [tabActif, setTabActif] = useState('flashcards')

  // Flashcards
  const [fcIndex, setFcIndex] = useState(0)
  const [fcRetourne, setFcRetourne] = useState(false)

  // Quiz
  const [qzIndex, setQzIndex] = useState(0)
  const [qzReponse, setQzReponse] = useState<number | null>(null)
  const [qzScore, setQzScore] = useState(0)
  const [qzTermine, setQzTermine] = useState(false)

  // Associations
  const [assocReponses, setAssocReponses] = useState<Record<string, string>>({})

  return (
    <div>
      {/* Sous-onglets */}
      <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', marginBottom: '1.5rem', paddingBottom: '0.25rem' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setTabActif(tab.id)}
            style={{
              padding: '0.5rem 1rem', borderRadius: '9999px',
              border: `1.5px solid ${tabActif === tab.id ? couleur : '#D1D5DB'}`,
              backgroundColor: tabActif === tab.id ? couleur : '#FFFFFF',
              color: tabActif === tab.id ? '#FFFFFF' : '#374151',
              fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer',
              whiteSpace: 'nowrap', fontFamily: 'Arial', minHeight: '36px',
            }}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* FLASHCARDS */}
      {tabActif === 'flashcards' && activites.flashcards.length > 0 && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#6B7280' }}>{fcIndex + 1} / {activites.flashcards.length}</span>
            <button onClick={() => { setFcIndex(0); setFcRetourne(false) }}
              style={{ background: 'none', border: 'none', color: '#9CA3AF', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Arial' }}>
              Recommencer
            </button>
          </div>

          <motion.div whileTap={{ scale: 0.98 }} onClick={() => setFcRetourne(r => !r)}
            style={{ backgroundColor: fcRetourne ? couleur : '#FFFFFF', borderRadius: '12px', padding: '2rem 1.5rem', border: `2px solid ${couleur}`, cursor: 'pointer', minHeight: '180px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', transition: 'background-color 0.3s' }}>
            <p style={{ fontSize: '0.7rem', fontWeight: '700', color: fcRetourne ? 'rgba(255,255,255,0.7)' : couleur, textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.75rem 0' }}>
              {fcRetourne ? 'Réponse' : 'Question'}
            </p>
            <p style={{ fontSize: '1rem', fontWeight: fcRetourne ? '400' : '600', color: fcRetourne ? '#FFFFFF' : '#111827', margin: 0, lineHeight: '1.5' }}>
              {fcRetourne ? activites.flashcards[fcIndex].verso : activites.flashcards[fcIndex].recto}
            </p>
            {!fcRetourne && <p style={{ fontSize: '0.75rem', color: '#9CA3AF', margin: '1rem 0 0 0' }}>Appuyez pour voir la réponse</p>}
          </motion.div>

          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem' }}>
            <button onClick={() => { setFcIndex(i => Math.max(0, i - 1)); setFcRetourne(false) }}
              disabled={fcIndex === 0}
              style={{ flex: 1, backgroundColor: fcIndex === 0 ? '#F3F4F6' : '#F9FAFB', border: '1px solid #D1D5DB', borderRadius: '8px', padding: '0.75rem', fontSize: '0.875rem', fontWeight: '600', color: fcIndex === 0 ? '#9CA3AF' : '#374151', cursor: fcIndex === 0 ? 'not-allowed' : 'pointer', fontFamily: 'Arial', minHeight: '44px' }}>
              Précédente
            </button>
            <button onClick={() => { setFcIndex(i => Math.min(activites.flashcards.length - 1, i + 1)); setFcRetourne(false) }}
              disabled={fcIndex === activites.flashcards.length - 1}
              style={{ flex: 1, backgroundColor: fcIndex === activites.flashcards.length - 1 ? '#F3F4F6' : couleur, border: 'none', borderRadius: '8px', padding: '0.75rem', fontSize: '0.875rem', fontWeight: '600', color: fcIndex === activites.flashcards.length - 1 ? '#9CA3AF' : '#FFFFFF', cursor: fcIndex === activites.flashcards.length - 1 ? 'not-allowed' : 'pointer', fontFamily: 'Arial', minHeight: '44px' }}>
              Suivante
            </button>
          </div>
        </div>
      )}

      {/* QUIZ */}
      {tabActif === 'quiz' && activites.quiz.length > 0 && (
        <div>
          {qzTermine ? (
            <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '2rem', border: '1px solid #D1D5DB', textAlign: 'center' }}>
              <p style={{ fontSize: '2rem', fontWeight: '700', color: couleur, margin: '0 0 0.5rem 0' }}>{qzScore}/{activites.quiz.length}</p>
              <p style={{ color: '#6B7280', margin: '0 0 1.5rem 0' }}>Quiz terminé</p>
              <button onClick={() => { setQzIndex(0); setQzReponse(null); setQzScore(0); setQzTermine(false) }}
                style={{ backgroundColor: couleur, color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.75rem 1.5rem', fontSize: '0.875rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial', minHeight: '44px' }}>
                Recommencer
              </button>
            </div>
          ) : (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                <span style={{ fontSize: '0.8rem', color: '#6B7280' }}>Question {qzIndex + 1}/{activites.quiz.length}</span>
                <span style={{ fontSize: '0.8rem', color: couleur, fontWeight: '600' }}>Score : {qzScore}</span>
              </div>

              <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB', marginBottom: '1rem' }}>
                <p style={{ fontSize: '0.9375rem', color: '#111827', margin: 0, lineHeight: '1.6', fontWeight: '600' }}>{activites.quiz[qzIndex].enonce}</p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
                {activites.quiz[qzIndex].options.map((opt, i) => {
                  let bg = '#FFFFFF', border = '#D1D5DB', color = '#374151'
                  if (qzReponse !== null) {
                    if (i === activites.quiz[qzIndex].reponse_correcte) { bg = '#D1FAE5'; border = '#6EE7B7'; color = '#065F46' }
                    else if (i === qzReponse) { bg = '#FEE2E2'; border = '#FECACA'; color = '#991B1B' }
                  }
                  return (
                    <button key={i} onClick={() => {
                      if (qzReponse !== null) return
                      setQzReponse(i)
                      if (i === activites.quiz[qzIndex].reponse_correcte) setQzScore(s => s + 1)
                    }}
                      style={{ backgroundColor: bg, border: `1.5px solid ${border}`, borderRadius: '8px', padding: '0.875rem 1rem', fontSize: '0.875rem', color, textAlign: 'left', cursor: qzReponse !== null ? 'default' : 'pointer', fontFamily: 'Arial', fontWeight: '500', minHeight: '44px' }}>
                      {opt}
                    </button>
                  )
                })}
              </div>

              {qzReponse !== null && (
                <button onClick={() => {
                  if (qzIndex < activites.quiz.length - 1) { setQzIndex(i => i + 1); setQzReponse(null) }
                  else setQzTermine(true)
                }}
                  style={{ marginTop: '1rem', width: '100%', backgroundColor: couleur, color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '0.9rem', fontWeight: '600', cursor: 'pointer', fontFamily: 'Arial', minHeight: '44px' }}>
                  {qzIndex < activites.quiz.length - 1 ? 'Question suivante' : 'Voir le résultat'}
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* GLOSSAIRE */}
      {tabActif === 'glossaire' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {activites.glossaire.map((terme, i) => (
            <motion.div key={terme.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem 1.25rem', border: '1px solid #D1D5DB', borderLeft: `3px solid ${couleur}` }}>
              <p style={{ fontSize: '0.9rem', fontWeight: '700', color: couleur, margin: '0 0 0.375rem 0' }}>{terme.terme}</p>
              <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, lineHeight: '1.6' }}>{terme.definition}</p>
            </motion.div>
          ))}
        </div>
      )}

      {/* ASSOCIATIONS */}
      {tabActif === 'associations' && (
        <div>
          <p style={{ fontSize: '0.875rem', color: '#6B7280', marginBottom: '1rem' }}>
            Associez chaque élément de gauche à son correspondant de droite.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {activites.associations.map(assoc => (
              <div key={assoc.id} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem', border: '1px solid #D1D5DB', display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                <span style={{ flex: 1, minWidth: '140px', fontSize: '0.875rem', fontWeight: '600', color: '#374151', backgroundColor: '#F9FAFB', padding: '0.5rem 0.75rem', borderRadius: '6px' }}>
                  {assoc.colonne_gauche}
                </span>
                <span style={{ color: '#9CA3AF', fontSize: '1.25rem' }}>→</span>
                <select value={assocReponses[assoc.id] ?? ''}
                  onChange={e => setAssocReponses(r => ({ ...r, [assoc.id]: e.target.value }))}
                  style={{ flex: 1, minWidth: '140px', padding: '0.5rem 0.75rem', border: `1.5px solid ${assocReponses[assoc.id] === assoc.colonne_droite ? '#16A34A' : '#D1D5DB'}`, borderRadius: '6px', fontSize: '0.85rem', fontFamily: 'Arial', backgroundColor: assocReponses[assoc.id] === assoc.colonne_droite ? '#D1FAE5' : '#FFFFFF' }}>
                  <option value="">-- Choisir --</option>
                  {activites.associations.map(a => (
                    <option key={a.id} value={a.colonne_droite}>{a.colonne_droite}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

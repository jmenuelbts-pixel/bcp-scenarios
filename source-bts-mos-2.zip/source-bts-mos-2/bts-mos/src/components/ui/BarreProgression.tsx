interface BarreProgressionProps {
  valeur: number        // 0 à 100
  couleur?: string
  hauteur?: string
  afficherPourcentage?: boolean
}

export default function BarreProgression({
  valeur,
  couleur = '#1A56A0',
  hauteur = '8px',
  afficherPourcentage = false,
}: BarreProgressionProps) {
  return (
    <div style={{ width: '100%' }}>
      {afficherPourcentage && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '0.25rem' }}>
          <span style={{ fontSize: '0.75rem', color: '#6B7280', fontFamily: 'Arial' }}>{valeur}%</span>
        </div>
      )}
      <div style={{ backgroundColor: '#F3F4F6', borderRadius: '9999px', height: hauteur, overflow: 'hidden' }}>
        <div style={{
          backgroundColor: couleur,
          height: '100%',
          width: `${Math.min(100, Math.max(0, valeur))}%`,
          borderRadius: '9999px',
          transition: 'width 0.5s ease',
        }} />
      </div>
    </div>
  )
}

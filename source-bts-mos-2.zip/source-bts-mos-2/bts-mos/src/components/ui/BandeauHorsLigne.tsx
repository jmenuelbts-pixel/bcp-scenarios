import { useEffect, useState } from 'react'

export default function BandeauHorsLigne() {
  const [horsLigne, setHorsLigne] = useState(!navigator.onLine)

  useEffect(() => {
    const enLigne = () => setHorsLigne(false)
    const horsLigneHandler = () => setHorsLigne(true)
    window.addEventListener('online', enLigne)
    window.addEventListener('offline', horsLigneHandler)
    return () => {
      window.removeEventListener('online', enLigne)
      window.removeEventListener('offline', horsLigneHandler)
    }
  }, [])

  if (!horsLigne) return null

  return (
    <div style={{
      backgroundColor: '#DC2626',
      color: '#FFFFFF',
      textAlign: 'center',
      padding: '0.5rem 1rem',
      fontSize: '0.8rem',
      fontFamily: 'Arial, Helvetica, sans-serif',
      fontWeight: '600',
      position: 'sticky',
      top: '52px',
      zIndex: 99,
    }}>
      Vous êtes hors ligne — certaines fonctionnalités sont indisponibles
    </div>
  )
}

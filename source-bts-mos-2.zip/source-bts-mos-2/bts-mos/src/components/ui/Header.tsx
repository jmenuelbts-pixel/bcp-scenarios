import { useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'

interface HeaderProps {
  titre?: string
  retourVers?: string
  couleurFond?: string
  couleurTexte?: string
  messagerieVers?: string
  afficherQuitter?: boolean
  prenom?: string
  onDeconnecter?: () => void
}

export default function Header({
  titre,
  retourVers,
  couleurFond = '#FFFFFF',
  couleurTexte = '#111827',
  messagerieVers,
  afficherQuitter = false,
  prenom,
  onDeconnecter,
}: HeaderProps) {
  const navigate = useNavigate()
  const estSombre = couleurFond !== '#FFFFFF'
  const texteCouleur = estSombre ? '#FFFFFF' : couleurTexte
  const bordure = estSombre ? 'none' : '1px solid #D1D5DB'
  const [nonLus, setNonLus] = useState(0)

  useEffect(() => {
    if (!messagerieVers) return
    let uid: string | null = null
    const charger = async () => {
      if (!uid) {
        const { data: { user } } = await supabase.auth.getUser()
        uid = user?.id ?? null
      }
      if (!uid) return
      // Messages directs non lus
      const { count: directs } = await supabase.from('messages')
        .select('id', { count: 'exact', head: true })
        .eq('destinataire_id', uid).eq('lu', false)
      // Messages enseignant non lus (pour étudiant)
      const { count: enseignant } = await supabase.from('messages')
        .select('id', { count: 'exact', head: true })
        .eq('destinataire_id', 'enseignant').eq('lu', false)
      // On prend le total pertinent selon le rôle
      setNonLus((directs ?? 0) + (messagerieVers.includes('etudiant') ? 0 : (enseignant ?? 0)))
    }
    charger()
    const channel = supabase.channel('header-msgs-' + messagerieVers)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, charger)
      .subscribe()
    return () => { channel.unsubscribe() }
  }, [messagerieVers])

  return (
    <header style={{
      backgroundColor: couleurFond,
      borderBottom: bordure,
      padding: '0 1rem',
      height: '52px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      fontFamily: 'Arial, Helvetica, sans-serif',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1 }}>
        {retourVers && (
          <button onClick={() => navigate(retourVers)}
            style={{ background: 'none', border: 'none', color: estSombre ? 'rgba(255,255,255,0.85)' : '#6B7280', cursor: 'pointer', fontSize: '0.875rem', minHeight: '44px', fontFamily: 'Arial', padding: '0' }}>
            &larr; Retour
          </button>
        )}
        {titre && !retourVers && (
          <button onClick={() => navigate('/')}
            style={{ background: 'none', border: 'none', fontWeight: '700', fontSize: '1rem', color: texteCouleur, cursor: 'pointer', minHeight: '44px', fontFamily: 'Arial', padding: '0' }}>
            {titre}
          </button>
        )}
      </div>

      {titre && retourVers && (
        <span style={{ fontWeight: '700', fontSize: '0.9rem', color: texteCouleur, textAlign: 'center', flex: 1 }}>
          {titre}
        </span>
      )}

      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: retourVers ? 1 : 'unset', justifyContent: 'flex-end' }}>
        {prenom && (
          <span style={{ fontSize: '0.8rem', color: estSombre ? 'rgba(255,255,255,0.85)' : '#374151', fontWeight: '600' }}>
            {prenom}
          </span>
        )}
        {messagerieVers && (
          <button onClick={() => navigate(messagerieVers)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: '44px', minWidth: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
            <svg width="22" height="22" fill="none" stroke={texteCouleur} strokeWidth="2" viewBox="0 0 24 24">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            {nonLus > 0 && (
              <div style={{
                position: 'absolute', top: '6px', right: '6px',
                backgroundColor: '#EF4444', color: '#FFFFFF',
                borderRadius: '9999px', minWidth: '16px', height: '16px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.65rem', fontWeight: '700', padding: '0 3px',
              }}>
                {nonLus > 9 ? '9+' : nonLus}
              </div>
            )}
          </button>
        )}
        {afficherQuitter && (
          <button onClick={() => navigate('/')}
            style={{ background: 'none', border: 'none', color: estSombre ? 'rgba(255,255,255,0.75)' : '#6B7280', cursor: 'pointer', fontSize: '0.8rem', minHeight: '44px', fontFamily: 'Arial' }}>
            Quitter
          </button>
        )}
        {onDeconnecter && (
          <button onClick={onDeconnecter}
            style={{ background: 'none', border: 'none', color: estSombre ? 'rgba(255,255,255,0.65)' : '#9CA3AF', cursor: 'pointer', fontSize: '0.75rem', minHeight: '44px', fontFamily: 'Arial', padding: '0 0.25rem' }}
            title="Se déconnecter">
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
          </button>
        )}
      </div>
    </header>
  )
}

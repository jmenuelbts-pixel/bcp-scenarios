import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import type { TravailARendre } from '../../data/schema'

interface Props { travail: TravailARendre; couleur: string; seanceId: string }

interface CorrQ { commentaire: string; points: string }
interface Correction {
  note: number | null
  bareme: number
  commentaire_prof: string | null
  correction_envoyee: boolean
  corrections_par_question: Record<string, CorrQ>
}

export default function OngletTravaux({ travail, couleur, seanceId }: Props) {
  const [sousOnglet, setSousOnglet] = useState<'devoir' | 'rendu'>('devoir')
  const [reponses, setReponses] = useState<Record<string, string>>({})
  const [statut, setStatut] = useState<'brouillon' | 'remis'>('brouillon')
  const [userId, setUserId] = useState<string | null>(null)
  const [sauvegarde, setSauvegarde] = useState(false)
  const [envoi, setEnvoi] = useState(false)
  const [devoirId, setDevoirId] = useState<string | null>(null)
  const [correction, setCorrection] = useState<Correction | null>(null)
  const [timer, setTimer] = useState<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      setUserId(user.id)
      const { data } = await supabase.from('devoirs').select('*').eq('user_id', user.id).eq('seance_id', seanceId).single()
      if (data) {
        setReponses(data.contenu ?? {})
        setStatut(data.statut)
        setDevoirId(data.id)
        setCorrection({
          note: data.note ?? null,
          bareme: data.bareme ?? 20,
          commentaire_prof: data.commentaire_prof ?? null,
          correction_envoyee: data.correction_envoyee ?? false,
          corrections_par_question: data.corrections_par_question ?? {},
        })
        if (data.statut === 'remis') setSousOnglet('rendu')
      }
    }
    init()
  }, [seanceId])

  const sauvegarder = async (nouvellesReponses: Record<string, string>) => {
    if (!userId || statut === 'remis') return
    setSauvegarde(true)
    if (devoirId) {
      await supabase.from('devoirs').update({ contenu: nouvellesReponses }).eq('id', devoirId)
    } else {
      const { data } = await supabase.from('devoirs').insert({ seance_id: seanceId, user_id: userId, contenu: nouvellesReponses, statut: 'brouillon' }).select('id').single()
      if (data) setDevoirId(data.id)
    }
    setTimeout(() => setSauvegarde(false), 1000)
  }

  const setReponse = (key: string, val: string) => {
    if (statut === 'remis') return
    const n = { ...reponses, [key]: val }
    setReponses(n)
    if (timer) clearTimeout(timer)
    setTimer(setTimeout(() => sauvegarder(n), 2000))
  }

  const handleEnvoyer = async () => {
    if (!userId || envoi || statut === 'remis') return
    if (!confirm('Envoyer le devoir ? Cette action est irréversible.')) return
    setEnvoi(true)
    const now = new Date().toISOString()
    if (devoirId) {
      await supabase.from('devoirs').update({ statut: 'remis', remis_at: now, contenu: reponses }).eq('id', devoirId)
    } else {
      await supabase.from('devoirs').insert({ seance_id: seanceId, user_id: userId, contenu: reponses, statut: 'remis', remis_at: now })
    }
    setStatut('remis')
    setSousOnglet('rendu')
    setEnvoi(false)
  }


  return (
    <div>
      {/* Sous-onglets */}
      <div style={{ display: 'flex', borderBottom: '2px solid #E5E7EB', marginBottom: '1.25rem' }}>
        <button onClick={() => setSousOnglet('devoir')}
          style={{ padding: '0.625rem 1.25rem', border: 'none', borderBottom: `2px solid ${sousOnglet === 'devoir' ? couleur : 'transparent'}`, marginBottom: '-2px', backgroundColor: 'transparent', color: sousOnglet === 'devoir' ? couleur : '#6B7280', fontWeight: sousOnglet === 'devoir' ? '700' : '400', fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'Arial' }}>
          Devoir à rendre
        </button>
        <button onClick={() => setSousOnglet('rendu')} disabled={statut !== 'remis'}
          style={{ padding: '0.625rem 1.25rem', border: 'none', borderBottom: `2px solid ${sousOnglet === 'rendu' ? couleur : 'transparent'}`, marginBottom: '-2px', backgroundColor: 'transparent', color: statut !== 'remis' ? '#D1D5DB' : sousOnglet === 'rendu' ? couleur : '#6B7280', fontWeight: sousOnglet === 'rendu' ? '700' : '400', fontSize: '0.875rem', cursor: statut !== 'remis' ? 'default' : 'pointer', fontFamily: 'Arial' }}>
          Devoir rendu {correction?.correction_envoyee ? '✓' : ''}
        </button>
      </div>

      {/* Sous-onglet 1 : Devoir à rendre */}
      {sousOnglet === 'devoir' && (
        <div>
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1rem', fontWeight: '700', color: couleur, margin: '0 0 0.5rem 0' }}>{travail.titre}</h2>
            <p style={{ fontSize: '0.875rem', color: '#6B7280', margin: 0, lineHeight: '1.6' }}>{travail.contexte}</p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {travail.consignes.map(c => (
              <div key={c.id} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: '700', color: couleur, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.5rem' }}>Consigne {c.numero}</div>
                <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.6', margin: '0 0 1rem 0' }}>{c.enonce}</p>
                <textarea value={reponses[c.id] ?? ''} onChange={e => setReponse(c.id, e.target.value)}
                  placeholder="Votre réponse..." rows={5} disabled={statut === 'remis'}
                  style={{ width: '100%', padding: '0.75rem', border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.6', backgroundColor: statut === 'remis' ? '#F9FAFB' : '#FFFFFF' }} />
              </div>
            ))}
          </div>

          {statut !== 'remis' && (
            <div style={{ marginTop: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.75rem', color: sauvegarde ? '#059669' : '#9CA3AF' }}>{sauvegarde ? 'Sauvegardé' : 'Sauvegarde automatique'}</span>
              <motion.button whileTap={{ scale: 0.97 }} onClick={handleEnvoyer} disabled={envoi}
                style={{ backgroundColor: couleur, color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.75rem 1.5rem', fontSize: '0.875rem', fontWeight: '700', cursor: 'pointer', fontFamily: 'Arial' }}>
                {envoi ? 'Envoi...' : 'Envoyer le devoir'}
              </motion.button>
            </div>
          )}

          {statut === 'remis' && (
            <div style={{ marginTop: '1rem', textAlign: 'center', padding: '0.875rem', backgroundColor: '#D1FAE5', borderRadius: '8px', fontSize: '0.875rem', color: '#065F46', fontWeight: '600' }}>
              Devoir envoyé — consultez l'onglet "Devoir rendu" pour voir la correction
            </div>
          )}
        </div>
      )}

      {/* Sous-onglet 2 : Devoir rendu + correction */}
      {sousOnglet === 'rendu' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {/* Note globale */}
          {correction?.correction_envoyee && correction.note !== null && (
            <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: `2px solid ${couleur}`, textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Note</div>
              <div style={{ fontSize: '2rem', fontWeight: '700', color: couleur }}>{correction.note} / {correction.bareme}</div>
              {correction.commentaire_prof && (
                <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.6', margin: '0.75rem 0 0 0', textAlign: 'left' }}>{correction.commentaire_prof}</p>
              )}
            </div>
          )}

          {!correction?.correction_envoyee && (
            <div style={{ backgroundColor: '#FEF3C7', borderRadius: '10px', padding: '1.25rem', border: '1px solid #FCD34D', textAlign: 'center', fontSize: '0.875rem', color: '#92400E' }}>
              Votre devoir a été remis. La correction n'est pas encore disponible.
            </div>
          )}

          {/* Réponses + correction par question */}
          {travail.consignes.map((c, i) => (
            <div key={c.id} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
              <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid #F3F4F6' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Question {i + 1}</div>
                <p style={{ fontSize: '0.8rem', color: '#9CA3AF', margin: '0 0 0.5rem 0', lineHeight: '1.5' }}>{c.enonce}</p>
                <p style={{ fontSize: '0.875rem', color: '#374151', lineHeight: '1.6', margin: 0, whiteSpace: 'pre-wrap' }}>
                  {reponses[c.id] || <span style={{ color: '#D1D5DB', fontStyle: 'italic' }}>Pas de réponse</span>}
                </p>
              </div>
              {correction?.correction_envoyee && correction.corrections_par_question?.[c.id] && (
                <div style={{ padding: '0.875rem 1.25rem', backgroundColor: '#F0FDF4' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#1B6B3A', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.25rem' }}>Correction</div>
                      <p style={{ fontSize: '0.875rem', color: '#374151', margin: 0, lineHeight: '1.5' }}>{correction.corrections_par_question[c.id].commentaire}</p>
                    </div>
                    {correction.corrections_par_question[c.id].points && (
                      <div style={{ backgroundColor: '#1B6B3A', color: '#FFFFFF', borderRadius: '8px', padding: '0.25rem 0.625rem', fontSize: '0.875rem', fontWeight: '700', flexShrink: 0 }}>
                        {correction.corrections_par_question[c.id].points} pts
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

interface Props {
  lienDrive: string
  titre: string
  intervenant: string
  duree: string
  couleur: string
}

// Convertit un lien de partage Google Drive en lien d'embed
function convertirLienDrive(lien: string): string {
  // Format partage : https://drive.google.com/file/d/ID/view?usp=sharing
  // Format embed  : https://drive.google.com/file/d/ID/preview
  const match = lien.match(/\/file\/d\/([a-zA-Z0-9_-]+)/)
  if (match) {
    return `https://drive.google.com/file/d/${match[1]}/preview`
  }
  return lien
}

export default function LecteurVideo({ lienDrive, titre, intervenant, duree, couleur }: Props) {
  const lienEmbed = convertirLienDrive(lienDrive)

  return (
    <div style={{ marginBottom: '1rem' }}>
      {/* Lecteur vidéo embarqué */}
      <div style={{
        position: 'relative',
        width: '100%',
        paddingTop: '56.25%', // ratio 16:9
        backgroundColor: '#000000',
        borderRadius: '10px',
        overflow: 'hidden',
        boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
      }}>
        <iframe
          src={lienEmbed}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            border: 'none',
          }}
          allow="autoplay"
          allowFullScreen
          title={titre}
        />
      </div>

      {/* Informations sous le lecteur */}
      <div style={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderTop: `3px solid ${couleur}`,
        borderRadius: '0 0 10px 10px',
        padding: '0.875rem 1rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        gap: '1rem',
        flexWrap: 'wrap',
      }}>
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: '0.9375rem', fontWeight: '700', color: '#111827', margin: '0 0 0.25rem 0', lineHeight: '1.3' }}>
            {titre}
          </p>
          <p style={{ fontSize: '0.8rem', color: '#6B7280', margin: 0 }}>
            {intervenant}
          </p>
        </div>
        <div style={{
          backgroundColor: couleur,
          color: '#FFFFFF',
          borderRadius: '9999px',
          fontSize: '0.75rem',
          fontWeight: '600',
          padding: '0.25rem 0.75rem',
          whiteSpace: 'nowrap',
          flexShrink: 0,
        }}>
          {duree}
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'
import type { FicheRessource } from '../../data/schema'

interface Props { fiche: FicheRessource; couleur: string; seanceId: string }

export default function OngletFiche({ fiche, couleur }: Props) {
  const [notionActive, setNotionActive] = useState(0)
  const notion = fiche.notions[notionActive]

  if (!fiche.notions || fiche.notions.length === 0) return (
    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.5rem', border: '1px solid #D1D5DB', textAlign: 'center', color: '#9CA3AF', fontSize: '0.875rem' }}>
      Fiche ressource non disponible pour cette séance.
    </div>
  )

  if (!notion) return null

  return (
    <div>
      {/* Navigation par notions */}
      <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', marginBottom: '1.5rem', paddingBottom: '0.25rem' }}>
        {fiche.notions.map((n, i) => (
          <button key={n.id} onClick={() => setNotionActive(i)}
            style={{
              padding: '0.5rem 1rem', borderRadius: '9999px', border: `1.5px solid ${i === notionActive ? couleur : '#D1D5DB'}`,
              backgroundColor: i === notionActive ? couleur : '#FFFFFF', color: i === notionActive ? '#FFFFFF' : '#374151',
              fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'Arial', minHeight: '36px',
            }}>
            Notion {n.numero}
          </button>
        ))}
      </div>

      {/* Contenu de la notion */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.5rem', border: '1px solid #D1D5DB' }}>
        <h2 style={{ fontSize: '1.0625rem', fontWeight: '700', color: couleur, margin: '0 0 1.25rem 0', paddingBottom: '0.75rem', borderBottom: `2px solid ${couleur}` }}>
          Notion {notion.numero} — {notion.titre}
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {notion.blocs.map((bloc, i) => {
            if (bloc.type === 'paragraphe') return (
              <p key={i} style={{ fontSize: '0.9rem', color: '#374151', lineHeight: '1.7', margin: 0 }}>{bloc.texte}</p>
            )

            if (bloc.type === 'tableau') return (
              <div key={i}>
                {bloc.titre && <p style={{ fontSize: '0.875rem', fontWeight: '600', color: '#374151', margin: '0 0 0.5rem 0' }}>{bloc.titre}</p>}
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.825rem' }}>
                    <thead>
                      <tr>
                        {bloc.colonnes.map((col, j) => (
                          <th key={j} style={{ backgroundColor: couleur, color: '#FFFFFF', padding: '0.625rem 0.875rem', textAlign: 'left', fontWeight: '600', fontSize: '0.8rem' }}>{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {bloc.lignes.map((ligne, ri) => (
                        <tr key={ri} style={{ backgroundColor: ri % 2 === 0 ? '#FAFAFA' : '#FFFFFF' }}>
                          {ligne.map((cell, ci) => (
                            <td key={ci} style={{ padding: '0.625rem 0.875rem', border: '1px solid #E5E7EB', lineHeight: '1.5', verticalAlign: 'top' }}>{cell}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )

            if (bloc.type === 'encadre_attention' || bloc.type === 'encadre_definition' || bloc.type === 'encadre_exemple') {
              const couleurBord = bloc.type === 'encadre_attention' ? '#DC2626' : bloc.type === 'encadre_exemple' ? '#16A34A' : couleur
              const couleurFond = bloc.type === 'encadre_attention' ? '#FEF2F2' : bloc.type === 'encadre_exemple' ? '#F0FDF4' : '#F0F4FF'
              return (
                <div key={i} style={{ backgroundColor: couleurFond, borderLeft: `4px solid ${couleurBord}`, borderRadius: '0 8px 8px 0', padding: '1rem 1.25rem' }}>
                  {bloc.titre && <p style={{ fontSize: '0.8rem', fontWeight: '700', color: couleurBord, margin: '0 0 0.375rem 0', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{bloc.titre}</p>}
                  <p style={{ fontSize: '0.875rem', color: '#374151', margin: 0, lineHeight: '1.6' }}>{bloc.texte}</p>
                </div>
              )
            }

            if (bloc.type === 'reference_juridique') return (
              <div key={i} style={{ backgroundColor: '#F8F4FF', border: '1px solid #C4B5FD', borderRadius: '8px', padding: '0.875rem 1rem' }}>
                <p style={{ fontSize: '0.75rem', fontWeight: '700', color: '#7C3AED', margin: '0 0 0.25rem 0', textTransform: 'uppercase' }}>Référence juridique</p>
                <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, lineHeight: '1.6' }}>{bloc.texte}</p>
              </div>
            )

            return null
          })}
        </div>
      </div>
    </div>
  )
}

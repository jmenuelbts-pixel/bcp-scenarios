import { useState } from 'react'
import LecteurVideo from './LecteurVideo'
import { motion, AnimatePresence } from 'framer-motion'
import type { CapsuleDistancielle } from '../../data/schema'

interface Props {
  capsule: CapsuleDistancielle
  couleur: string
  seanceId: string
}

export default function OngletCapsule({ capsule, couleur }: Props) {
  const [etapeActuelle, setEtapeActuelle] = useState(0)
  const [reponses, setReponses] = useState<Record<string, string>>({})
  const etapes = capsule.etapes
  const etape = etapes[etapeActuelle]
  const total = etapes.length

  const setReponse = (key: string, val: string) => setReponses(r => ({ ...r, [key]: val }))

  const styleTextarea = {
    width: '100%', minHeight: '80px', padding: '0.75rem',
    border: '1px solid #D1D5DB', borderRadius: '8px',
    fontSize: '0.9rem', fontFamily: 'Arial', resize: 'vertical' as const,
    boxSizing: 'border-box' as const, lineHeight: '1.5',
  }

  const styleBouton = (actif: boolean) => ({
    backgroundColor: actif ? couleur : '#F3F4F6',
    color: actif ? '#FFFFFF' : '#6B7280',
    border: 'none', borderRadius: '8px', padding: '0.75rem 1.5rem',
    fontSize: '0.9rem', fontWeight: '600', cursor: actif ? 'pointer' : 'not-allowed',
    minHeight: '44px', fontFamily: 'Arial', opacity: actif ? 1 : 0.5,
  })

  return (
    <div>
      {/* Indicateur d'étape */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
        {etapes.map((_, i) => (
          <div key={i} style={{
            flex: 1, height: '4px', borderRadius: '9999px',
            backgroundColor: i <= etapeActuelle ? couleur : '#E5E7EB',
            transition: 'background-color 0.3s',
          }} />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={etapeActuelle} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }}>

          {/* ÉTAPE 1 — Vidéo */}
          {etape.type === 'video' && (
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: '700', color: couleur, textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.75rem 0' }}>
                Étape 1 — Déclencheur vidéo
              </p>
              <LecteurVideo
                lienDrive={etape.lien_drive}
                titre={etape.titre_video}
                intervenant={etape.intervenant}
                duree={etape.duree}
                couleur={couleur}
              />
              <div style={{ backgroundColor: '#F9FAFB', borderRadius: '8px', padding: '1rem', borderLeft: `3px solid ${couleur}`, marginTop: '1rem' }}>
                <p style={{ fontSize: '0.8rem', fontWeight: '600', color: '#374151', margin: '0 0 0.5rem 0' }}>Consigne de visionnage</p>
                <p style={{ fontSize: '0.85rem', color: '#4B5563', margin: 0, lineHeight: '1.6' }}>{etape.consigne_visionnage}</p>
              </div>
            </div>
          )}

          {/* ÉTAPE 2 — Questions */}
          {etape.type === 'questions' && (
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: '700', color: couleur, textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.75rem 0' }}>
                Étape 2 — Questions de réflexion
              </p>
              <p style={{ fontSize: '0.85rem', color: '#6B7280', margin: '0 0 1.25rem 0', fontStyle: 'italic' }}>
                Répondez aux questions ci-dessous. Il n'y a pas de bonne ou de mauvaise réponse. Minimum 3 lignes par question.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                {etape.questions.map((q, i) => (
                  <div key={i}>
                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1rem', border: '1px solid #D1D5DB', marginBottom: '0.5rem' }}>
                      <p style={{ fontSize: '0.8rem', fontWeight: '700', color: couleur, margin: '0 0 0.5rem 0' }}>Question {i + 1}</p>
                      <p style={{ fontSize: '0.875rem', color: '#374151', margin: 0, lineHeight: '1.6' }}>{q}</p>
                    </div>
                    <textarea value={reponses[`q${i}`] ?? ''} onChange={e => setReponse(`q${i}`, e.target.value)}
                      placeholder="Votre réponse..." style={styleTextarea} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ÉTAPE 3 — Exercices */}
          {etape.type === 'exercices' && (
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: '700', color: couleur, textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.75rem 0' }}>
                Étape 3 — Exercices sur la vidéo
              </p>
              <p style={{ fontSize: '0.85rem', color: '#6B7280', margin: '0 0 1.25rem 0' }}>{etape.consigne_globale}</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {etape.exercices.map((ex, i) => (
                  <div key={ex.id} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB' }}>
                    <p style={{ fontSize: '0.8rem', fontWeight: '700', color: couleur, margin: '0 0 0.5rem 0' }}>Exercice {i + 1}</p>
                    <p style={{ fontSize: '0.875rem', color: '#374151', margin: '0 0 1rem 0', lineHeight: '1.6' }}>{ex.enonce}</p>

                    {ex.type === 'texte_libre' && (
                      <textarea value={reponses[ex.id] ?? ''} onChange={e => setReponse(ex.id, e.target.value)}
                        placeholder="Votre réponse..." style={styleTextarea} />
                    )}

                    {ex.type === 'tableau' && ex.colonnes && ex.lignes && (
                      <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
                          <thead>
                            <tr>
                              {ex.colonnes.map((col, j) => (
                                <th key={j} style={{ backgroundColor: couleur, color: '#FFFFFF', padding: '0.5rem 0.75rem', textAlign: 'left', fontWeight: '600' }}>{col}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {ex.lignes.map((ligne, ri) => (
                              <tr key={ri} style={{ backgroundColor: ri % 2 === 0 ? '#FAFAFA' : '#FFFFFF' }}>
                                {ligne.map((cell, ci) => (
                                  <td key={ci} style={{ padding: '0.5rem 0.75rem', border: '1px solid #E5E7EB' }}>
                                    {ci === 0 ? cell : (
                                      <input type="checkbox" style={{ width: '16px', height: '16px', cursor: 'pointer' }}
                                        checked={reponses[`${ex.id}_${ri}_${ci}`] === 'true'}
                                        onChange={e => setReponse(`${ex.id}_${ri}_${ci}`, e.target.checked ? 'true' : 'false')} />
                                    )}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ÉTAPE 4 — Micro-tâche */}
          {etape.type === 'micro_tache' && (
            <div>
              <p style={{ fontSize: '0.75rem', fontWeight: '700', color: couleur, textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.75rem 0' }}>
                Étape 4 — Micro-tâche de clôture
              </p>
              <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB', marginBottom: '1rem' }}>
                <p style={{ fontSize: '0.875rem', color: '#374151', margin: 0, lineHeight: '1.6' }}>{etape.consigne}</p>
              </div>
              <textarea value={reponses['micro_tache'] ?? ''} onChange={e => setReponse('micro_tache', e.target.value)}
                placeholder="Votre réponse..." style={{ ...styleTextarea, minHeight: '100px' }} />
            </div>
          )}

        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2rem', gap: '1rem' }}>
        <button onClick={() => setEtapeActuelle(e => Math.max(0, e - 1))}
          disabled={etapeActuelle === 0}
          style={styleBouton(etapeActuelle > 0)}>
          &larr; Retour
        </button>

        {etapeActuelle < total - 1 ? (
          <button onClick={() => setEtapeActuelle(e => e + 1)}
            style={styleBouton(true)}>
            Continuer &rarr;
          </button>
        ) : (
          <button onClick={() => alert('Capsule validée !')}
            style={{ ...styleBouton(true), backgroundColor: '#16A34A' }}>
            Valider la capsule
          </button>
        )}
      </div>
    </div>
  )
}

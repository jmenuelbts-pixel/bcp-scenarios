import { useState } from 'react'
import type { CoursPresenciel } from '../../data/schema'

interface Props { cours: CoursPresenciel; couleur: string; seanceId: string }

const MODALITE_LABELS: Record<string, string> = {
  individuel: 'Individuel', binome: 'Binôme', groupe: 'Groupe', classe: 'Collectif'
}

export default function OngletPresentiel({ cours, couleur }: Props) {
  const [reponses, setReponses] = useState<Record<string, string>>({})
  const setReponse = (key: string, val: string) => setReponses(r => ({ ...r, [key]: val }))

  const styleTextarea = {
    width: '100%', minHeight: '80px', padding: '0.75rem',
    border: '1px solid #D1D5DB', borderRadius: '8px', fontSize: '0.875rem',
    fontFamily: 'Arial', resize: 'vertical' as const, boxSizing: 'border-box' as const, lineHeight: '1.5',
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {cours.phases.map(phase => (
        <div key={phase.id} style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', border: '1px solid #D1D5DB', overflow: 'hidden' }}>
          {/* En-tête de phase */}
          <div style={{ backgroundColor: couleur, padding: '0.875rem 1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div>
              <span style={{ color: 'rgba(255,255,255,0.75)', fontSize: '0.7rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Phase {phase.numero}
              </span>
              <h3 style={{ color: '#FFFFFF', fontSize: '0.9375rem', fontWeight: '700', margin: '0.1rem 0 0 0' }}>{phase.titre}</h3>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              <span style={{ backgroundColor: 'rgba(255,255,255,0.2)', color: '#FFFFFF', borderRadius: '9999px', fontSize: '0.7rem', fontWeight: '600', padding: '0.2rem 0.6rem' }}>
                {phase.duree_minutes} min
              </span>
              <span style={{ backgroundColor: 'rgba(255,255,255,0.2)', color: '#FFFFFF', borderRadius: '9999px', fontSize: '0.7rem', fontWeight: '600', padding: '0.2rem 0.6rem' }}>
                {MODALITE_LABELS[phase.modalite] ?? phase.modalite}
              </span>
            </div>
          </div>

          {/* Éléments de la phase */}
          <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {phase.elements.map(elem => {
              if (elem.type === 'consigne') return (
                <div key={elem.id} style={{ backgroundColor: '#F9FAFB', borderLeft: `3px solid ${couleur}`, borderRadius: '0 8px 8px 0', padding: '1rem 1.25rem' }}>
                  <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, lineHeight: '1.7', whiteSpace: 'pre-line' }}>{elem.contenu}</p>
                </div>
              )

              if (elem.type === 'document') return (
                <div key={elem.id} style={{ backgroundColor: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: '8px', padding: '1rem 1.25rem' }}>
                  <p style={{ fontSize: '0.7rem', fontWeight: '700', color: '#92400E', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 0.5rem 0' }}>Document</p>
                  <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, lineHeight: '1.7', whiteSpace: 'pre-line' }}>{elem.contenu}</p>
                </div>
              )

              if (elem.type === 'zone_reponse') return (
                <div key={elem.id}>
                  <p style={{ fontSize: '0.875rem', color: '#374151', margin: '0 0 0.5rem 0', lineHeight: '1.6', whiteSpace: 'pre-line' }}>{elem.contenu}</p>
                  <textarea value={reponses[elem.id] ?? ''} onChange={e => setReponse(elem.id, e.target.value)}
                    placeholder="Votre réponse..." style={styleTextarea} />
                </div>
              )

              if (elem.type === 'tableau_editable' && elem.colonnes && elem.lignes) return (
                <div key={elem.id}>
                  <p style={{ fontSize: '0.875rem', color: '#374151', margin: '0 0 0.75rem 0', lineHeight: '1.6' }}>{elem.contenu}</p>
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.825rem' }}>
                      <thead>
                        <tr>
                          {elem.colonnes.map((col, j) => (
                            <th key={j} style={{ backgroundColor: couleur, color: '#FFFFFF', padding: '0.625rem 0.875rem', textAlign: 'left', fontWeight: '600' }}>{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {elem.lignes.map((ligne, ri) => (
                          <tr key={ri} style={{ backgroundColor: ri % 2 === 0 ? '#FAFAFA' : '#FFFFFF' }}>
                            {ligne.map((cell, ci) => (
                              <td key={ci} style={{ padding: '0.375rem 0.5rem', border: '1px solid #E5E7EB', verticalAlign: 'top' }}>
                                {cell === '' ? (
                                  <textarea value={reponses[`${elem.id}_${ri}_${ci}`] ?? ''}
                                    onChange={e => setReponse(`${elem.id}_${ri}_${ci}`, e.target.value)}
                                    style={{ width: '100%', minHeight: '60px', padding: '0.375rem', border: '1px solid #D1D5DB', borderRadius: '4px', fontSize: '0.8rem', fontFamily: 'Arial', resize: 'vertical' }} />
                                ) : (
                                  <span style={{ lineHeight: '1.5' }}>{cell}</span>
                                )}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )

              return null
            })}
          </div>
        </div>
      ))}
    </div>
  )
}

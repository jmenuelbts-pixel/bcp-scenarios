import { useEffect, useState, useRef } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'

interface Props { couleur: string; seanceId: string }

export default function OngletJournal({ couleur, seanceId }: Props) {
  const [entree, setEntree] = useState('')
  const [statut, setStatut] = useState<'idle' | 'sauvegarde' | 'ok'>('idle')
  const journalIdRef = useRef<string | null>(null)
  const userIdRef = useRef<string | null>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      userIdRef.current = user.id
      const { data } = await supabase
        .from('journal_bord')
        .select('id, contenu')
        .eq('user_id', user.id)
        .eq('seance_id', seanceId)
        .maybeSingle()
      if (data) {
        journalIdRef.current = data.id
        setEntree(data.contenu ?? '')
      }
    }
    init()
  }, [seanceId])

  const sauvegarder = async (texte: string) => {
    if (!userIdRef.current) return
    setStatut('sauvegarde')
    const { data } = await supabase.from('journal_bord')
      .upsert(
        { user_id: userIdRef.current, seance_id: seanceId, contenu: texte, created_at: new Date().toISOString() },
        { onConflict: 'user_id,seance_id' }
      )
      .select('id')
      .single()
    if (data) journalIdRef.current = data.id
    setStatut('ok')
    setTimeout(() => setStatut('idle'), 2000)
  }

  const handleChange = (val: string) => {
    setEntree(val)
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => sauvegarder(val), 2000)
  }

  return (
    <div>
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', padding: '1.25rem', border: '1px solid #D1D5DB', marginBottom: '1.25rem' }}>
        <h2 style={{ fontSize: '1rem', fontWeight: '700', color: couleur, margin: '0 0 0.5rem 0' }}>Journal de bord alternance</h2>
        <p style={{ fontSize: '0.875rem', color: '#6B7280', margin: 0, lineHeight: '1.6' }}>
          Notez vos observations en entreprise en lien avec cette séance. Votre professeur peut consulter ce journal.
        </p>
      </div>

      <div style={{ marginBottom: '0.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: '0.75rem', color: statut === 'ok' ? '#059669' : statut === 'sauvegarde' ? '#D97706' : '#9CA3AF' }}>
          {statut === 'ok' ? 'Sauvegardé' : statut === 'sauvegarde' ? 'Sauvegarde...' : 'Sauvegarde automatique'}
        </span>
        <span style={{ fontSize: '0.8rem', color: '#9CA3AF' }}>
          {new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
        </span>
      </div>

      <textarea value={entree} onChange={e => handleChange(e.target.value)}
        placeholder="Qu'avez-vous observé en entreprise en lien avec cette séance ? Comment les notions étudiées se retrouvent-elles dans votre quotidien professionnel ?"
        style={{ width: '100%', minHeight: '220px', padding: '1rem', border: '1px solid #D1D5DB', borderRadius: '10px', fontSize: '0.875rem', fontFamily: 'Arial', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.7' }} />

      <motion.button whileTap={{ scale: 0.98 }} onClick={() => sauvegarder(entree)}
        style={{ marginTop: '1rem', width: '100%', backgroundColor: statut === 'ok' ? '#16A34A' : couleur, color: '#FFFFFF', border: 'none', borderRadius: '8px', padding: '0.875rem', fontSize: '0.9rem', fontWeight: '600', cursor: 'pointer', minHeight: '44px', fontFamily: 'Arial', transition: 'background-color 0.2s' }}>
        {statut === 'sauvegarde' ? 'Sauvegarde...' : statut === 'ok' ? 'Sauvegardé' : 'Sauvegarder'}
      </motion.button>
    </div>
  )
}

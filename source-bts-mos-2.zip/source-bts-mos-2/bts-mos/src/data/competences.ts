// MOS Pro P3 — Référentiel des compétences Bloc 3 (U52)
// Mapping compétence → séances qui la travaillent

export interface Competence {
  id: string
  code: string        // ex: "A3.1C1"
  libelle: string
  activite: string    // "A3.1" | "A3.2" | "A3.3"
  seances: string[]   // ids des séances qui couvrent cette compétence
}

export interface ActiviteBloc {
  id: string
  code: string
  titre: string
  couleur: string
  competences: Competence[]
}

export const ACTIVITES_BLOC3: ActiviteBloc[] = [
  {
    id: 'a31',
    code: 'A3.1',
    titre: 'Préparation de l\'offre commerciale',
    couleur: '#1A56A0',
    competences: [
      {
        id: 'a31c1',
        code: 'A3.1C1',
        libelle: 'Élaborer une offre commerciale cohérente',
        activite: 'A3.1',
        seances: ['s1', 's2', 's3'],
      },
      {
        id: 'a31c2',
        code: 'A3.1C2',
        libelle: 'Présenter et argumenter l\'offre commerciale',
        activite: 'A3.1',
        seances: ['s4'],
      },
    ],
  },
  {
    id: 'a32',
    code: 'A3.2',
    titre: 'Gestion de la prestation',
    couleur: '#B22222',
    competences: [
      {
        id: 'a32c1',
        code: 'A3.2C1',
        libelle: 'Mettre en oeuvre des outils de suivi de la prestation',
        activite: 'A3.2',
        seances: ['s7', 's9'],
      },
      {
        id: 'a32c2',
        code: 'A3.2C2',
        libelle: 'Ajuster la prestation',
        activite: 'A3.2',
        seances: ['s6', 's8', 's10'],
      },
      {
        id: 'a32c3',
        code: 'A3.2C3',
        libelle: 'Mettre en place des actions de remédiation ou d\'amélioration',
        activite: 'A3.2',
        seances: ['s8', 's9', 's10'],
      },
      {
        id: 'a32c4',
        code: 'A3.2C4',
        libelle: 'Rendre compte à la hiérarchie',
        activite: 'A3.2',
        seances: ['s7', 's9', 's11'],
      },
      {
        id: 'a32c5',
        code: 'A3.2C5',
        libelle: 'Gérer les relations avec les autres prestataires',
        activite: 'A3.2',
        seances: ['s6'],
      },
      {
        id: 'a32c6',
        code: 'A3.2C6',
        libelle: 'Gérer la sécurité dans le cadre de l\'intervention d\'un prestataire extérieur',
        activite: 'A3.2',
        seances: ['s6'],
      },
    ],
  },
  {
    id: 'a33',
    code: 'A3.3',
    titre: 'Suivi et pérennisation de la relation client',
    couleur: '#B8860B',
    competences: [
      {
        id: 'a33c1',
        code: 'A3.3C1',
        libelle: 'Conduire une réunion avec le client',
        activite: 'A3.3',
        seances: ['s11', 's12'],
      },
      {
        id: 'a33c2',
        code: 'A3.3C2',
        libelle: 'Identifier les événements et les incidents',
        activite: 'A3.3',
        seances: ['s10'],
      },
      {
        id: 'a33c3',
        code: 'A3.3C3',
        libelle: 'Gérer les conséquences des événements',
        activite: 'A3.3',
        seances: ['s10'],
      },
      {
        id: 'a33c4',
        code: 'A3.3C4',
        libelle: 'Faire des propositions d\'amélioration de la prestation',
        activite: 'A3.3',
        seances: ['s14', 's15'],
      },
      {
        id: 'a33c5',
        code: 'A3.3C5',
        libelle: 'Déployer une politique de qualité dans la relation client',
        activite: 'A3.3',
        seances: ['s14', 's15'],
      },
    ],
  },
]

// Liste à plat de toutes les compétences
export const COMPETENCES: Competence[] = ACTIVITES_BLOC3.flatMap(a => a.competences)

// Niveau de maîtrise d'une compétence
export type NiveauCompetence = 'non_travaillee' | 'en_cours' | 'atteinte'

export interface ResultatCompetence {
  competence: Competence
  niveau: NiveauCompetence
  seancesRealisees: string[]   // séances couvrant cette compétence déjà faites
  seancesTotales: string[]     // toutes les séances couvrant cette compétence
  scoreQuiz: number | null     // meilleur score quiz parmi les séances concernées (0-100)
  devoirRemis: boolean         // au moins un devoir remis sur ces séances
}

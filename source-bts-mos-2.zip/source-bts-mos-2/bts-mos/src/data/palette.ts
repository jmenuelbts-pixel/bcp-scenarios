// MOS Pro P3 — Palette de couleurs et tokens visuels
// Phase 0 — Référence unique pour toute l'application

export const PALETTE = {

  // ── Double portail (page d'accueil uniquement) ──────────────────
  portail: {
    professeur: '#1B6B3A',   // vert — réservé exclusivement au portail
    etudiant:   '#C25A00',   // orange — réservé exclusivement au portail
  },

  // ── Couleurs des 4 thèmes ────────────────────────────────────────
  themes: {
    theme1: '#1A56A0',   // bleu — Préparer l'offre commerciale
    theme2: '#B22222',   // rouge — Gérer la prestation
    theme3: '#B8860B',   // jaune foncé — Suivre et pérenniser
    theme4: '#C2185B',   // rose — Consolidation et simulations E52
  },

  // ── Neutres (interface globale) ──────────────────────────────────
  neutres: {
    fond:         '#F5F5F5',   // fond global de l'app
    surface:      '#FFFFFF',   // cartes, panneaux, onglets
    bordure:      '#D1D5DB',   // séparateurs, contours
    texte:        '#111827',   // texte principal
    texteSecond:  '#6B7280',   // texte secondaire, légendes
    desactive:    '#9CA3AF',   // boutons hors ligne, éléments verrouillés
  },

  // ── Statuts et feedback ──────────────────────────────────────────
  statuts: {
    succes:        '#16A34A',  // validation, badge, envoi confirmé
    avertissement: '#D97706',  // alerte douce
    erreur:        '#DC2626',  // erreur, hors ligne
    info:          '#2563EB',  // information neutre
  },

  // ── Badges de progression ────────────────────────────────────────
  badges: {
    non_commence: '#9CA3AF',
    en_cours:     '#2563EB',
    bronze:       '#CD7F32',
    argent:       '#A8A9AD',
    or:           '#FFD700',
    diamant:      '#B9F2FF',
    maitre:       '#7C3AED',
  },
} as const

// ── Tokens typographiques ───────────────────────────────────────────
// Police unique : Arial (toute l'application)
export const TYPO = {
  fontFamily: 'Arial, Helvetica, sans-serif',
  tailles: {
    xs:   '0.75rem',    // 12px — légendes, badges
    sm:   '0.875rem',   // 14px — texte secondaire
    base: '1rem',       // 16px — corps de texte
    lg:   '1.125rem',   // 18px — titres de section
    xl:   '1.25rem',    // 20px — titres de page
    xxl:  '1.5rem',     // 24px — titres principaux
    hero: '2rem',       // 32px — portail d'accueil uniquement
  },
  poids: {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
} as const

// ── Tokens de mise en page ──────────────────────────────────────────
export const LAYOUT = {
  // Hauteur minimale des zones tactiles (mobile)
  touchMin: '44px',

  // Largeur minimale testée (mobile)
  mobileMin: '375px',

  // Header fixe
  headerHeight: {
    mobile:  '52px',
    desktop: '64px',
  },

  // Espacement standard
  espacements: {
    xs:  '4px',
    sm:  '8px',
    md:  '16px',
    lg:  '24px',
    xl:  '32px',
    xxl: '48px',
  },

  // Border radius
  radius: {
    sm:  '4px',
    md:  '8px',
    lg:  '12px',
    xl:  '16px',
    full: '9999px',
  },
} as const

// MOS Pro P3 — Schéma TypeScript complet
// Phase 0 — Définition de tous les types de l'application

// ─────────────────────────────────────────────
// UTILISATEURS ET RÔLES
// ─────────────────────────────────────────────

export type Role = 'etudiant' | 'enseignant'

export interface Utilisateur {
  id: string
  email: string
  role: Role
  nom: string
  prenom: string
  classe: string
  created_at: string
}

// ─────────────────────────────────────────────
// STRUCTURE PÉDAGOGIQUE
// ─────────────────────────────────────────────

export type ThemeId = 'theme1' | 'theme2' | 'theme3' | 'theme4'
export type OngletId = 'capsule' | 'fiche' | 'presentiel' | 'activites' | 'travaux' | 'journal'
export type StatutProgression = 'non_commence' | 'en_cours' | 'complete'
export type StatutBadge = 'non_commence' | 'en_cours' | 'bronze' | 'argent' | 'or' | 'diamant' | 'maitre'

export interface Theme {
  id: ThemeId
  numero: number
  titre: string
  couleur: string
  seances: string[] // liste des seance_id
}

export interface Seance {
  type?: string
  id: string           // ex: 's1', 's2'...
  numero: number
  titre: string
  theme_id: ThemeId
  couleur: string      // hérité du thème
}

// ─────────────────────────────────────────────
// CAPSULE DISTANCIELLE (Onglet 1)
// ─────────────────────────────────────────────

export interface EtapeVideo {
  type: 'video'
  lien_drive: string
  titre_video: string
  intervenant: string
  duree: string           // ex: "12 min"
  consigne_visionnage: string
}

export interface EtapeQuestions {
  type: 'questions'
  questions: string[]
}

export interface EtapeExercices {
  type: 'exercices'
  consigne_globale: string
  exercices: ExerciceCapsule[]
}

export type TypeExerciceCapsule = 'texte_libre' | 'qcm' | 'tableau' | 'mise_en_situation'

export interface ExerciceCapsule {
  id: string
  type: TypeExerciceCapsule
  enonce: string
  options?: string[]         // pour QCM
  colonnes?: string[]        // pour tableau
  lignes?: string[][]        // pour tableau
}

export interface EtapeMicroTache {
  type: 'micro_tache'
  consigne: string
}

export type EtapeCapsule = EtapeVideo | EtapeQuestions | EtapeExercices | EtapeMicroTache

export interface CapsuleDistancielle {
  etapes: [EtapeVideo, EtapeQuestions, EtapeExercices, EtapeMicroTache]
}

// ─────────────────────────────────────────────
// FICHE RESSOURCE (Onglet 2)
// ─────────────────────────────────────────────

export type TypeBloc =
  | 'paragraphe'
  | 'tableau'
  | 'encadre_attention'
  | 'encadre_definition'
  | 'encadre_exemple'
  | 'liste'
  | 'reference_juridique'

export interface BlocParagraphe {
  type: 'paragraphe'
  texte: string
}

export interface BlocTableau {
  type: 'tableau'
  titre?: string
  colonnes: string[]
  lignes: string[][]
}

export interface BlocEncadre {
  type: 'encadre_attention' | 'encadre_definition' | 'encadre_exemple'
  titre?: string
  texte: string
}

export interface BlocListe {
  type: 'liste'
  titre?: string
  items: string[]
}

export interface BlocReference {
  type: 'reference_juridique'
  texte: string
}

export type BlocFiche = BlocParagraphe | BlocTableau | BlocEncadre | BlocListe | BlocReference

export interface Notion {
  id: string            // ex: 'notion_1'
  numero: number
  titre: string
  blocs: BlocFiche[]
}

export interface FicheRessource {
  notions: Notion[]
}

// ─────────────────────────────────────────────
// COURS EN PRÉSENTIEL (Onglet 3)
// ─────────────────────────────────────────────

export type Modalite = 'individuel' | 'binome' | 'groupe' | 'classe'

export type TypeElementPhase =
  | 'consigne'
  | 'document'
  | 'tableau_editable'
  | 'zone_reponse'
  | 'qcm'
  | 'texte'

export interface ElementPhase {
  id: string
  type: TypeElementPhase
  contenu: string
  colonnes?: string[]        // pour tableau_editable
  lignes?: string[][]        // pour tableau_editable (données initiales)
  options?: string[]         // pour QCM
  minuteur_secondes?: number // si exercice chronométré
}

export interface PhaseCoursPresence {
  id: string
  numero: number
  titre: string
  duree_minutes: number
  modalite: Modalite
  elements: ElementPhase[]
}

export interface CoursPresenciel {
  phases: PhaseCoursPresence[]
}

// ─────────────────────────────────────────────
// ACTIVITÉS (Onglet 4)
// ─────────────────────────────────────────────

export interface Flashcard {
  id: string
  recto: string
  verso: string
}

export interface FlashcardSM2 extends Flashcard {
  interval: number
  repetitions: number
  ease_factor: number
  next_review: string   // ISO date YYYY-MM-DD
}

export interface QuestionQuiz {
  id: string
  enonce: string
  options: [string, string, string, string]
  reponse_correcte: 0 | 1 | 2 | 3
}

export interface TermeGlossaire {
  id: string
  terme: string
  definition: string
}

export interface PaireGlisserDeposer {
  id: string
  element: string
  cible: string
}

export interface PaireAssociation {
  id: string
  colonne_gauche: string
  colonne_droite: string
}

export interface NoeudCarteMentale {
  id: string
  texte: string
  a_completer: boolean   // true = case vide à remplir par l'étudiant
  parent_id: string | null
  enfants: string[]      // ids des noeuds enfants
}

export interface Activites {
  flashcards: Flashcard[]
  quiz: QuestionQuiz[]
  glossaire: TermeGlossaire[]
  glisser_deposer: PaireGlisserDeposer[]
  associations: PaireAssociation[]
  carte_mentale: NoeudCarteMentale[]
}

// ─────────────────────────────────────────────
// TRAVAUX À RENDRE (Onglet 5)
// ─────────────────────────────────────────────

export type TypeConsigneDevoir =
  | 'texte_libre'
  | 'tableau'
  | 'qcm'
  | 'document_a_analyser'

export interface ConsigneDevoir {
  id: string
  numero: number
  type: TypeConsigneDevoir
  enonce: string
  document_joint?: string    // texte du document si analyse de document
  colonnes?: string[]
  lignes?: string[][]
}

export interface TravailARendre {
  titre: string
  contexte: string
  consignes: ConsigneDevoir[]
}

// ─────────────────────────────────────────────
// CONTENU COMPLET D'UNE SÉANCE
// ─────────────────────────────────────────────

export interface ContenuSeance {
  seance_id: string
  capsule: CapsuleDistancielle
  fiche_ressource: FicheRessource
  cours_presentiel: CoursPresenciel
  activites: Activites
  travail_a_rendre: TravailARendre
  // Le journal de bord est généré dynamiquement (saisie libre) — pas de JSON
}

// ─────────────────────────────────────────────
// PROGRESSION (local Dexie + Supabase)
// ─────────────────────────────────────────────

export interface Progression {
  user_id: string
  seance_id: string
  onglet: OngletId
  statut: StatutProgression
  score?: number
  updated_at: string
}

export interface BadgeEtudiant {
  user_id: string
  badge_id: string
  obtenu_a: string
}

// ─────────────────────────────────────────────
// RÉPONSES ET DEVOIRS
// ─────────────────────────────────────────────

export interface Reponse {
  user_id: string
  exercice_id: string
  contenu: string
  valide: boolean
  updated_at: string
}

export type StatutDevoir = 'brouillon' | 'remis'

export interface Devoir {
  id: string
  seance_id: string
  user_id: string
  contenu: Record<string, string>  // clé = consigne_id, valeur = réponse
  statut: StatutDevoir
  remis_at?: string
}

// ─────────────────────────────────────────────
// MESSAGERIE
// ─────────────────────────────────────────────

export interface Message {
  id: string
  expediteur_id: string
  destinataire_id: string   // 'groupe' pour message collectif
  contenu: string
  lu: boolean
  created_at: string
}

// ─────────────────────────────────────────────
// DÉVERROUILLAGE (géré par l'enseignant)
// ─────────────────────────────────────────────

export interface Deverrouillage {
  seance_id: string
  onglet: OngletId | 'all'
  user_id: string | 'all'   // 'all' = tout le groupe
  ouvert_a: string
  ferme_a?: string
  duree_minutes?: number
}

// ─────────────────────────────────────────────
// ANNOTATIONS ET SURLIGNAGES
// ─────────────────────────────────────────────

export interface Annotation {
  user_id: string
  seance_id: string
  notion_id: string
  texte: string
  surlignes: SurlignaGe[]
  updated_at: string
}

export interface SurlignaGe {
  bloc_id: string
  debut: number   // index caractère
  fin: number     // index caractère
}

// ─────────────────────────────────────────────
// JOURNAL DE BORD
// ─────────────────────────────────────────────

export interface EntreeJournalBord {
  id: string
  user_id: string
  seance_id: string
  contenu: string
  created_at: string
}

// ─────────────────────────────────────────────
// MINUTEURS
// ─────────────────────────────────────────────

export interface Minuteur {
  seance_id: string
  exercice_id: string
  duree_secondes: number
}

// ─────────────────────────────────────────────
// CONNEXIONS (suivi enseignant)
// ─────────────────────────────────────────────

export interface Connexion {
  user_id: string
  connecte_a: string
  deconnecte_a?: string
  duree_secondes?: number
}

// ─────────────────────────────────────────────
// DONNÉES DE NAVIGATION (constantes)
// ─────────────────────────────────────────────

export const ONGLETS: { id: OngletId; label: string }[] = [
  { id: 'capsule',    label: 'Capsule distancielle' },
  { id: 'fiche',      label: 'Fiche ressource' },
  { id: 'presentiel', label: 'Cours en présentiel' },
  { id: 'activites',  label: 'Activités' },
  { id: 'travaux',    label: 'Travaux à rendre' },
  { id: 'journal',    label: 'Journal de bord' },
]

export const THEMES: Theme[] = [
  {
    id: 'theme1',
    numero: 1,
    titre: 'Préparer l\'offre commerciale',
    couleur: '#1A56A0',
    seances: ['s1', 's2', 's3', 's4', 's5'],
  },
  {
    id: 'theme2',
    numero: 2,
    titre: 'Gérer la prestation',
    couleur: '#B22222',
    seances: ['s6', 's7', 's8', 's9', 's10', 's11'],
  },
  {
    id: 'theme3',
    numero: 3,
    titre: 'Suivre et pérenniser la relation client',
    couleur: '#B8860B',
    seances: ['s12', 's13', 's14', 's15'],
  },
  {
    id: 'theme4',
    numero: 4,
    titre: 'Consolidation et simulations E52',
    couleur: '#C2185B',
    seances: ['s16', 's17', 's18'],
  },
]

export const SEANCES: Seance[] = [
  { id: 's1',  numero: 1,  titre: 'Le secteur de la sécurité privée et la logique commerciale',     theme_id: 'theme1', couleur: '#1A56A0' },
  { id: 's2',  numero: 2,  titre: 'Décoder le cahier des charges : besoins explicites et implicites', theme_id: 'theme1', couleur: '#1A56A0' },
  { id: 's3',  numero: 3,  titre: 'Construire l\'offre commerciale : coût, marge, devis',             theme_id: 'theme1', couleur: '#1A56A0' },
  { id: 's4',  numero: 4,  titre: 'Présenter et argumenter l\'offre commerciale',                     theme_id: 'theme1', couleur: '#1A56A0' },
  { id: 's5',  numero: 5,  titre: 'Évaluation formative Partie 1 - Bilan et ancrage en alternance',   theme_id: 'theme1', couleur: '#1A56A0', type: 'evaluation' },
  { id: 's6',  numero: 6,  titre: 'Prendre en charge la prestation : consignes et prestataires',      theme_id: 'theme2', couleur: '#B22222' },
  { id: 's7',  numero: 7,  titre: 'Piloter par les indicateurs : le tableau de bord de la prestation',theme_id: 'theme2', couleur: '#B22222' },
  { id: 's8',  numero: 8,  titre: 'Maîtriser les coûts et les marges en cours de prestation',         theme_id: 'theme2', couleur: '#B22222' },
  { id: 's9',  numero: 9,  titre: 'Suivi de conformité et remontée d\'informations',                  theme_id: 'theme2', couleur: '#B22222' },
  { id: 's10', numero: 10, titre: 'Gérer les situations dégradées et l\'amélioration continue',       theme_id: 'theme2', couleur: '#B22222' },
  { id: 's11', numero: 11, titre: 'Communication externe et image de l\'entreprise de sécurité',      theme_id: 'theme2', couleur: '#B22222' },
  { id: 's12', numero: 12, titre: 'Conduire une réunion de suivi de prestation',                      theme_id: 'theme3', couleur: '#B8860B' },
  { id: 's13', numero: 13, titre: 'Évaluation formative Partie 2 - Bilan et ancrage en alternance',   theme_id: 'theme3', couleur: '#B8860B', type: 'evaluation' },
  { id: 's14', numero: 14, titre: 'La fidélisation du client : stratégies et outils',                 theme_id: 'theme3', couleur: '#B8860B' },
  { id: 's15', numero: 15, titre: 'Être force de proposition : évolutions de la prestation et démarche qualité', theme_id: 'theme3', couleur: '#B8860B' },
  { id: 's16', numero: 16, titre: 'Mobilisation transversale : du cahier des charges à la fidélisation', theme_id: 'theme4', couleur: '#C2185B', type: 'evaluation' },
  { id: 's17', numero: 17, titre: 'Simulation E52 n°1 et bilan de mi-parcours',                       theme_id: 'theme4', couleur: '#C2185B', type: 'evaluation' },
  { id: 's18', numero: 18, titre: 'Simulation E52 n°2 et bilan annuel de progression',                theme_id: 'theme4', couleur: '#C2185B', type: 'evaluation' },
]

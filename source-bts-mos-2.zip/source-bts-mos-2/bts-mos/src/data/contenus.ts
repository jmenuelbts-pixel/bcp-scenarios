// MOS Pro P3 — Loader centralisé unique
// RÈGLE : Toutes les données passent par ce fichier. Jamais d'import direct de JSON dans les pages.

import type { ContenuSeance } from './schema'
import { SEANCES, THEMES } from './schema'

// Import de tous les JSON de séances
import s1  from './seances/s1.json'
import s2  from './seances/s2.json'
import s3  from './seances/s3.json'
import s4  from './seances/s4.json'
import s5  from './seances/s5.json'
import s6  from './seances/s6.json'
import s7  from './seances/s7.json'
import s8  from './seances/s8.json'
import s9  from './seances/s9.json'
import s10 from './seances/s10.json'
import s11 from './seances/s11.json'
import s12 from './seances/s12.json'
import s13 from './seances/s13.json'
import s14 from './seances/s14.json'
import s15 from './seances/s15.json'
import s16 from './seances/s16.json'
import s17 from './seances/s17.json'
import s18 from './seances/s18.json'

// Map centralisée : seance_id → contenu complet
const CONTENUS_MAP: Record<string, ContenuSeance> = {
  s1:  s1  as unknown as ContenuSeance,
  s2:  s2  as unknown as ContenuSeance,
  s3:  s3  as unknown as ContenuSeance,
  s4:  s4  as unknown as ContenuSeance,
  s5:  s5  as unknown as ContenuSeance,
  s6:  s6  as unknown as ContenuSeance,
  s7:  s7  as unknown as ContenuSeance,
  s8:  s8  as unknown as ContenuSeance,
  s9:  s9  as unknown as ContenuSeance,
  s10: s10 as unknown as ContenuSeance,
  s11: s11 as unknown as ContenuSeance,
  s12: s12 as unknown as ContenuSeance,
  s13: s13 as unknown as ContenuSeance,
  s14: s14 as unknown as ContenuSeance,
  s15: s15 as unknown as ContenuSeance,
  s16: s16 as unknown as ContenuSeance,
  s17: s17 as unknown as ContenuSeance,
  s18: s18 as unknown as ContenuSeance,
}

// ── API publique du loader ────────────────────────────────────────────

/** Retourne le contenu complet d'une séance */
export function getContenuSeance(seanceId: string): ContenuSeance | undefined {
  return CONTENUS_MAP[seanceId]
}

/** Retourne toutes les séances d'un thème */
export function getSeancesParTheme(themeId: string) {
  const theme = THEMES.find(t => t.id === themeId)
  if (!theme) return []
  return theme.seances.map(sid => ({
    seance: SEANCES.find(s => s.id === sid)!,
    contenu: CONTENUS_MAP[sid],
  }))
}

/** Retourne les métadonnées d'une séance */
export function getMetaSeance(seanceId: string) {
  return SEANCES.find(s => s.id === seanceId)
}

/** Retourne tous les thèmes */
export function getAllThemes() {
  return THEMES
}

/** Retourne toutes les séances */
export function getAllSeances() {
  return SEANCES
}

// Re-export des constantes pour éviter les imports multiples
export { THEMES, SEANCES }

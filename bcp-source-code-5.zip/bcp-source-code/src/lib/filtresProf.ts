// filtresProf.ts
// Persistance des filtres de l'espace professeur (classe, groupe, scenario)
// pendant 30 minutes, avec un compteur commun a toutes les pages : chaque
// interaction avec un filtre relance le delai. Au-dela de 30 min sans
// activite, les filtres sont oublies.

const CLE = 'bcp_filtres_prof'
const DUREE_MS = 30 * 60 * 1000

type Filtres = Record<string, string>

interface Stocke {
  filtres: Filtres
  ts: number
}

function lireStocke(): Stocke | null {
  try {
    const brut = localStorage.getItem(CLE)
    if (!brut) return null
    const obj = JSON.parse(brut) as Stocke
    if (!obj || typeof obj.ts !== 'number') return null
    if (Date.now() - obj.ts > DUREE_MS) {
      localStorage.removeItem(CLE)
      return null
    }
    return obj
  } catch {
    return null
  }
}

// Lit un filtre memorise (ex. 'classe', 'groupe', 'scenario'). Renvoie la
// valeur par defaut si absent ou expire.
export function lireFiltre(nom: string, defaut = ''): string {
  const s = lireStocke()
  if (!s) return defaut
  return s.filtres[nom] ?? defaut
}

// Ecrit un filtre et relance le compteur de 30 min (commun a tout l'espace prof).
export function ecrireFiltre(nom: string, valeur: string): void {
  try {
    const s = lireStocke()
    const filtres = s ? { ...s.filtres } : {}
    filtres[nom] = valeur
    localStorage.setItem(CLE, JSON.stringify({ filtres, ts: Date.now() }))
  } catch {
    // ignore
  }
}

// Deverrouillage.tsx
// Espace professeur : ouverture et fermeture des onglets par mission, et
// ouverture des evaluations. Cadenas vert (ouvert) ou rouge (verrouille)
// cliquable. Boutons Tout ouvrir / Tout fermer par mission. Le journal de bord
// est toujours ouvert et non modifiable. Synchronise avec Supabase.

import { useEffect, useState } from 'react'
import { lireFiltre, ecrireFiltre } from '../../lib/filtresProf'
import { useNavigate } from 'react-router-dom'
import { SCENARIOS, ONGLETS, COULEUR_PROF } from '../../data/schema'
import {
  chargerDeverrouillages,
  definirOnglet,
  definirOngletEleve,
  definirTousOnglets,
  reinitialiserOngletEleve,
  ongletOuvert,
  aReglageIndividuel,
  evaluationsOuvertes,
  ONGLET_EVALUATION,
  toutVerrouillerPartout,
  DEVERROUILLAGE_DEFAUT,
  type EtatDeverrouillage,
} from '../../lib/deverrouillage'
import { listerElevesAcceptes } from '../../lib/enseignant'
import { rouvrirTravail } from '../../lib/eleve'
import { listerClasses, listerGroupes, listerLiaisonsGroupes, type Classe, type Groupe, type LiaisonGroupe } from '../../lib/classes'
import type { Profil } from '../../lib/auth'

// Onglets verrouillables uniquement (le journal n'est jamais verrouillable).
const ONGLETS_VERROUILLABLES = ONGLETS.filter((o) => o.verrouillable)

export function Deverrouillage() {
  const navigate = useNavigate()
  const [scenarioId, setScenarioId] = useState<string>(SCENARIOS[0].id)
  const [etat, setEtat] = useState<EtatDeverrouillage>(DEVERROUILLAGE_DEFAUT)
  const [chargement, setChargement] = useState(true)
  const [enCours, setEnCours] = useState<string | null>(null)
  // Portee courante : null = classe entiere (global), sinon un eleve.
  const [eleves, setEleves] = useState<Profil[]>([])
  const [eleveId, setEleveId] = useState<string | null>(null)
  const [classes, setClasses] = useState<Classe[]>([])
  const [groupes, setGroupes] = useState<Groupe[]>([])
  const [liaisons, setLiaisons] = useState<LiaisonGroupe[]>([])
  const [filtreClasse, setFiltreClasse] = useState<string>(() => lireFiltre('classe'))
  const [filtreGroupe, setFiltreGroupe] = useState<string>(() => lireFiltre('groupe'))

  useEffect(() => {
    chargerDeverrouillages().then((e) => {
      setEtat(e)
      setChargement(false)
    })
    listerElevesAcceptes().then(setEleves)
    listerClasses().then(setClasses)
    listerGroupes().then(setGroupes)
    listerLiaisonsGroupes().then(setLiaisons)
  }, [])

  const scenario = SCENARIOS.find((s) => s.id === scenarioId)!
  const eleveCourant = eleveId ? eleves.find((e) => e.id === eleveId) ?? null : null
  const elevesFiltres = eleves.filter((e) => {
    if (filtreClasse && e.classe_id !== filtreClasse) return false
    if (filtreGroupe && !liaisons.some((l) => l.eleve_id === e.id && l.groupe_id === filtreGroupe)) return false
    return true
  })
  const groupesDuFiltre = groupes.filter((g) => g.classe_id === filtreClasse)

  // Bascule d'un onglet : agit sur le global ou sur l'eleve selon la portee.
  async function basculer(missionId: string, ongletId: string, ouvertActuel: boolean) {
    const clef = `${missionId}::${ongletId}`
    setEnCours(clef)
    try {
      let nouvel: EtatDeverrouillage
      if (eleveId) {
        nouvel = await definirOngletEleve(scenarioId, missionId, ongletId, eleveId, !ouvertActuel, etat)
      } else {
        nouvel = await definirOnglet(scenarioId, missionId, ongletId, !ouvertActuel, etat)
      }
      setEtat(nouvel)
    } catch (e) {
      alert("L'enregistrement a échoué. Vérifiez que la migration SQL du déverrouillage a bien été exécutée dans Supabase.\n\nDétail : " + (e instanceof Error ? e.message : String(e)))
    } finally {
      setEnCours(null)
    }
  }

  async function toutPour(missionId: string, ouvrir: boolean) {
    setEnCours(`all-${missionId}`)
    try {
      let courant = etat
      for (const o of ONGLETS_VERROUILLABLES) {
        if (eleveId) {
          courant = await definirOngletEleve(scenarioId, missionId, o.id, eleveId, ouvrir, courant)
        } else {
          courant = await definirOnglet(scenarioId, missionId, o.id, ouvrir, courant)
        }
      }
      setEtat(courant)
    } catch (e) {
      alert("L'enregistrement a échoué. Vérifiez que la migration SQL du déverrouillage a bien été exécutée dans Supabase.\n\nDétail : " + (e instanceof Error ? e.message : String(e)))
    } finally {
      setEnCours(null)
    }
  }

  // Remet un onglet d'un eleve sous controle du global.
  async function reinitOnglet(missionId: string, ongletId: string) {
    if (!eleveId) return
    const clef = `${missionId}::${ongletId}`
    setEnCours(clef)
    const nouvel = await reinitialiserOngletEleve(missionId, ongletId, eleveId, etat)
    setEtat(nouvel)
    setEnCours(null)
  }

  async function rouvrirDepuisDeverrouillage(
    missionId: string,
    partie: 'travaux' | 'synthese' | 'autoeval' | 'quiz' | 'glisser',
    libelle: string
  ) {
    if (!eleveId) return
    if (!window.confirm(`Rouvrir « ${libelle} » pour cet élève ? Tout ce qu'il a déjà saisi est conservé.`)) return
    const { erreur } = await rouvrirTravail(eleveId, missionId, partie)
    if (erreur) window.alert('Échec : ' + erreur)
    else window.alert("Travail rouvert. L'élève peut de nouveau le modifier.")
  }

  // Verrouille TOUT (tous les scenarios, toutes les missions) en global.
  async function toutVerrouillerGlobal() {
    if (!window.confirm("Verrouiller TOUS les onglets de toutes les missions de tous les scénarios, y compris les quiz, glisser-déposer et les réglages individuels des élèves ?")) return
    setEnCours('lock-all')
    try {
      const nouvel = await toutVerrouillerPartout()
      setEtat(nouvel)
    } catch (e) {
      alert("L'enregistrement a échoué. Vérifiez que la migration SQL du déverrouillage a bien été exécutée dans Supabase.\n\nDétail : " + (e instanceof Error ? e.message : String(e)))
    } finally {
      setEnCours(null)
    }
  }

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', minHeight: '100vh', background: '#F1F6F3' }}>
      <header style={{ background: COULEUR_PROF, color: '#FFFFFF', padding: '16px 24px' }}>
        <div style={{ maxWidth: 1000, margin: '0 auto' }}>
          <button
            type="button"
            onClick={() => navigate('/enseignant')}
            style={btnRetourEntete}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
              <polyline points="15,5 8,12 15,19" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Tableau de bord
          </button>
          <h1 style={{ margin: 0, fontSize: 21, fontWeight: 700 }}>Déverrouillage</h1>
        </div>
      </header>

      <main style={{ maxWidth: 1000, margin: '0 auto', padding: 24 }}>
        {/* Selecteur de portee : classe entiere ou eleve precis */}
        <div style={{ background: '#FFFFFF', border: '1px solid #EAF0F5', borderRadius: 14, boxShadow: '0 2px 10px rgba(14, 165, 233, 0.08)', padding: 14, marginBottom: 16, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#1F2933' }}>Portée :</span>
          <button
            type="button"
            onClick={() => setEleveId(null)}
            style={{
              fontFamily: 'Arial, sans-serif', fontSize: 13, fontWeight: 600, padding: '8px 14px', borderRadius: 99,
              border: eleveId === null ? 'none' : '1px solid #D2DCE6',
              background: eleveId === null ? COULEUR_PROF : '#FFFFFF',
              color: eleveId === null ? '#FFFFFF' : '#4A5568', cursor: 'pointer',
            }}
          >
            Classe entière
          </button>
          <select value={filtreClasse} onChange={(e) => { setFiltreClasse(e.target.value); setFiltreGroupe(''); setEleveId(null); ecrireFiltre('classe', e.target.value); ecrireFiltre('groupe', '') }} style={{ fontFamily: 'Arial, sans-serif', fontSize: 13, padding: '8px 12px', borderRadius: 8, border: '1px solid #D2DCE6', background: '#FFFFFF', color: '#1F2933', minWidth: 160 }}>
            <option value="">Toutes les classes</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
          </select>
          <select value={filtreGroupe} onChange={(e) => { setFiltreGroupe(e.target.value); setEleveId(null); ecrireFiltre('groupe', e.target.value) }} disabled={!filtreClasse || groupesDuFiltre.length === 0} style={{ fontFamily: 'Arial, sans-serif', fontSize: 13, padding: '8px 12px', borderRadius: 8, border: '1px solid #D2DCE6', background: !filtreClasse ? '#F0F2F5' : '#FFFFFF', color: '#1F2933', minWidth: 160 }}>
            <option value="">{filtreClasse ? 'Toute la classe' : "Choisir une classe d'abord"}</option>
            {groupesDuFiltre.map((g) => <option key={g.id} value={g.id}>{g.nom}</option>)}
          </select>
          <select
            value={eleveId ?? ''}
            onChange={(e) => setEleveId(e.target.value || null)}
            style={{ fontFamily: 'Arial, sans-serif', fontSize: 13, padding: '8px 12px', borderRadius: 8, border: '1px solid #D2DCE6', background: '#FFFFFF', color: '#1F2933', minWidth: 220 }}
          >
            <option value="">— Choisir un élève —</option>
            {elevesFiltres.map((el) => (
              <option key={el.id} value={el.id}>{(el.prenom ?? '') + ' ' + (el.nom ?? '')}</option>
            ))}
          </select>
          {eleveCourant && (
            <span style={{ fontSize: 12, color: '#6B7280' }}>
              Réglage pour <b style={{ color: COULEUR_PROF }}>{eleveCourant.prenom} {eleveCourant.nom}</b> — l'état individuel prime sur le global.
            </span>
          )}
          <button
            type="button"
            disabled={enCours !== null}
            onClick={toutVerrouillerGlobal}
            title="Verrouille tous les onglets de toutes les missions de tous les scénarios"
            style={{ marginLeft: 'auto', fontFamily: 'Arial, sans-serif', fontSize: 13, fontWeight: 700, padding: '8px 14px', borderRadius: 8, border: 'none', background: '#B0413E', color: '#FFFFFF', cursor: 'pointer' }}
          >
            Tout verrouiller (tous les scénarios)
          </button>
        </div>

        {/* Selecteur de scenario */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 20 }}>
          {SCENARIOS.map((s) => {
            const actif = s.id === scenarioId
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setScenarioId(s.id)}
                style={{
                  fontFamily: 'Arial, sans-serif',
                  fontSize: 13,
                  fontWeight: 600,
                  padding: '8px 14px',
                  borderRadius: 99,
                  border: actif ? 'none' : '1px solid #D2DCE6',
                  background: actif ? COULEUR_PROF : '#FFFFFF',
                  color: actif ? '#FFFFFF' : '#4A5568',
                  cursor: 'pointer',
                }}
              >
                {s.nom}
              </button>
            )
          })}
        </div>

        {chargement ? (
          <p style={{ fontSize: 14, color: '#6B7280' }}>Chargement en cours...</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {scenario.missions.map((m) => (
              <div
                key={m.id}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: 12,
                  padding: 16,
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap', marginBottom: 12 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: '#1F2933' }}>
                    Mission {m.numero} - {m.titre}
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button
                      type="button"
                      disabled={enCours !== null}
                      onClick={() => toutPour(m.id, true)}
                      style={btnPetit('#2E8B57')}
                    >
                      Tout ouvrir
                    </button>
                    <button
                      type="button"
                      disabled={enCours !== null}
                      onClick={() => toutPour(m.id, false)}
                      style={btnPetit('#B0413E')}
                    >
                      Tout fermer
                    </button>
                  </div>
                </div>

                {/* Grille des onglets verrouillables */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {ONGLETS_VERROUILLABLES.map((o) => {
                    const ouvert = ongletOuvert(m.id, o.id, etat, eleveId ?? undefined)
                    const individuel = eleveId ? aReglageIndividuel(m.id, o.id, eleveId, etat) : false
                    return (
                      <span key={o.id} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                        <button
                          type="button"
                          disabled={enCours !== null}
                          onClick={() => basculer(m.id, o.id, ouvert)}
                          style={pastilleOnglet(ouvert)}
                          title={eleveId ? (individuel ? "Réglage individuel actif" : "Suit l'état de la classe") : undefined}
                        >
                          <CadenasIcone ouvert={ouvert} />
                          {o.libelle}
                          {eleveId && individuel && (
                            <span style={{ fontSize: 10, fontWeight: 700, background: '#16456E', color: '#FFFFFF', borderRadius: 20, padding: '1px 6px', marginLeft: 4 }}>indiv.</span>
                          )}
                        </button>
                        {eleveId && individuel && (
                          <button
                            type="button"
                            disabled={enCours !== null}
                            onClick={() => reinitOnglet(m.id, o.id)}
                            title="Revenir à l'état de la classe"
                            style={{ fontFamily: 'Arial, sans-serif', border: '1px solid #D2DCE6', background: '#FFFFFF', color: '#6B7280', borderRadius: 99, width: 22, height: 22, fontSize: 13, lineHeight: 1, cursor: 'pointer', padding: 0 }}
                          >
                            ↺
                          </button>
                        )}
                      </span>
                    )
                  })}

                  {/* Journal de bord : toujours ouvert, non modifiable */}
                  <span style={{ ...pastilleOnglet(true), cursor: 'default', opacity: 0.85 }}>
                    <CadenasIcone ouvert={true} />
                    Journal de bord (toujours ouvert)
                  </span>
                </div>

                {/* Evaluations : bouton ouvrir / fermer */}
                <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #EEF2F6', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontSize: 13, color: '#4A5568', fontWeight: 600 }}>Évaluations</span>
                  {(() => {
                    const ouvert = evaluationsOuvertes(m.id, etat, eleveId ?? undefined)
                    return (
                      <button
                        type="button"
                        disabled={enCours !== null}
                        onClick={() => basculer(m.id, ONGLET_EVALUATION, ouvert)}
                        style={btnPetit(ouvert ? '#B0413E' : '#2E8B57')}
                      >
                        {ouvert ? 'Fermer' : 'Ouvrir'}
                      </button>
                    )
                  })()}
                </div>

                {eleveId && (
                  <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #EEF2F6' }}>
                    <div style={{ fontSize: 13, color: '#4A5568', fontWeight: 600, marginBottom: 8 }}>Rouvrir un travail envoyé (le contenu de l'élève est conservé)</div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {([
                        { id: 'travaux', libelle: 'Devoir à rendre' },
                        { id: 'synthese', libelle: 'Synthèse' },
                        { id: 'autoeval', libelle: 'Auto-évaluation' },
                        { id: 'quiz', libelle: 'Quiz' },
                        { id: 'glisser', libelle: 'Glisser-déposer' },
                      ] as const).map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          disabled={enCours !== null}
                          onClick={() => rouvrirDepuisDeverrouillage(m.id, p.id, p.libelle)}
                          style={{ fontFamily: 'Arial, sans-serif', background: '#FFFFFF', border: '1.5px solid #B0413E', color: '#B0413E', borderRadius: 8, padding: '7px 14px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}
                        >
                          Rouvrir : {p.libelle}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

// Icone cadenas : ouvert (vert) ou ferme (rouge).
function CadenasIcone({ ouvert }: { ouvert: boolean }) {
  const couleur = ouvert ? '#2E8B57' : '#B0413E'
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
      <rect x="5" y="11" width="14" height="9" rx="2" fill="none" stroke={couleur} strokeWidth="2" />
      {ouvert ? (
        <path d="M8 11 V8 a4 4 0 0 1 7 -2" fill="none" stroke={couleur} strokeWidth="2" strokeLinecap="round" />
      ) : (
        <path d="M8 11 V8 a4 4 0 0 1 8 0 v3" fill="none" stroke={couleur} strokeWidth="2" />
      )}
    </svg>
  )
}

const btnRetourEntete: React.CSSProperties = {
  fontFamily: 'Arial, sans-serif',
  background: 'rgba(255,255,255,0.2)',
  border: 'none',
  color: '#FFFFFF',
  borderRadius: 99,
  padding: '6px 14px',
  fontSize: 13,
  cursor: 'pointer',
  marginBottom: 10,
  display: 'inline-flex',
  alignItems: 'center',
  gap: 6,
}

function btnPetit(couleur: string): React.CSSProperties {
  return {
    fontFamily: 'Arial, sans-serif',
    background: couleur,
    color: '#FFFFFF',
    border: 'none',
    borderRadius: 8,
    padding: '6px 12px',
    fontSize: 12,
    fontWeight: 600,
    cursor: 'pointer',
  }
}

function pastilleOnglet(ouvert: boolean): React.CSSProperties {
  return {
    fontFamily: 'Arial, sans-serif',
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    fontSize: 12,
    fontWeight: 600,
    padding: '7px 12px',
    borderRadius: 99,
    border: `1px solid ${ouvert ? '#A8D5BC' : '#E2B3B1'}`,
    background: ouvert ? '#EAF7EF' : '#FCECEB',
    color: ouvert ? '#0EA5E9' : '#8A2A28',
    cursor: 'pointer',
  }
}
